#!/usr/bin/python3
import os
import math

os.system("clear")
num = int(input('Enter number: '))
root = math.sqrt(num)

if int(root + 0.5) ** 2 == num:
    print(num, 'is a perfect square.')
else:
    print(num, 'is not a perfect square.')
