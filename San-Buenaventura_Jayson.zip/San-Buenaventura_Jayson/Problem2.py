#!/usr/bin/python3
import os

def singleNum(arr,n):
    res = arr[0]
    for i in range(1,n):
        res = res ^ arr[i]     
    return res

def main():
    os.system("clear")
    arr = []
    n = int(input("Enter list size: "))
    
    print("\n")
    for i in range(0, n):
        print("Enter element: ", i, )
        item = int(input())
        arr.append(item)
    print("User list is: ", arr)
    print("Element occurring once is", singleNum(arr, len(arr)))

main()
