// Create a program that will compute the sum of two integers number.

#include <iostream>
using namespace std;

int main(){
	int num1, num2, sum;

	cout << "Enter num1: ";
	cin >> num1;

	cout << "Enter num2: ";
	cin >> num2;

	sum = num1 + num2;
	cout << "Sum: " << sum;

	return 0;
}
