// Create a program that will compute the quotient of two integers number.

#include <iostream>
using namespace std;

int main(){
	int num1, num2, quo;

	cout << "Enter num1: ";
	cin >> num1;

	cout << "Enter num2: ";
	cin >> num2;

	quo = num1 / num2;
	cout << "Quotient: " << quo;

	return 0;
}
