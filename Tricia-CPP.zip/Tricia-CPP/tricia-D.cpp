// Create a program that will compute the area of a trapezoid.

#include <iostream>
using namespace std;

int main() {
	float trapezoidBase1;
	float trapezoidBase2;
	float trapezoidHeight;

	cout << "Please enter base1 of trapezoid:";
	cin >> trapezoidBase1;

	cout << "Please enter base2 of trapezoid:";
	cin >> trapezoidBase2;

	cout << "Please enter height of trapezoid:";
	cin >> trapezoidHeight;

	float areaOfTrapezoid = (trapezoidBase1 + trapezoidBase2) * trapezoidHeight / 2;

	cout << "Area of trapezoid is: " << areaOfTrapezoid;

	return 0;
}
