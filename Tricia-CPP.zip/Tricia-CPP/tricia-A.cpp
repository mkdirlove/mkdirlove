// Create a program that will display your basic information.

#include <iostream>
using namespace std;

int main(){

	string name = "Tricia Mae Arguson";
	string addr = "test";
	string bday = "test";
	string gender = "Female";
	string email = "test";
	string contact = "0909090909";
	int age = 18;
	
	cout << "\nName      :   " << name;
	cout << "\nAge       :   " << age;
	cout << "\nAddress   :   " << addr;
	cout << "\nBirthday  :   " << bday;
	cout << "\nGender    :   " << gender;
	cout << "\nEmail     :   " << email;
	cout << "\nContact   :   " << contact;

	return 0;
}
