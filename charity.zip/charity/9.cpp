#include<iostream>
using namespace std;
int main()
{
double sales,bonus;
cout<<"Enter the sales made by the salesman:\n";
cin>>sales;

if(sales>150000)
bonus=sales*0.02;

if(sales<150000)
bonus=sales*0.01;

cout<<"\nThe bonus is: "<<bonus<<"\n";
return 0;
}
