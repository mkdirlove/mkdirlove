#include <iostream>
using namespace std;
int main(){
	int midium = 245, large = 349, coupon = 59, total, order, opt;

	cout << "Micci\'s Pizzeria'";
	cout << "\n----------------\n";
	cout << "1. Midium : P245\n";
	cout << "2. Large : P349";
	cout << "\n";
	cout << "Type your order (1/2): ";
	cin >> order;

	if(order == 1){
		cout << "Do you have a coupon (y/n)?: ";
		cin >> opt;
		if(opt == 'y'){
			total = midium - coupon;
			cout << "\nOrder: " << order;
			cout << "\nCoupon: " << coupon;
			cout << "\nTotal: " << total;
		}
		else{
			total = large;
			cout << "\nOrder: " << order;
			cout << "\nCoupon: " << coupon;
			cout << "\nTotal: " << total;
		}

	if(order == 2){
		if(opt == 'y'){
			total = midium - coupon;
			cout << "\nOrder: " << order;
			cout << "\nCoupon: " << coupon;
			cout << "\nTotal: " << total;
		}
		else{
			total = large;
			cout << "\nOrder: " << order;
			cout << "\nCoupon: " << coupon;
			cout << "\nTotal: " << total;
		}
	}
	}
	return 0;
}
