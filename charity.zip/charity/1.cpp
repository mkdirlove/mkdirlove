#include <iostream>
using namespace std;
int main(){
	int scr1, scr2, scr3, avg;

	cout << "Enter score1: ";
	cin >> scr1;
	cout << "Enter score2: ";
	cin >> scr2;
	cout << "Enter score2: ";
	cin >> scr3;

	avg = scr1 + scr2 + scr3 / 3;
	if(avg >= 75){
		cout << "Passed!";
	}
	else{
		cout << "Failed!";
	}
 	return 0;
}
