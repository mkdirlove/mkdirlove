#include <iostream>

using namespace std;

int main()
{
float A,B,C,Total;
cout << "Enter Price of 1st Item:";
cin>>A;
cout<<"Enter Priceof 2nd Item:";
cin>>B;
if(A < B){
C=A/2;
Total=A+C;
}
else
{
C=B/2;
Total=A+C;
}
cout<<"Total Price= "<< Total;
return 0;
}
