#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;

const double OVERTIME_RATE = 1.5;


double calcTotalGrossPay (double rate, double hours)

{

return rate * hours ;

}

int main()

{

double hours = 0;
double rate = 0;
double monthly = 0;
double weekly = 0;
int weekBeingPaid = 1;

cout.setf(ios::fixed);
cout.setf(ios::showpoint);
cout.precision (2);


    cout << "Enter employee's hourly rate: ";
    cin >> rate;

monthly = monthly + calcTotalGrossPay (rate, hours);


     while (weekBeingPaid <=4)

{

        cout << "Enter hours worked for week  " << weekBeingPaid <<":" <<endl;

        cin >> hours;

    if (hours > 40)

{

        weekly = (hours * rate) + (hours - 40) * OVERTIME_RATE;

        monthly = monthly = calcTotalGrossPay (hours, rate);

}

    else if (hours <= 40)

{
        weekly = hours * rate;

        monthly = monthly = calcTotalGrossPay (hours, rate);

}

    else if (monthly + hours > 40)

{

     monthly = monthly + calcTotalGrossPay (hours, rate);


}

cout <<"Employee's pay for the week "<<weekBeingPaid<<" is: "<< monthly <<endl;

 weekBeingPaid++;

}

cout << "Employee's total gross pay for the month is: "<< calcTotalGrossPay <<endl;


    return 0;

}
