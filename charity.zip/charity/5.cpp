#include <iostream>
using namespace std;

int main()
{
    float r, d = 0, c = 0, a = 0;
    
    // r = radius
    // d = diameter
    // c = circumference
    // a = area

    cout << "Enter the radius of the circle: ";
    cin >> r;

    /* Calculation of diameter, circumference and area */
    d = 2 * r;
    c = 2 * 3.14 * r;
    a = 3.14 * (r * r);

    /* Print output */
    cout << "\n";
    cout << "Diameter      : " << d << " units\n";
    cout << "Circumference : " << c << " units\n";
    cout << "Area          : " << a << " sq. units";

    return 0;
}
