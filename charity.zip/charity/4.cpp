#include <iostream>
using namespace std;

int main() {
   int length1, width1, length2, width2, area1, area2;

   cout << "Classroom Area Calculator\n";

   cout << "\nLength of classroom #1: ";
   cin>>length1;

   cout << "\nWidth of classroom #1: ";
   cin>>width1;


   cout << "\nLength of classroom #2: ";
   cin>>length2;

   cout << "\nWidth of classroom #2: ";
   cin>>width2;

   area1 = length1 * width1;
   area2 = length2 * width2;
	
   
   if(area1 < area2){
   	cout << "\nRoom #2 is bigger.";
   }
   else if(area1 > area2){
   	cout << "\nRoom #1 is bigger.";
   }
   else if(area1 == area2){
    cout << "\nRoom #1 and Room #2 is equal.";	
   }
   return (0);
}
