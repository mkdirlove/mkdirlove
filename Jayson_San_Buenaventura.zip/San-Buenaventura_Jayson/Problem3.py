#!/usr/bin/python3
import os

def reverse_sum(n1, n2):
    return int(str(int(str(n1)[::-1]) + int(str(n2)[::-1]))[::-1])

def main():
    os.system("clear")
    num1 = input("Enter num1: ")
    num2 = input("Enter num2: ")

    print(reverse_sum(num1, num2))

main()
