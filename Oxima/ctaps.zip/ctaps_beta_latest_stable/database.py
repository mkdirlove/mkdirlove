import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__, static_folder='static')

# Define the uploads folder path
UPLOADS_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOADS_FOLDER

# Database setup
DB_FILE = 'crud_app.db'
app.config['DATABASE'] = DB_FILE

def create_table():
    with sqlite3.connect(app.config['DATABASE']) as connection:
        cursor = connection.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS organizations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                logo_path TEXT,
                org_name TEXT,
                founder TEXT,
                year_founded INTEGER,
                total_members INTEGER,
                capabilities TEXT,
                description TEXT,
                latitude REAL,
                longitude REAL,
                gen_location TEXT
            )
        ''')
        # Create the individuals table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS individuals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                logo_path TEXT,
                code_name TEXT,
                real_name TEXT,
                org_associated TEXT,
                capabilities TEXT,
                description TEXT,
                latitude REAL,
                longitude REAL,
                gen_location TEXT
            )
        ''')
        connection.commit()

create_table()
