import os
import shutil
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.config['SESSION_TYPE'] = 'filesystem'
app.secret_key = 'your_secret_key'

# Define the uploads folder path
UPLOADS_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOADS_FOLDER

# Replace this with a more secure storage mechanism in production
admin_credentials = {'username': 'admin', 'password': 'admin'}

# Database setup
DB_FILE = 'crud_app.db'
app.config['DATABASE'] = DB_FILE

def create_table():
    with sqlite3.connect(app.config['DATABASE']) as connection:
        cursor = connection.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS organizations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                logo_path TEXT,
                org_name TEXT,
                founder TEXT,
                year_founded INTEGER,
                total_members INTEGER,
                capabilities TEXT,
                description TEXT,
                latitude REAL,
                longitude REAL
            )
        ''')
        # Create the individuals table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS individuals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                logo_path TEXT,
                code_name TEXT,
                real_name TEXT,
                org_associated TEXT,
                capabilities TEXT,
                description TEXT,
                latitude REAL,
                longitude REAL
            )
        ''')
        connection.commit()

def allowed_file(filename):
    # Define your file upload criteria here
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'jpg', 'jpeg', 'png', 'gif'}

# Function to copy the 'uploads' folder contents to the 'static' folder
def copy_uploads_to_static():
    uploads_path = os.path.join(os.getcwd(), 'uploads')  # Change 'os.getcwd()' if needed
    static_path = os.path.join(os.getcwd(), 'static/uploads')
    
    try:
        shutil.rmtree(static_path)  # Remove the existing 'static' folder
        shutil.copytree(uploads_path, static_path)  # Copy the 'uploads' folder to 'static'
        print('Uploads copied to Static successfully!')
    except Exception as e:
        print(f'Error copying uploads to static: {e}')
        
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/view/<int:id>')
def view_organization(id):
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM organizations WHERE id=?', (id,))
    organization = cursor.fetchone()
    conn.close()

    return render_template('view_organization.html', organization=organization)

@app.route('/view_indi/<int:id>')
def view_individual(id):
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM individuals WHERE id=?', (id,))
    individual = cursor.fetchone()
    conn.close()

    # Logic to fetch and display individual with the given id
    return render_template('view_individual.html', individual=individual)
        
# Add this route to your Flask application
@app.route('/logout')
def logout():
    # Perform logout actions (e.g., clear session)
    # Redirect to the login page
    return redirect(url_for('login'))

@app.route('/index', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == admin_credentials['username'] and password == admin_credentials['password']:
            # Successful login, set session variable and redirect to dashboard
            session['logged_in'] = True
            return redirect(url_for('admin_dashboard'))

        else:
            # Failed login, show error message
            error_message = 'Invalid username or password. Please try again.'
            return render_template('index.html', error_message=error_message)

    return render_template('index.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    with sqlite3.connect(app.config['DATABASE']) as connection:
        cursor = connection.cursor()
        # Fetch data from the organizations table
        cursor.execute('SELECT * FROM organizations')
        organizations = cursor.fetchall()
        # Fetch data from the individuals table
        cursor.execute('SELECT * FROM individuals')
        individuals = cursor.fetchall()
    
    return render_template('admin_dashboard.html', organizations=organizations, individuals=individuals)

@app.route('/admin/cyber_orgs')
def cyber_orgs():
    with sqlite3.connect(app.config['DATABASE']) as connection:
        cursor = connection.cursor()
        cursor.execute('SELECT * FROM organizations')
        organizations = cursor.fetchall()
    return render_template('organizations.html', organizations=organizations)
    
@app.route('/admin/cyber_solo')
def cyber_solo():
    with sqlite3.connect(app.config['DATABASE']) as connection:
        cursor = connection.cursor()
        cursor.execute('SELECT * FROM individuals')
        individuals = cursor.fetchall()
    return render_template('individuals.html', individuals=individuals)
    
@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_organization(id):
    if request.method == 'POST':
        logo = request.files.get('logo')
        org_name = request.form['org_name']
        founder = request.form['founder']
        year_founded = request.form['year_founded']
        total_members = request.form['total_members']
        capabilities = request.form['capabilities']
        description = request.form['description']
        latitude = request.form['latitude']
        longitude = request.form['longitude']

        conn = sqlite3.connect('crud_app.db')
        cursor = conn.cursor()

        # Check if a new logo is provided
        if logo and allowed_file(logo.filename):
            logo_path = os.path.join(app.config['UPLOAD_FOLDER'], logo.filename)
            logo.save(logo_path)
            # Update organization with the new logo path
            cursor.execute('''
                UPDATE organizations
                SET logo_path=?, org_name=?, founder=?, year_founded=?, total_members=?, capabilities=?, description=?, latitude=?, longitude=?
                WHERE id=?
            ''', (logo_path, org_name, founder, year_founded, total_members, capabilities, description, latitude, longitude, id))
        else:
            # Update organization without changing the logo
            cursor.execute('''
                UPDATE organizations
                SET org_name=?, founder=?, year_founded=?, total_members=?, capabilities=?, description=?, latitude=?, longitude=?
                WHERE id=?
            ''', (org_name, founder, year_founded, total_members, capabilities, description, latitude, longitude, id))

        conn.commit()
        conn.close()

        # Call the function to copy uploads to static
        copy_uploads_to_static()
        
        return redirect(url_for('admin_dashboard'))

    conn = sqlite3.connect('crud_app.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM organizations WHERE id=?', (id,))
    organization = cursor.fetchone()
    conn.close()

    return render_template('edit_organization.html', organization=organization)

@app.route('/edit_individual/<int:id>', methods=['GET', 'POST'])
def edit_individual(id):
    if request.method == 'POST':
        logo = request.files.get('logo')
        code_name = request.form['code_name']
        real_name = request.form['real_name']
        org_associated = request.form['org_associated']
        capabilities = request.form['capabilities']
        description = request.form['description']
        latitude = request.form['latitude']
        longitude = request.form['longitude']

        conn = sqlite3.connect('crud_app.db')
        cursor = conn.cursor()

        # Check if a new logo is provided
        if logo and allowed_file(logo.filename):
            logo_path = os.path.join(app.config['UPLOAD_FOLDER'], logo.filename)
            logo.save(logo_path)
            # Update individual with the new logo path
            cursor.execute('''
                UPDATE individuals
                SET logo_path=?, code_name=?, real_name=?, org_associated=?, capabilities=?, description=?, latitude=?, longitude=?
                WHERE id=?
            ''', (logo_path, code_name, real_name, org_associated, capabilities, description, latitude, longitude, id))
        else:
            # Update individual without changing the logo
            cursor.execute('''
                UPDATE individuals
                SET code_name=?, real_name=?, org_associated=?, capabilities=?, description=?, latitude=?, longitude=?
                WHERE id=?
            ''', (code_name, real_name, org_associated, capabilities, description, latitude, longitude, id))

        conn.commit()
        conn.close()

        # Call the function to copy uploads to static
        copy_uploads_to_static()
        
        return redirect(url_for('cyber_solo'))

    conn = sqlite3.connect('crud_app.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM individuals WHERE id=?', (id,))
    individual = cursor.fetchone()
    conn.close()

    return render_template('edit_individual.html', individual=individual)
    
@app.route('/delete/<int:id>')
def delete_organization(id):
    conn = sqlite3.connect('crud_app.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM organizations WHERE id=?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_dashboard'))

@app.route('/delete_indi/<int:id>')
def delete_individual(id):
    conn = sqlite3.connect('crud_app.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM individuals WHERE id=?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_dashboard'))
    
@app.route('/add', methods=['GET', 'POST'])
def add_organization():
    if request.method == 'POST':
        logo = request.files['logo']
        org_name = request.form['organization_name']  # Fix the key here
        founder = request.form['founder']
        year_founded = request.form['year_founded']
        total_members = request.form['total_members']
        capabilities = request.form['capabilities']
        description = request.form['description']
        latitude = request.form['latitude']
        longitude = request.form['longitude']

        if logo and allowed_file(logo.filename):
            logo_path = os.path.join(app.config['UPLOAD_FOLDER'], logo.filename)
            logo.save(logo_path)
        else:
            logo_path = None

        conn = sqlite3.connect(app.config['DATABASE'])
        cursor = conn.cursor()
        cursor.execute('''
                    INSERT INTO organizations (logo_path, org_name, founder, year_founded, total_members, capabilities, description, latitude, longitude)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (logo_path, org_name, founder, year_founded, total_members, capabilities, description, latitude, longitude))
        conn.commit()
        conn.close()

        # Call the function to copy uploads to static
        copy_uploads_to_static()

        return redirect(url_for('admin_dashboard'))

    return render_template('add_organization.html')

@app.route('/add_indi', methods=['GET', 'POST'])
def add_individual():
    if request.method == 'POST':
        logo = request.files['logo']
        code_name = request.form['code_name']
        real_name = request.form['real_name']
        org_associated = request.form['org_associated']
        capabilities = request.form['capabilities']
        description = request.form['description']
        latitude = request.form['latitude']
        longitude = request.form['longitude']

        if logo and allowed_file(logo.filename):
            logo_path = os.path.join(app.config['UPLOAD_FOLDER'], logo.filename)
            logo.save(logo_path)
        else:
            logo_path = None

        conn = sqlite3.connect(app.config['DATABASE'])
        cursor = conn.cursor()
        cursor.execute('''
                    INSERT INTO individuals (logo_path, code_name, real_name, org_associated, capabilities, description, latitude, longitude)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (logo_path, code_name, real_name, org_associated, capabilities, description, latitude, longitude))
        conn.commit()
        conn.close()

        # Call the function to copy uploads to static
        copy_uploads_to_static()

        return redirect(url_for('admin_dashboard'))

    return render_template('add_individual.html')
    
if __name__ == '__main__':
    app.run(debug=True, port=5000)
