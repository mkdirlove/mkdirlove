import requests

url = "https://extract-news.p.rapidapi.com/v0/article"

querystring = {"url":"https://www.philstar.com/tags/cybersecurity"}

headers = {
	"X-RapidAPI-Key": "18140c0733msh4177590f10ca716p1ba0c8jsnd344b761be19",
	"X-RapidAPI-Host": "extract-news.p.rapidapi.com"
}

response = requests.get(url, headers=headers, params=querystring)

print(response.json())
