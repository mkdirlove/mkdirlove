import java.util.Scanner;
public class problem6 {

    public static void main(String[] args) {
        
        double in, yd, cm, ft, mt;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Inch: ");
        in = sc.nextInt();
        
        sc.close();
        cm = in * 2.54;
		ft = in / 12;
		yd = in / 36;
		mt = in / 39.37;  
		
        System.out.println("Inch to Centimeter: "+cm);
        System.out.println("Inch to Meter: "+mt);
        System.out.println("Inch to Yard: "+yd);
        System.out.println("Inch to Foot: "+ft);
    }
}
