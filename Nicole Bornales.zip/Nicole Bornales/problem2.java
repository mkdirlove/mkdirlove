import java. io.*;
class problem2 {
static InputStreamReader reader = new InputStreamReader (System. in) ;
static BufferedReader input = new BufferedReader (reader) ;
public static void main (String[] args) throws Exception {
String namel;
String name2;
System. out . print ("Please enter your name:" ) ,
name 1 = input . readLine ( );
System. out. print ("Please enter your friend's name: ;
name 2 = input . readLine ( ) ;
System. out . print ( " " +namel+ " and " +name2 + " are friends\n")
}
}
