import java.io.*;
public class problem4 {
     public static void main(String[] args) throws IOException{
  	    BufferedReader num= new BufferedReader(new InputStreamReader(System.in));

     	System.out.print("No. of hours worked: ");
     	int hw= Integer.parseInt(num.readLine());

        double othours = hw - 40;
        double otfee = (othours*1.5)*108.33;
        double rate = 108.33;
        double anet = rate*40;
        double net= anet+otfee;
        
        System.out.println("No of hours work: "+hw);
        System.out.println("Net Income: "+net);
        System.out.println("Overtime Fee's: "+otfee);
    }
}
