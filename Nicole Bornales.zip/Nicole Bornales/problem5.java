import java.util.Scanner;

class problem5 
	{
	
	public static void main(String[] args)
	{
		double fahrenheit = 50.0, celsius = 0.0;
	    Scanner sc = new Scanner(System.in);
        System.out.println("Enter temperature in Fahrenheit:");
        fahrenheit = sc.nextDouble();

		celsius = (fahrenheit - 32) / 1.8;

		System.out.println(fahrenheit + " degree Fahrenheit is equal to "+ celsius +" in Celsius");
	}
}
