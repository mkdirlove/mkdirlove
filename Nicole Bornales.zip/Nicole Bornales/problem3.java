import java.util.Scanner;
public class problem3 {

    public static void main(String[] args) {
        
        int num1, num2, sum, dif, pro, quo;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter First Number: ");
        num1 = sc.nextInt();
        
        System.out.println("Enter Second Number: ");
        num2 = sc.nextInt();
        
        sc.close();
        sum = num1 + num2;
        dif = num1 - num2;
        pro = num1 * num2;
        quo = num1 / num2;
        System.out.println("Sum of two numbers: "+sum);
        System.out.println("Difference of two numbers: "+dif);
        System.out.println("Product of two numbers: "+pro);
        System.out.println("Quotient two numbers: "+quo);
    }
}
