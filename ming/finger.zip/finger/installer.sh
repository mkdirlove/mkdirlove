#!/usr/bin/bash

echo "Installing dependencies..."
ulimit -n 999999
apt install npm screen -y
npm install url
npm install fs
npm install user-agents
npm install http2
npm install http
npm install tls
npm install crypto
npm install request
npm install cluster
npm install fake-useragent
npm install randomstring
npm install child_process
npm install events
npm install net
npm install axios
npm install cheerio
npm install os
npm install colors
npm install minimist
npm install cloudscraper
npm install header-generator
npm install gradient-string

echo "\nDependencies installation success..."
