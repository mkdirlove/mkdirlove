import numpy as np

temp_F = [32, 50, -25.6, 212, 73.4]

feh = np.array(temp_F)

cel = (5/9) * (feh - 32)

print(f"[Output]:\n{cel}")
