weight = float(input("Enter the weight in kg: "))  
height = float(input("Enter the height in cm: "))  

the_BMI = weight / (height/100)**2  

if the_BMI <= 15:  
    print(f"Your BMI is {the_BMI} and You are very severely underweight.")  
elif the_BMI <= 15 and the_BMI >= 16:  
    print(f"Your BMI is {the_BMI} and You severely underweight.")  
elif the_BMI <= 16 and the_BMI >= 18.5 :  
    print(f"Your BMI is {the_BMI} and You are underweight.")  
elif the_BMI <= 18.5 and the_BMI >= 25:  
    print(f"Your BMI is {the_BMI} and You are Normal (healthy weight).")  
elif the_BMI <= 25 and the_BMI >= 30: 
    print(f"Your BMI is {the_BMI} and You are overweight.")  
elif the_BMI <= 30 and the_BMI >= 35:  
    print(f"Your BMI is {the_BMI} and You are moderately obese.")  
elif the_BMI <= 35 and the_BMI >= 40:  
    print(f"Your BMI is {the_BMI} and You are severly obese.")  
elif the_BMI > 40:  
    print(f"Your BMI is {the_BMI} and You very severly obese.")  
else:  
    print("Invalid input, please try again...")  
