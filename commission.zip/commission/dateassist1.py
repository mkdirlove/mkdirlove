my_fave_list = ["Fight Club", "Eternal Sunshine of the Spotless Mind", "Memento", "Happy Feet", "Harry Potter"]

her_fave_list = []

print("You have 3 common fave movies and they are:")
print(*my_fave_list[0:3], sep="\n")
print("")

fave1 = input("Enter fave movie 1: ")
fave2 = input("Enter fave movie 2: ")
fave3 = input("Enter fave movie 3: ")
fave4 = input("Enter fave movie 4: ")
fave5 = input("Enter fave movie 5: ")

her_fave_list.append(fave1)
her_fave_list.append(fave2)
her_fave_list.append(fave3)
her_fave_list.append(fave4)
her_fave_list.append(fave5)

if len(her_fave_list) <= 3:
    print("It  will never work out. Nice meeting you!")
    print("")
    
if fave1 in my_fave_list: 
    print('It will work out.')
elif fave2 in my_fave_list: 
    print('It will work out.')
elif fave3 in my_fave_list: 
    print('It will work out.')
elif fave4 in my_fave_list: 
    print('It will work out.')
elif fave5 in my_fave_list: 
    print('It will work out.')
else:
    print("It  will never work out. Nice meeting you!")

