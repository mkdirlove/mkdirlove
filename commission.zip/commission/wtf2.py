import numpy as np

temp_F = [50, -25.6]

feh = np.array(temp_F)

cel = (5/9) * (feh - 32)

print("[Output]:")
print(str(temp_F[0])+"F is equivalent to "+str(cel[0]))
print(str(temp_F[1])+"F is equivalent to "+str(cel[1]))
