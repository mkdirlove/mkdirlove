class problem2 {
    public static void main(String[] args) {
    	
        System.out.println("LL            A    V     V    A\n");
        System.out.println("LL           A A    V   V    A A\n");
        System.out.println("LL          AAAAA    V V    AAAAA\n");
        System.out.println("LLLLLLLL   A     A    V    A     A\n");   
    }
}
