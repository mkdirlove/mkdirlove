import java.util.*;  
class problem2 {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    int num1,num2,num3,num4,num5,num6,num7,num8,num9,num10,num11,num12,num13,num14,num15,num16,num17,num18,num19,num20,avg;
    
    System.out.print("Enter num1: ");  
    num1 = sc.nextInt();  

    System.out.print("Enter num2: ");  
    num2 = sc.nextInt();  
    
    System.out.print("Enter num3: ");  
    num3 = sc.nextInt();  
    
    System.out.print("Enter num4: ");  
    num4 = sc.nextInt();  
    
    System.out.print("Enter num5: ");  
    num5 = sc.nextInt();  
    
    System.out.print("Enter num6: ");  
    num6 = sc.nextInt();  
    
    System.out.print("Enter num7: ");  
    num7 = sc.nextInt();  
    
    System.out.print("Enter num8: ");  
    num8 = sc.nextInt();  
    
    System.out.print("Enter num9: ");  
    num9 = sc.nextInt();  
    
    System.out.print("Enter num10: ");  
    num10 = sc.nextInt();  
    
    System.out.print("Enter num11: ");  
    num11 = sc.nextInt();  
    
    System.out.print("Enter num12: ");  
    num12 = sc.nextInt();  
    
    System.out.print("Enter num13: ");  
    num13 = sc.nextInt();  
    
    System.out.print("Enter num14: ");  
    num14 = sc.nextInt();  
    
    System.out.print("Enter num15: ");  
    num15 = sc.nextInt();  
    
    System.out.print("Enter num16: ");  
    num16 = sc.nextInt();  
    
    System.out.print("Enter num17: ");  
    num17 = sc.nextInt();  
    
    System.out.print("Enter num18: ");  
    num18 = sc.nextInt();  
    
    System.out.print("Enter num19: ");  
    num19 = sc.nextInt();  
    
    System.out.print("Enter num20: ");  
    num20 = sc.nextInt();  

    avg = num1 + num2 + num3 + num4 + num5 + num6 + num7 + num8 + num9 + num10 + num11 + num12 + num13 + num14 + num15 + num16 + num17 + num18 + num19 + num20 / 20;
    System.out.println("\nAverage: "+avg);
  }
}
