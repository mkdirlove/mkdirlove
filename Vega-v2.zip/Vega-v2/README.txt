----------------------------------------------------------------------------------------------------------
                                    !! **IMPORTANT | : | READ ALL** !!
----------------------------------------------------------------------------------------------------------

To Install New Updates, Go To This Link: https://link-to.net/82375/VegaExecutor

If You Are Having Any Problems, Check This Document For Help: https://pastebin.com/raw/vuqUBNJR

To Add Scripts To The Script List, Just Put Your '.txt' Script Files Into The Folder Named "Scripts".

Any Extra Questions? DM Me On Discord For Help, Or Check The Pastebin For Common Questions. Peace!

----------------------------------------------------------------------------------------------------------

I Hope You Enjoy Using Vega X!

~ 1_F0 ~ https://1f0discordlink.weebly.com/

----------------------------------------------------------------------------------------------------------