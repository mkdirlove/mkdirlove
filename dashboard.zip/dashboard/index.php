<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (latest entry first)
$result = mysqli_query($mysqli, "SELECT * FROM users ORDER BY id DESC"); // using mysqli_query instead

?>

<html>
<head>
	<title>Dashboard</title>
	<style>
		table {
			border-collapse: collapse;
			width: 80%;
			margin: 20px auto;
		}
		th, td {
			padding: 8px;
			text-align: left;
			border-bottom: 1px solid #ddd;
		}
		th {
			background-color: #f2f2f2;
		}
		tr:nth-child(even) {
			background-color: #f2f2f2;
		}
		a {
			color: #008CBA;
			text-decoration: none;
		}
		a:hover {
			color: #005580;
			text-decoration: underline;
		}
	</style>
</head>
<body>
	<br/>
	<a href="add.html" style="text-decoration: none; padding: 10px 20px; background-color: #4CAF50; color: white; border-radius: 4px;">Add New Data</a>
	<?php if(mysqli_num_rows($result) == 0): ?>
		<p>No data is available, please add some data...</p>
	<?php else: ?>
		<table>
			<tr>
				<th>Name</th>
				<th>Age</th>
				<th>Email</th>
				<th>Update</th>
			</tr>
			<?php 
			while($res = mysqli_fetch_array($result)) { 		
				echo "<tr>";
				echo "<td>".$res['name']."</td>";
				echo "<td>".$res['age']."</td>";
				echo "<td>".$res['email']."</td>";	
				echo "<td>
  <a href=\"edit.php?id=$res[id]\" style=\"text-decoration:none; padding:5px 10px; background-color:#008CBA; color:white; border-radius:4px;\">Edit</a> | 
  <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\" style=\"text-decoration:none; padding:5px 10px; background-color:#f44336; color:white; border-radius:4px;\">Delete</a>
</td>
";		
			}
			?>
		</table>
	<?php endif; ?>
</body>
</html>
