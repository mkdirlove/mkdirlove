#include <iostream>
#include <cmath>

using namespace std;

void Force() {
    float force, mass, acceleration;
    cout << " Enter the Mass: ";
    cin >> mass;
    cout << " Enter the Acceleration: ";
    cin >> acceleration;

    force = mass * acceleration;

    cout << " Force: " << force << " N\n";
}

void Mass() {
    float force, mass, acceleration;
    cout << " Enter the Force: ";
    cin >> force;
    cout << " Enter the Acceleration: ";
    cin >> acceleration;

    mass = force / acceleration;

    cout << " Mass: " << mass << " kg\n";
}

void Acceleration() {
    float force, mass, acceleration;
    cout << " Enter the Force: ";
    cin >> force;
    cout << " Enter the Mass: ";
    cin >> mass;

    acceleration = force / mass;

    cout << " Acceleration: " << acceleration << " m/s²\n";
}

void choices() {
  char choice;
  
  cout<<"\n --------------------------\n";
  cout<<" Newton's 2nd Law of Motion";
  cout<<"\n --------------------------\n\n";
  cout<<" 1. Force (N)\n";
  cout<<" 2. Mass (kg)\n";
  cout<<" 3. Acceleration (m/s²)\n";
  cout<<" 4. Exit\n";
  cout<<"\n You want to compute for: ";
  cin>>choice;
  cout<<"\n";
  switch(choice)
  {
     case '1' :
     	Force();
        choices();
        break;
        
     case '2' :
     	Mass();
        choices();
        break;
        
     case '3' :
        Acceleration();
        choices();
        break;
        
     case '4' :
  		cout << "\033[2J\033[1;1H";
        exit(1);
        
     default :
        cout<<"Wrong choice..!!..Press any key to exit..\n";
        choices();
  }
}

int main() {
	choices();
}
