#include <iostream>
#include <cmath>

using namespace std;

void Retangle() {
   int length, width, area;
   cout << " Enter Length: ";
   cin >> length;

   cout << " Enter Width: ";
   cin >> width;

   area = length * width;
   cout << " Area of the Rectangle: " << area << "\n";
}

void Triangle() {
   int height, base;
   float area; 
   cout << " Enter Height: ";
   cin >> height;
   
   cout << " Enter Base: ";
   cin >> base;
   
   area = (0.5) * height * base;

   cout<<" Area of the Triangle: "<< area << "\n";
}

void Square() {
   int side, area;
   cout << " Enter Sides: ";
   cin >> side;
   
   area = side * side;

   cout<<" Area of the Square: "<< area << "\n";
}

void Circle() {
  float radius, area;

   cout << " Enter radius: ";
   cin >> radius;

   area = 3.14 * radius * radius;
   cout << " Area of the Circle: " << area << "\n";
}

void choices() {
  char choice;
  
  cout<<"\n ------------------------\n";
  cout<<" Area of Different Shapes";
  cout<<"\n ------------------------\n\n";
  cout<<" 1. Area of Retangle\n";
  cout<<" 2. Area of Triangle\n";
  cout<<" 3. Area of Square\n";
  cout<<" 4. Area of Circle\n";
  cout<<" 5. Exit\n";
  cout<<"\n Choose Shape: ";
  
  cin>>choice;
  cout<<"\n";
  switch(choice)
  {
     case '1' :
     	Retangle();
        choices();
        break;
        
     case '2' :
     	Triangle();
        choices();
        break;
        
     case '3' :
        Square();
        choices();
        break;

     case '4' :
        Circle();
        choices();
        break;
        
     case '5' :
  		cout << "\033[2J\033[1;1H";
        exit(1);
        
     default :
        cout<<"Wrong choice..!!..Press any key to exit..\n";
        choices();
  }
}

int main() {
	choices();
}
