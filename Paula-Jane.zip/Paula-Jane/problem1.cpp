#include <iostream>
#include <cmath>

using namespace std;

void Inch2Foot() {
	float inches;
	cout << " Enter Inch: ";
	cin >> inches;
	int foot = inches / 12;
	cout << " Foot: " << foot << "\n";
}

void Inch2Yard() {
	float inches;
	cout << " Enter Inch: ";
	cin >> inches;

	int yards = inches / 36;
	cout << " Yard: " << yards << "\n";
}

void Foot2Yard() {
	int foot;
	cout << " Enter Foot: ";
	cin >> foot;

	int yards = foot / 3;
	cout << " Yard: " << yards << "\n";	
}

void Foot2Inch() {
	int foot;
	cout << " Enter Foot: ";
	cin >> foot;

	int inches = foot * 12;
	cout << " Inch: " << inches << "\n";	
}

void Yard2Inch() {
	int yards;
	cout << " Enter Yard: ";
	cin >> yards;

	int inches = yards * 36;
	cout << " Inch: " << inches << "\n";	
}

void Yard2Foot() {
	int yards;
	cout << " Enter Yard: ";
	cin >> yards;

	int foot = yards * 3;
	cout << " Foot: " << foot << "\n";
}


void choices() {
  char choice;
  
  cout<<"\n --------------------\n";
  cout<<" Simple C++ Converter";
  cout<<"\n --------------------\n\n";
  cout<<" 1. Inch to Foot\n";
  cout<<" 2. Inch to Yard\n";
  cout<<" 3. Foot to Inch\n";
  cout<<" 4. Foot to Yard\n";
  cout<<" 5. Yard to Inch\n";
  cout<<" 6. Yard to Foot\n";
  cout<<" 7. Exit\n";
  cout<<"\n Coversion type: ";
  cin>>choice;
  cout<<"\n";
  switch(choice)
  {
     case '1' :
     	Inch2Foot();
        choices();
        break;
        
     case '2' :
     	Inch2Yard();
        choices();
        break;
        
     case '3' :
        Foot2Inch();
        choices();
        break;
        
     case '4' :
        Foot2Yard();
        choices();
        break;
        
     case '5' :
        Yard2Inch();
        choices();
        break;
        
     case '6' :
        Yard2Foot();
        choices();
        break;
        
     case '7' :
  		cout << "\033[2J\033[1;1H";
        exit(1);
        
     default :
        cout<<"Wrong choice..!!..Press any key to exit..\n";
        choices();
  }
}

int main() {
	choices();
}
