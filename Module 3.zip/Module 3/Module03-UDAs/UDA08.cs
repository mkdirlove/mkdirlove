using System;
using System.Collections.Generic;
using System.Text;

namespace NetPay
{
 class Program
    {
 static void Main(string[] args)
        {
 string userInput;
 double netPay;
 double editedTax1;
 double grossPay;
 double editedTax2;
 double editedTax3;
 double hrsWorked;
 double ovtWorked;
 double payRate;

 const double TAX = 0.05;
 const double UNION = 0.02;
 const double SALOAN = 509.32;

            Console.WriteLine("WEEKLY PAYROLL INFORMATION");

            Console.WriteLine("--------------------------");

            Console.Write("\nENTER NUMBER OF HOUR: ");
            userInput = Console.ReadLine();
            hrsWorked = Convert.ToDouble(userInput);

            Console.Write("\nENTER OVERTIME HOUR: ");
            userInput = Console.ReadLine();
            ovtWorked = Convert.ToInt32(userInput);

            Console.Write("\nENTER HOURLY PAY RATE: ");
            userInput = Console.ReadLine();
            payRate = Convert.ToDouble(userInput);

            grossPay = (hrsWorked * payRate + ovtWorked * 1.5 * payRate);

            editedTax1 = TAX * grossPay;

            editedTax2 = UNION * grossPay;

            editedTax3 = TAX + UNION + SALOAN;

            netPay = editedTax1 + editedTax2 - grossPay;

            Console.WriteLine("\nGROSS PAY: {0}",grossPay);

            Console.WriteLine("TAX: {0}", editedTax1);
            Console.WriteLine("UNION: {0}", editedTax2);
            Console.WriteLine("DEDUCTION: {0}", editedTax3);
            Console.WriteLine("NET PAY: {0}",netPay);
       }
    }
}
