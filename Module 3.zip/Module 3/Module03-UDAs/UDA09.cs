using System;

namespace Problem06

{

	class Program

	{

		public static void Main(string[] args)

		{

			string str;

            int i, len, vowel=0, cons=0,digit=0,pun=0,space=0,sc=0;

		

          Console.Write("ENTER A LINE OF TEXT / STRING: ");

          str = Console.ReadLine();		

          len = str.Length;

            for(i=0; i<len; i++)

            {

            if(str[i] =='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u' ||

                 str[i]=='A' || str[i]=='E' || str[i]=='I' || str[i]=='O' || str[i]=='U')

            {

                vowel++;

            }

            else if((str[i]>='a' && str[i]<='z') || (str[i]>='A' && str[i]<='Z'))

            {

                cons++;

            }

            else if (str[i] >= '0' && str[i] <= '9')

            {

                digit++;

            }

            else if (str[i] == ' ')

            {

                space++;

            }

            else if (str[i] == '!' || str[i] == '.' || str[i] == '"' || str[i] == '(' || str[i] == '?'

                || str[i] == ':' || str[i] == ')' || str[i] == ';' )

            {

                pun++;

            }

            else

            {

                sc++;

            }

            

            }

            double total = vowel + cons + digit + space + pun + sc;

            double per1 = (vowel / total) * 100, p1 = Math.Round(per1, 2);

            double per2 = (cons / total) * 100,p2=Math.Round(per2,2);

            double per3 = (digit / total) * 100, p3 = Math.Round(per3, 2) ;

            double per4 = (space / total) * 100,p4=Math.Round(per4,2);

            double per5 = (pun / total) * 100,p5=Math.Round(per5,2);

            double per6 = (sc / total) * 100,p6=Math.Round(per6,2);

            double totalper = p1 + p2 + p3 + p4 + p5 + p6;

            double mean = total / 6;

            double var = Math.Pow((mean - vowel), 2) + Math.Pow((mean - cons), 2) + Math.Pow((mean - digit), 2) +

                Math.Pow((mean - space), 2) + Math.Pow((mean - pun), 2) + Math.Pow((mean - sc), 2);

            double variance = var / (6-1);

            double sd = Math.Sqrt(variance);

            

            Console.WriteLine();

			Console.WriteLine("------------------------------------------");
            Console.WriteLine("CHARACTERS\tFREQUENCY\tPERCENTAGE");
			Console.WriteLine("------------------------------------------");
			
            Console.WriteLine("VOWELS\t\t{0}\t\t{1}", vowel,p1);

            Console.WriteLine("CONSONANTS\t{0}\t\t{1}", cons, p2);

            Console.WriteLine("DIGITS\t\t{0}\t\t{1}", digit, p3);

            Console.WriteLine("SPACE\t\t{0}\t\t{1}", space, p4);

            Console.WriteLine("PUNCTUATION\t{0}\t\t{1}", pun, p5);

            Console.WriteLine("SPECIAL\t\t{0}\t\t{1}", sc, p6);

            Console.WriteLine("------------------------------------------");
            Console.WriteLine("TOTAL\t\t{0}\t\t{1}", total, totalper);
            Console.WriteLine("------------------------------------------");

            Console.WriteLine();

            
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("DESCRIPTIVE STATISTICS");
            Console.WriteLine("------------------------------------------");

            Console.WriteLine("MEAN "+Math.Round(mean,2));

            Console.WriteLine("VARIANCE " + Math.Round(variance, 2));

            Console.WriteLine("STANDARD DEVIATION " + Math.Round(sd,2));

            Console.ReadLine();

			Console.ReadKey(true);

		}

	}

}
