using System;

namespace Characters

{

	class Program

	{

		public static void Main(string[] args)

		{

			char c;

			bool isLowercaseVowel, isUppercaseVowel;

			

			Console.Write("ENTER ANY CHARACTER: ");

			c = char.Parse(Console.ReadLine());

			

			isLowercaseVowel = (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');

			isUppercaseVowel = (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U');

			if (isLowercaseVowel || isUppercaseVowel) 

	    {

            Console.WriteLine("'{0}' IS A VOWEL.", c);

        }

            else

        {

            Console.WriteLine("'{0}' IS A CONSONANT.", c);

        }

			if((c >= 97 && c <= 122) || (c >= 65 && c <= 90))

        {

            Console.WriteLine("'{0}' IS AN ALPHABET.", c);

        }

            else if(c >= 48 && c <= 57)

        {

            Console.WriteLine("'{0}' IS A DIGIT.", c);

        }

            else

        {

            Console.WriteLine("'{0}' IS A SPECIAL CHARACTER.", c);

        }

			// TODO: Implement Functionality Here

			

			Console.Write("Press any key to continue . . . ");

			Console.ReadKey(true);

		}

	}

}
