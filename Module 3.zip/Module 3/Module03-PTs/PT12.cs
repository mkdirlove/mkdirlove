using System;

namespace Problem05
{
 class Program
 {
 public static void Main(string[] args)
 {
 
 int n,i,sum;
 string m = "";
 int mx;
 
  Console.Write("ENTER THE RANGE OF NUMBER: ");
  mx = int.Parse(Console.ReadLine());
  Console.WriteLine("NUMBER\tSUM OF FACTORS\tREMARKS");
 for(n=1;n<=mx;n++)
 {
    i=1;
    sum = 0;
 while(i<n)
 {
 if(n%i==0)
           sum=sum+i;
          i++; 
 }
 if (sum == n)
 {
      m = "PERFECT";
 }
 else if(sum >= n)
 {
      m = "ABUNDANT";
 }
 else
 {
      m = "DEFICIENT";
 }
    Console.WriteLine("\t{0}     \t\t{1}     \t{2}",n,sum,m);
 }
 }
}
}
