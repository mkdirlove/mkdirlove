using System;

using System.Linq;

namespace PrimeNumbers

{

	class Program

	{

		public static void Main(string[] args)

		{

			bool isPrime = true;

            Console.WriteLine("P­RIME NUMBERS BETWEEN 150: ");

            for (int i = 2; i <= 150; i++)

        {

            for (int j = 2; j <= 150; j++)

        {

            if (i != j && i % j == 0)

        {

            isPrime = false;

            break;

        }

        }

            if (isPrime)

        {

            Console.Write("\t" +i);

        }

            isPrime = true;

        }

            Console.ReadKey();

        }

    }

}
