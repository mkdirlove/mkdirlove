using System;

namespace NumberPattern
{
 class Program
 {
  static void Main(string[] args)
  {
   int i, j, num;
   Console.WriteLine("Enter the input reference number for the processing of output: ");
   num = int.Parse(Console.ReadLine());

   for(i=num; i>=1; i--)
   {
    for(j=num; j>=i; j--)
     Console.Write(j);
    Console.WriteLine();
   } 
  }
 }
}
