using System;

namespace OddEv

{

	class Program

	{

		public static void Main(string[] args)

		{

			int num1, num2, num3, num4, num5, num6, sum;

			int odd = 0, even = 0;

			

			Console.Write("ENTER 6 NUMBERS: ");

			num1 = Convert.ToInt32(Console.ReadLine());

			num2 = Convert.ToInt32(Console.ReadLine());

			num3 = Convert.ToInt32(Console.ReadLine());

			num4 = Convert.ToInt32(Console.ReadLine());

			num5 = Convert.ToInt32(Console.ReadLine());

			num6 = Convert.ToInt32(Console.ReadLine());

			

			Console.WriteLine("\n");

			if (num1 % 2 == 0){

				even = even + num1;

                Console.WriteLine("THE NUMBER IS EVEN");

			}else {

				odd = odd + num1;

				Console.WriteLine("THE NUMBER IS ODD");			    	

			      }

			if (num2 % 2 == 0){

				even = even + num2;

				Console.WriteLine("THE NUMBER IS EVEN");

			}else {

				odd = odd + num2;

				Console.WriteLine("THE NUMBER IS ODD");

			}

			if (num3 % 2 == 0){

				even = even + num3;

				Console.WriteLine("THE NUMBER IS EVEN");

			}else {

				odd = odd + num3;

				Console.WriteLine("THE NUMBER IS ODD");

			}

			if (num4 % 2 == 0){

				even = even + num4;

				Console.WriteLine("THE NUMBER IS EVEN");

			}else {

				odd = odd + num4;

				Console.WriteLine("THE NUMBER IS ODD");

			}

			if (num5 % 2 == 0){

				even = even + num5;

				Console.WriteLine("THE NUMBER IS EVEN");

			}else {

				odd = odd + num5;

				Console.WriteLine("THE NUMBER IS ODD");

			}

			if (num6 % 2 == 0){

				even = even + num6;

				Console.WriteLine("THE NUMBER IS EVEN");

			}else {

				odd = odd + num6;

				Console.WriteLine("THE NUMBER IS ODD");

			}

			

			sum = num1 + num2 + num3 + num4 + num5 + num6;

			

			Console.WriteLine();

			if(odd > even) {

				Console.WriteLine("SUM OF ALL ODD: {0}",odd);

			}else {

				Console.WriteLine("SUM OF ALL EVEN: {0}",even);

			}
			

			Console.Write("Press any key to continue . . . ");

			Console.ReadKey(true);

		}

	}

}
