using System;

namespace LeapYearProgram

{

	class Program

	{

		public static void Main(string[] args)

		{

			int year1, year2, year3, year4, year5;

			int more = 0, less = 0;

            Console.Write("\n\n");

            Console.Write("CHECK WETHER THE GIVEN YEAR IS LEAP YEAR OR NOT:\n");

            Console.Write("----------------------------------------------");

            Console.Write("\n\n");

            Console.Write("ENTER FIVE YEARS: ");

            year1 = int.Parse(Console.ReadLine());

            year2 = int.Parse(Console.ReadLine());

            year3 = int.Parse(Console.ReadLine());

            year4 = int.Parse(Console.ReadLine());

            year5 = int.Parse(Console.ReadLine());

            Console.WriteLine("CHECKING YEAR.....");

            Console.Write("\n\n");            

            System.Threading.Thread.Sleep(2000);

            if ((year1 % 400) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year1);

            }else if ((year1 % 100) == 0){

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year1);

            }else if ((year1 % 4) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year1);

            }else{

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year1);

            }

            

            if ((year2 % 400) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year2);

            }else if ((year2 % 100) == 0){

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year2);

            }else if ((year2 % 4) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year2);

            }else{

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year2);

            }

            

            if ((year3 % 400) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year3);

            }else if ((year3 % 100) == 0){

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year3);

            }else if ((year3 % 4) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year3);

            }else{

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year3);

            }

            

            if ((year4 % 400) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year4);

            }else if ((year4 % 100) == 0){

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year4);

            }else if ((year4 % 4) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year4);

            }else{

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year4);

            }

            

            if ((year5 % 400) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year5);

            }else if ((year5 % 100) == 0){

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year5);

            }else if ((year5 % 4) == 0){

            	more += 1;

            Console.WriteLine("{0} IS LEAP YEAR.\n", year5);

            }else{

            	less += 1;

            Console.WriteLine("{0} IS NOT LEAP YEAR.\n", year5);

            }

            Console.WriteLine();

            if(more > less) {

            	Console.WriteLine("MORE LEAP YEAR");

            }else {

            	Console.WriteLine("LESS LEAP YEAR");

            }

            Console.ReadKey();

       }

   }

}

