using System;

namespace BaseExpo

{

	class Program

	{

		public static void Main(string[] args)

		{

			double m, n;

			string inputString;

            char response;

            Console.Write("ENTER BASE: ");

            m = double.Parse(Console.ReadLine());

            Console.Write("ENTER EXPONENT: ");

            n = double.Parse(Console.ReadLine());

            double value1 = Math.Pow(m, n);

            Console.WriteLine("{0} RAISE TO {1} = {0} ^ {1} = {2}",m,n,value1);

            Console.ReadLine();

            

            Console.Write("TRY AGAIN? Y/N: ");

            inputString = Console.ReadLine();

            Console.WriteLine("\n");

            response = Convert.ToChar(inputString);

            while (response == 'y')

         {

            Console.Write("ENTER BASE: ");

            m = double.Parse(Console.ReadLine());

            Console.Write("ENTER EXPONENT: ");

            n = double.Parse(Console.ReadLine());

            double value2 = Math.Pow(m, n);

            Console.WriteLine("{0} RAISE TO {1} = {0} ^ {1} = {2}",m,n,value2);

            Console.ReadLine();

            

            Console.Write("TRY AGAIN? Y/N: ");

            inputString = Console.ReadLine();

            Console.WriteLine("\n");

            response = Convert.ToChar(inputString);

        }

        }

     }

}
