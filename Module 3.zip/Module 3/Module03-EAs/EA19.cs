using System;

namespace GrossPay

{

	class Program

	{

		public static void Main(string[] args)

		{

            string input;

            double gross_pay;

            double hours;

            double overtime;

            double rate;

            Console.WriteLine("WEEKLY SALARY INFORMATION");

            Console.WriteLine("----------------------------");

            Console.Write("\nENTER HOUR YOU WORKED THIS WEEK: ");

            input = Console.ReadLine();

            hours = Convert.ToDouble(input);

            	

            Console.Write("\nENTER THE NUMBER OF OVERTIME HOURS: ");

            input = Console.ReadLine();

            overtime = Convert.ToInt32(input);

            Console.Write("\nENTER HOURLY PAY RATE: ");

            input = Console.ReadLine();

            rate = Convert.ToDouble(input);

            gross_pay = (hours * rate);

            overtime = (hours * rate + overtime * 1.5 * rate);

            

            Console.WriteLine("\nGROSS PAY: {0}",gross_pay);

            Console.WriteLine("\nOVER TIME PAY: {0}",overtime);

        }

    }

}
