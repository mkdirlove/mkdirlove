using System;

namespace LargerNumber

{

	class Program

	{

		public static void Main(string[] args)

		{

			int num1 ,num2;

			

			Console.Write("ENTER 1ST NUMBER: ");

			num1 = Convert.ToInt32(Console.ReadLine());

			Console.Write("ENTER 2ND NUMBER: ");

			num2 = Convert.ToInt32(Console.ReadLine());

			

			if(num1 > num2) {

				Console.WriteLine("THE SUM: {0}",num1 + num2);

			}else{

				Console.WriteLine("THE PRODUCT: {0}",num1 * num2);

			}

			// TODO: Implement Functionality Here

			

			Console.Write("Press any key to continue . . . ");

			Console.ReadKey(true);

		}

	}

}
