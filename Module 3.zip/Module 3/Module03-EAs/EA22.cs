using System;

namespace StartEndYear

{

	class Program

	{

		public static void Main(string[] args) 

		{

			int yr1, yr2, i, j, ttl_days = 0, num=0;

            Console.Write("ENTER START YEAR: ");

            yr1 = int.Parse(Console.ReadLine());

            Console.Write("ENTER END YEAR: ");

            yr2 = int.Parse(Console.ReadLine());

            for (i = yr1; i <= yr2; i++)

            {

                num += 1;

                for (j = i; j <= i; j++)

                {

                    if (j % 4 == 0)

                    {

                        ttl_days += 366;

                    }

                    else

                    {

                        ttl_days += 365;

                    }

                }

            }

            Console.WriteLine("NO. OR YEAR/S: {0}",num);

            Console.WriteLine("NO. OF DAYS: {0}",ttl_days);

            Console.ReadLine();

			Console.ReadKey(true);

		}

	}

}
