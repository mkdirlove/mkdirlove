class HelloWorld {
    static void Main() {
        System.Console.WriteLine("give me a bottle of rum!");
    }
}
