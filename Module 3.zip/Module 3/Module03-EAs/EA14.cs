using System;
 
public class PNZ
{
    static void Main(string[] args)
    {
        int num;
 
        Console.WriteLine("Enter any number: ");
        num = int.Parse(Console.ReadLine());        
 
        if (num > 0)
        {            
            Console.WriteLine("Enter number is positive ");
        }
        else if (num < 0)
        {
            Console.WriteLine("Enter number is nagative ");            
        }
        else
        {
            Console.WriteLine("Enter number is zero ");            
        }     
 
        Console.ReadLine();
    }
}
