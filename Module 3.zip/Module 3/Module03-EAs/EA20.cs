using System;

namespace AcceptAndStop

{

	class Program

	{

		public static void Main(string[] args)

		{

			int a;  

            int count = 0;  

            int prevInt = 0; 

            

            do {

                 Console.Write("ENTER A NUMBER: ");

                 a = Convert.ToInt32(Console.ReadLine());   

     

                 if (a == prevInt) { 

                 count++;   

                 if (count == 2)

               { 

        	break; 

        }

    }

            prevInt = a;

            count = 1;

} 

            while(count < 3);

            Console.WriteLine("Done!");

		}

     }

}
