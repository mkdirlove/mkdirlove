using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AllInOne

{

	class Program

	{

		public static void Main(string[] args)

		{

			int m, i, sum = 0, ave = 0, odd = 0, even = 0;
			int mx, mn;

			Console.WriteLine("Enter how many number/s to read: ");

			m = int.Parse(Console.ReadLine());

			

			int[] a = new int[m];

			for(i = 0; i < m; i++) {

				Console.WriteLine("Enter number: ");

				a[i] = int.Parse(Console.ReadLine());

				if (a[i] % 2 == 0){
					even += 1;
				}
				else {
					odd += 1;
				}
			}

			for(i = 0; i < m; i++) {

				sum += a[i];

			}



				mx = a[0];
			    mn = a[0];
			    
			    for(i=1; i<m; i++)
			    {
			        if(a[i]>mx)
			        {
			            mx = a[i];
			        }
			
			
			        if(a[i]<mn)
			        {
			            mn = a[i];
			        }
			    }

			sum = m + m;

			ave = m / m;	

			
			Console.WriteLine("\nSum = {0}",sum);

			Console.WriteLine("Average = {0}",ave);

			Console.WriteLine("Highest = {0}",mx);

			Console.WriteLine("Smallest = {0}",mn);

			Console.WriteLine("No. of Odd number/s: {0}",odd);
			
			Console.WriteLine("No. of Even number/s: {0}",even);

			

			Console.Write("Press any key to continue . . . ");

			Console.ReadKey(true);

		}

	}

}
