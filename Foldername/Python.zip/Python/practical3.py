import importlib.util
import subprocess
from cryptography.fernet import Fernet

def check_cryptography_installed():
    cryptography_spec = importlib.util.find_spec("cryptography")
    return cryptography_spec is not None

def install_cryptography():
    subprocess.check_call(["pip", "install", "cryptography"])

def encrypt_data(data, password):
    key = Fernet.generate_key()
    cipher_suite = Fernet(key)
    encrypted_data = cipher_suite.encrypt(data.encode())
    return key, encrypted_data

def decrypt_data(encrypted_data, password):
    cipher_suite = Fernet(password)
    decrypted_data = cipher_suite.decrypt(encrypted_data)
    return decrypted_data.decode()

def run_encryption():
    data = input("Enter string to encrypt: ")
    password = input("Enter Password to be encrypt: ")

    if not check_cryptography_installed():
        print("cryptography library is not installed. Installing...")
        install_cryptography()

    key, encrypted_data = encrypt_data(data, password)
    print("\nEncrypted data:")
    print(encrypted_data)

    decrypted_data = decrypt_data(encrypted_data, key)
    print("\nDecrypted data:", decrypted_data)

run_encryption()
