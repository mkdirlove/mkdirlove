import itertools
import time

def guess_string(target_string):
    start_time = time.time()
    total_guess = 0
    match_found = False

    for guess in itertools.product("ABC123", repeat=4):
        guess = ''.join(guess)
        total_guess += 1

        print(f"Checking: {guess}")
        if guess == target_string:
            match_found = True
            break

    end_time = time.time()
    duration = int(end_time - start_time)

    print(f"\nMatch Found: {guess}")
    print(f"Total Guess: {total_guess}")
    print(f"Duration of Guess: {format_time(duration)}")

def format_time(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

target_string = input("Enter string to guess: ")
guess_string(target_string)
