import time
import requests

def check_internet_connection(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            return True
        else:
            return False
    except requests.exceptions.RequestException:
        return False

def run_internet_check(url, attempts, interval):
    print(f"\nChecking connection to {url}")
    connected = check_internet_connection(url)
    if connected:
        print(f"Status: You are connected to {url}")
    else:
        print(f"Status: You are not connected to {url}")

    for i in range(1, attempts+1):
        print(f"Checking after {interval} seconds...")
        time.sleep(interval)
        print(f"Check Count: {i}\n")
        connected = check_internet_connection(url)
        if connected:
            print(f"Status: You are still connected to {url}")
        else:
            print(f"Status: You are no longer connected to {url}")

url = input("Enter website to check: ")
run_internet_check(url, 15, 45)
