<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Login | Enrollment System</title>
 	

<?php include('./header.php'); ?>
<?php 
session_start();
if(isset($_SESSION['login_id']))
header("location:index.php?page=home");
?>

</head>
<style>
	body{
		width: 100%;
	    height: calc(100%);
	    background: #007bff;
	}
	main#main{
		width:100%;
		height: calc(100%);
		background:white;
	}
	#login-left{
		position: absolute;
		left:0;
		width:60%;
		height: calc(100%);
		background-image: url(https://scontent.fmnl3-4.fna.fbcdn.net/v/t39.30808-6/335833945_1007152523862933_8967615009696606711_n.jpg?stp=cp6_dst-jpg&_nc_cat=102&ccb=1-7&_nc_sid=e3f864&_nc_eui2=AeG0ZqTdXdGhHfgwr4pez4L4qiIreziya2mqIit7OLJraXHNix9VcL1aEDaO8lpyg0OO0Phae3ttDUFjJvGOwfpJ&_nc_ohc=f5WIBREI6Z8AX8JfJ1T&_nc_ht=scontent.fmnl3-4.fna&oh=00_AfCL9hAPI5yunijvGFgqIWlsptwSTk8Lp_ZF9WHW6RmKCg&oe=64556164);
		background-repeat: no-repeat;
		background-size: cover;
	}
	#login-left::before { /* add a pseudo-element to create a background layer */
		content: "";
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.5);
		filter: blur(10px); /* add the blur effect */
	}
	#login-right{
		position: absolute;
		right:0;
		width:40%;
		height: calc(100%);
		background:white;
		display: flex;
		align-items: center;
		flex-flow: wrap;
	}
	#login-right .card{
		margin: auto
	}
	#logo{
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%); /* center the logo horizontally and vertically */
		width: 200px; /* adjust the width of the logo as needed */
	}
</style>

<main id="main" class="login alert-info">
  
    		<div id="login-left">
<div id="logo">
  <img src="https://scontent.fmnl3-4.fna.fbcdn.net/v/t39.30808-6/279203122_5269990113044084_3951425420168033920_n.jpg?_nc_cat=106&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeFV9aA2uCFBWoZFVeyFkUGvKkvMnk_9PsoqS8yeT_0-yg5TWEHRBvuS86k4N9Rf4AVpe_qZdj4Rxf-c0Bk6ly6v&_nc_ohc=KaMnpNOnIIwAX-u42_x&_nc_ht=scontent.fmnl3-4.fna&oh=00_AfDs9BqOJdmNmuawZ6MD8UvrJmRHWVaUOcGmSdHw29AYTQ&oe=645551FF" alt="Logo">
</div>

    		</div>
  		
  		<div id="login-right">
  			<div class="col-md-12 text-center">
  				<h4><strong>School Enrollment System - Login</strong></h4>
  			</div>
  
  			<div class="card col-md-8">
  				<div class="card-body">
  					<form id="login-form" >
  						<div class="form-group">
  							<label for="username" class="control-label">Username</label>
  							<input type="text" id="username" name="username" class="form-control">
  						</div>
  						<div class="form-group">
  							<label for="password" class="control-label">Password</label>
  							<input type="password" id="password" name="password" class="form-control">
  						</div>
  						<center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Login</button></center>
  					</form>
  				</div>
  			</div>
  		</div>
     
  
    </main>

  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>


</body>
<script>
	$('#login-form').submit(function(e){
		e.preventDefault()
		$('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
		if($(this).find('.alert-danger').length > 0 )
			$(this).find('.alert-danger').remove();
		$.ajax({
			url:'ajax.php?action=login',
			method:'POST',
			data:$(this).serialize(),
			error:err=>{
				console.log(err)
		$('#login-form button[type="button"]').removeAttr('disabled').html('Login');

			},
			success:function(resp){
				if(resp == 1){
					location.reload('index.php?page=home');
				}else{
					$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				}
			}
		})
	})
</script>	
</html>
