<?php 

function connect() {
    static $conn;

    if ($conn == null) {
        $conn = mysqli_connect("localhost", "root", "mkdirlove", "school_db");
    }

    if ($conn) {
        return $conn;
    } else {
        header("Location: .."); 
    }



}


?>
