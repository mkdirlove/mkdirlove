-- phpMyAdmin SQL Dump
-- version 5.2.1deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 03, 2023 at 03:03 AM
-- Server version: 10.11.2-MariaDB-1
-- PHP Version: 8.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `logid` int(11) NOT NULL,
  `logtext` text NOT NULL,
  `log_time` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`logid`, `logtext`, `log_time`) VALUES
(102, 'Admin Admin  has logged in', '2023-05-03 02:59:16'),
(103, 'Admin Admin accepted a student.', '2023-05-03 02:59:45'),
(104, 'Admin Admin  has logged out.', '2023-05-03 03:00:43');

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`id`, `username`, `password`, `status`) VALUES
(46, 'admin', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL,
  `fullname` text DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` text DEFAULT NULL,
  `contact` text DEFAULT NULL,
  `lrn` bigint(11) DEFAULT NULL,
  `mname` text DEFAULT NULL,
  `mcontact` bigint(15) DEFAULT NULL,
  `fname` text DEFAULT NULL,
  `fcontact` bigint(15) DEFAULT NULL,
  `gwa` int(11) DEFAULT NULL,
  `birthcert_id` bigint(15) DEFAULT NULL,
  `email` text DEFAULT NULL,
  `fb` text DEFAULT NULL,
  `strand` text DEFAULT NULL,
  `section` text DEFAULT NULL,
  `status_enroll` int(11) NOT NULL DEFAULT 1,
  `utype` int(11) NOT NULL DEFAULT 0,
  `birthday` date DEFAULT NULL,
  `birthplace` text DEFAULT NULL,
  `religion` text DEFAULT NULL,
  `mother_tongue` text DEFAULT NULL,
  `home_address` text DEFAULT NULL,
  `malumni` text NOT NULL,
  `falumni` text NOT NULL,
  `last_school` text DEFAULT NULL,
  `school_type` text DEFAULT NULL,
  `listahan_benef` text DEFAULT NULL,
  `four_p` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `fullname`, `age`, `sex`, `contact`, `lrn`, `mname`, `mcontact`, `fname`, `fcontact`, `gwa`, `birthcert_id`, `email`, `fb`, `strand`, `section`, `status_enroll`, `utype`, `birthday`, `birthplace`, `religion`, `mother_tongue`, `home_address`, `malumni`, `falumni`, `last_school`, `school_type`, `listahan_benef`, `four_p`) VALUES
(46, 'Admin Admin', 18, 'Female', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, NULL, '', '', NULL, NULL, NULL, NULL),
(90, 'fgdfg dfgdf dfgdfg ', 17, 'Female', 'sdfsdf', 12345678901, 'sdfsdf', 98765342, 'sdfsdf', 9876543211, 90, -1, 'sdfsdf@gmail.com', 'sdfsdf', 'HE1', '11ICT', 2, 0, '2023-05-08', 'sdfsd', 'sdfsdf', 'sdfsdf', 'asdfasd', 'yes', 'yes', 'dfgdfg', 'Public', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
