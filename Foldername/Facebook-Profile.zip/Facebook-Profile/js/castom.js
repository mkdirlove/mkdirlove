"use strict";

let input_Profile_Name = "MJ Angheles Caw";
let input_Profile_Image = "images/profile/profile.jpg";


let Input_firnd_1 = "images/friends/profile-1.jpg";

