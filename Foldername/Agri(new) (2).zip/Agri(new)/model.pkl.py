# Import dependencies
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
import joblib

# Load the dataset
df = pd.read_csv('sample_new.csv')
include = ['Season', 'District_Name', 'Crop', 'Area_Harvested']  # Four features
df_ = df[include]

# Data Preprocessing
# Encode categorical variables
label_encoders = {}
for col in ['Crop']:
    le = LabelEncoder()
    df_[col] = le.fit_transform(df_[col])
    label_encoders[col] = le

# Handle missing values (example: filling numerical missing values with mean)
df_['Area_Harvested'].fillna(df_['Area_Harvested'].mean(), inplace=True)

# Define features and target variable
X = df_[['Crop', 'Area_Harvested']]
y = df_['Season']

# Initialize and train the KNN Classifier
knn = KNeighborsClassifier(n_neighbors=3)  # You can adjust the number of neighbors as per your choice
knn.fit(X, y)

# Save the trained model
joblib.dump(knn, 'knn_model.pkl')
print("knn_model.pkl dumped!")

# Save the label encoders
joblib.dump(label_encoders, 'label_encoders.pkl')
print("Label encoders dumped!")

# Saving the data columns from training
model_columns = ['Crop', 'Area_Harvested']
joblib.dump(model_columns, 'model_columns.pkl')
print("Model columns dumped!")
