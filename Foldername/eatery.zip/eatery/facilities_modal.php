<div id="facilities" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
	  <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title center"><i class = "fa fa-pagelines green"></i>Terms And Condition</h4>
        </div>
         <div class="modal-body">
                <div class="padd">
					<p>  1. Catering is within the area of NEGROS OCCIDENTAL only.</p>

					<p>2. Additional 10% payment on reservation outside Kabankalan City.</p>

					<p>3. MINIMUM Pax For Lunch nd Dinner 50px , Merienda 100px and in the Non-Combo Combo meal is 30px.</p>

					<p>4. Costumer must pay 50% of the actual price as an advance payment 3 days after confirmation, if the costumer failed to pay the said advance payment reservation will be cancelled.</p>

					<p>5. The management will call the costumer about the payment details.</p>

					<p>6. If the costumer wants to cancel its confirmed reservation due to personal reason, the management will get 25% from the advance payment he/she made as charge for the damages.</p>

					<p>7. 50 percent should be paid before the approval of reservation, 3 days without payments will resolve to the termination of reservation.</p>

					<p>8. Terms of payments will be personal payments.
close</p>
				</div>
        </div>
        
    </div>
</div>