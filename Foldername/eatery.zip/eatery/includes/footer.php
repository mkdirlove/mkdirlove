<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
            <!-- Copyright info -->
            <p class="copy center">Copyright &copy; 2023 | <a href="#">Ate's Eatery and Sari Sari Store</a> </p>
      </div>
    </div>
  </div>
</footer> 