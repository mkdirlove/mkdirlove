<?php

$careerObjectives = array(
    'Career Objectives' => 'One of my key career objectives as a second-year college student pursuing a Bachelor of Science in Information Technology Animation and Game Development (BSITAGD). Becoming a Skilled Animator: Many individuals aspire to become skilled animators, focusing on creating visually appealing and engaging animations for games, films, television, or other digital media. The objective may be to master various animation techniques, such as 2D or 3D animation, character animation, special effects, or motion graphics.');

?>
