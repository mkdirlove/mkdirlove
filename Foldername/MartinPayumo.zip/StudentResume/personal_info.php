<?php

$personalInfo = array(
    'Name' => 'Martin Emmanuel Payumo',
    'Address' => '#24 K4th Kamuning Qc',
    'Email' => '202110692@fit.edu.ph',
    'Phone' => '09162000461',
    'Sex' => 'Male',
    'Birth' => 'December 21, 2001',
    'Nationality' => 'Filipino'
);

?>