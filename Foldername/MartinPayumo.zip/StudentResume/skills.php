<?php
$skills = array(
    'C++',
    'Java',
    'PHP',
    'Javascript',
    'Python',
    'Photoshop',
    'Illustrator'
);
?>
