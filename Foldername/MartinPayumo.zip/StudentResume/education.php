<?php

$educationData = array(
    array(
        'Institution' => 'Immaculate Conception Cathedral School',
        'Level' => 'Primary',
    ),
    array(
        'Institution' => 'Immaculate Conception Cathedral School',
        'Level' => 'Secondary',
    ),
    array(
        'Institution' => 'FEU Institute of Technology',
        'Level' => 'Tertiary',
        'Course' => 'Bachelor of Science in Information Technology Animation and Game Development (BSITAGD)',
    ),
);

?>
