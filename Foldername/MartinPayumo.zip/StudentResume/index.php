<!DOCTYPE html>
<html>
<head>
    <title>Table Example</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            text-align: center;
            border: 1px solid black;
            padding: 8px;
        }
        
        img {
            max-height: 200px;
        }

        p {
            text-align: left;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>
                <?php
                $imagePath = "StudentResume/profile.png"; // Path to your image file
                echo '<img src="' . $imagePath . '" alt="Profile Image">';
                ?>
            </th>
<th class="perinfo">
    Personal Information<br>
    <?php
    include 'personal_info.php';

    echo '<p>Name: ' . $personalInfo['Name'] . '</p>';
    echo '<p>Address: ' . $personalInfo['Address'] . '</p>';
    echo '<p>Email: ' . $personalInfo['Email'] . '</p>';
    echo '<p>Phone Number: ' . $personalInfo['Phone'] . '</p>';
    echo '<p>Sex: ' . $personalInfo['Sex'] . '</p>';
    echo '<p>Date of Birth: ' . $personalInfo['Birth'] . '</p>';
    echo '<p>Nationality: ' . $personalInfo['Nationality'] . '</p>';
    ?>
</th>

            </th>
        </tr>
    </table>
    <table>
        <tr>
            <td>
        <?php
        include 'career.php';
        foreach ($careerObjectives as $key => $value) {
            echo '<p>' . $key . '</p>';
            echo '<p>' . $value . '</p>';
        }
        ?></td>
        </tr>
        
        <tr>
            <th>Educationa Attainment</th>
        </tr>
        <td>
        <?php
        include 'education.php';

        foreach ($educationData as $education) {

            echo '<p>' . $education['Institution'] . '</p>';
            echo '<p>' . $education['Level'];
            if (isset($education['Course'])) {
                echo ' - ' . $education['Course'];
            }
            echo '</p>';
        }
        ?></td>
        <tr>
            <td>Slills</td>
        </tr>
        <td>
            <?php
        include 'skills.php';

        foreach ($skills as $skill) {
            echo '<p>' . $skill . '</p>';
        }
        ?>
        </td>
        <tr>
            <td>Affilation</td>
        </tr>
                <td>
            <?php
        include 'affiliation.php';

        foreach ($affiliation as $affiliations) {
            echo '<p>' . $affiliations . '</p>';
        }
        ?>
        </td>
        <tr>
            <td>Work Experience</td>
        </tr>
                        <td>
            <?php
        include 'experience.php';

        foreach ($experience as $experiences) {
            echo '<p>' . $experiences . '</p>';
        }
        ?>
        </td>
    </table>
</body>
</html>
