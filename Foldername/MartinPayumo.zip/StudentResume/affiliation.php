<?php
$affiliation = array(
    'N/A'
);
?>
