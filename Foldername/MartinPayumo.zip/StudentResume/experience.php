<?php
$experience = array(
    'N/A'
);
?>
