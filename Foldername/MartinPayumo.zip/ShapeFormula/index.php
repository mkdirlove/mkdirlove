<?php
function calculateVolume($shape, $params)
{
    switch ($shape) {
        case 'Cube':
            $side = $params['side'];
            return $side * $side * $side;
        case 'Right Rectangular Prism':
            $length = $params['length'];
            $width = $params['width'];
            $height = $params['height'];
            return $length * $width * $height;
        case 'Prism or Cylinder':
            $radius = $params['radius'];
            $height = $params['height'];
            return pi() * $radius * $radius * $height;
        case 'Pyramid or Cone':
            $baseArea = $params['baseArea'];
            $height = $params['height'];
            return (1 / 3) * $baseArea * $height;
        case 'Sphere':
            $radius = $params['radius'];
            return (4 / 3) * pi() * $radius * $radius * $radius;
        default:
            return 0;
    }
}

// Define the shapes and their respective parameters
$shapes = array(
    array(
        'name' => 'Cube',
        'params' => array('side' => 5),
        'formula' => 'V = s³'
    ),
    array(
        'name' => 'Right Rectangular Prism',
        'params' => array('length' => 4, 'width' => 3, 'height' => 6),
        'formula' => 'V = lwh'
    ),
    array(
        'name' => 'Prism or Cylinder',
        'params' => array('radius' => 2, 'height' => 8),
        'formula' => 'V = πr²h'
    ),
    array(
        'name' => 'Pyramid or Cone',
        'params' => array('baseArea' => 10, 'height' => 5),
        'formula' => 'V = (1/3) * baseArea * h'
    ),
    array(
        'name' => 'Sphere',
        'params' => array('radius' => 3),
        'formula' => 'V = (4/3) * πr³'
    )
);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Volume Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 3px solid black;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <center><h1>Volume Calculator</h1></center>
    <table>
        <tr>
            <th>Value</th>
            <th>Formula</th>
            <th>Answer</th>
        </tr>
        <?php foreach ($shapes as $shape): ?>
            <tr>
                <td>
                    <?php
                        foreach ($shape['params'] as $param => $value) {
                            echo "$param = $value<br>";
                        }
                    ?>
                </td>
                <td><?php echo $shape['formula']; ?></td>
                <td><?php echo calculateVolume($shape['name'], $shape['params']); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
