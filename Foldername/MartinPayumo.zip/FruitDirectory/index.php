<?php
$fruits = array(
    array(
        'name' => 'Apple',
        'image' => 'apple.png',
        'description' => 'The apple is a sweet and crunchy fruit.',
        'facts' => 'Apples are a good source of dietary fiber.'
    ),
    array(
        'name' => 'Banana',
        'image' => 'bananas.png',
        'description' => 'Bananas are a popular tropical fruit.',
        'facts' => 'Bananas are rich in potassium.'
    ),
    array(
        'name' => 'Orange',
        'image' => 'orange.png',
        'description' => 'Oranges are citrus fruits with a refreshing taste.',
        'facts' => 'Oranges are high in vitamin C.'
    ),
    array(
        'name' => 'Strawberry',
        'image' => 'strawberry.png',
        'description' => 'Strawberries are juicy and sweet berries.',
        'facts' => 'Strawberries are packed with antioxidants.'
    ),
    array(
        'name' => 'Mango',
        'image' => 'mango.png',
        'description' => 'Mangoes are tropical fruits known for their sweet taste.',
        'facts' => 'Mangoes are the national fruit of India, Pakistan, and the Philippines.'
    ),
    array(
        'name' => 'Grapes',
        'image' => 'grape.png',
        'description' => 'Grapes are small and juicy fruits that come in various colors.',
        'facts' => 'Grapes are used to make wine and raisins.'
    ),
    array(
        'name' => 'Watermelon',
        'image' => 'watermelon.png',
        'description' => 'Watermelon is a refreshing and hydrating fruit with a sweet taste.',
        'facts' => 'Watermelon is over 90% water.'
    ),
    array(
        'name' => 'Pineapple',
        'image' => 'pineapple.png',
        'description' => 'Pineapples have a tropical flavor and are rich in vitamins and minerals.',
        'facts' => 'Pineapples contain an enzyme called bromelain that aids digestion.'
    ),
    array(
        'name' => 'Kiwi',
        'image' => 'kiwi.png',
        'description' => 'Kiwis are small fruits with a fuzzy brown exterior and bright green flesh.',
        'facts' => 'Kiwis are a great source of vitamin C and dietary fiber.'
    ),
    array(
        'name' => 'Peach',
        'image' => 'peach.png',
        'description' => 'Peaches are juicy and sweet fruits with a fuzzy skin.',
        'facts' => 'Peaches belong to the rose family and are related to cherries, apricots, and plums.'
    )
);


// Sort the fruits array alphabetically by name
usort($fruits, function($a, $b) {
    return strcmp($a['name'], $b['name']);
});
?>

<!DOCTYPE html>
<html>
<head>
    <title>Fruit Directory</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 3px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        img {
            max-width: 50px;
            height: auto;
            display: block;
        }
    </style>
</head>
<body>
    <center>
        <h1>My Fruits</h1>
    </center>
    <table>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Description</th>
            <th>Facts</th>
        </tr>
        <?php foreach ($fruits as $fruit): ?>
            <tr>
                <td><img src="<?php echo $fruit['image']; ?>" alt="<?php echo $fruit['name']; ?>"></td>
                <td><?php echo $fruit['name']; ?></td>
                <td><?php echo $fruit['description']; ?></td>
                <td><?php echo $fruit['facts']; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>