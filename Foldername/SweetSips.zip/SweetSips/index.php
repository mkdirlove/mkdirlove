<?php 
	$welcome="Welcome  to SweetSips Milk Tea Shop";
	$description = "To all fanatics out there, SweetSips's tea shop offers a wide range of delicious and refreshing organic pearl bubble tea beverages.<br>Guaranteed made from the high-quality 100 percent freshly brewed loose-leaf teas for a healthy lifestyle."; 
?>

<html>
   <head>
      <title> SweetSips </title>
      <link rel="stylesheet" href="./css/style.css">
   </head>
   <body>
      <nav>
         <div class="logonav">
            <img id="logo" src="./img/logo.png">
         </div>
         <ul>
            <li> <a href="index.php"> Home </a>
            <li> <a href="about.php"> About Us </a> </li>
            <li> <a href="products.php"> Product </a>  </li>
            <li> <a href="contact.php"> Contact </a>    </li>
         </ul>
      </nav>
      <p class="Welcome">
         <?php 
         	echo $welcome;
         ?> 
         </b>
         <br>
      <p id="description">
         <?php 
         	echo $description;
         ?>          
         <br>
         <br>
      <center>
         <br> 
         <br>
         <img class="picture" src="./img/img1.jpeg"> 
         <img class="picture" src="./img/img2.jpeg">           
         <img class="picture" src="./img/img3.jpeg">
      </center>
      <div class="header">
      <div class="row1">
         <div class="blog">
            <div class="content-info">
               <h3>  Follow us on instagram!   </h3>
               @SweetSips
            </div>
         </div>
      </div>
      <div class="footer">
         <h2> All rights reserved. (SweetSips) </h2>
         <h2 id="visitor-count"> Visitors: <span id="count">0</span></h2>
      </div>
   </body>
   <script type="text/javascript">
         var count = 0;
         count = parseInt(localStorage.getItem("count")) || 0;
         count++;
         localStorage.setItem("count", count);
         document.getElementById("count").innerHTML = count;
      </script>
</html>
