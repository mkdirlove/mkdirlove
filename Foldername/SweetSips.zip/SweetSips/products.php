<?php
	$main = "A refreshing combination of brewed black tea, milk, and (optional) tapioca pearl";
	$second = "A strong black tea combined with sweetened condensed milk <br> and studded with (optional) tapioca pearls";
	$third = "A fresh fruit-based tea with your choice of boba that is often caffeine-free<br>";
?>

<html>
   <head>
      <title> Products </title>
      <link rel="stylesheet" href="./css/products.css">
   </head>
   <body>
      <body>
         <nav>
            <div class="logonav">
               <img id="logo" src="./img/logo.png">
            </div>
            <ul>
            <li> <a href="index.php"> Home </a>
            <li> <a href="about.php"> About Us </a> </li>
            <li> <a href="products.php"> Product </a>  </li>
            <li> <a href="contact.php"> Contact </a>    </li>
            </ul>
         </nav>
         <br>
         <h3> OUR MENU </h3>
         <div class="main">
            <div class="first">
               <img src="./img/milktea.png" width="300px">
               <p id="headingtext">
                  <?php
                  	echo $main;
                  ?>
               </p>
               <p id="captiontext">
                  Small - ₱110 <br>
                  Regular -₱125 <br>
                  Grande - ₱135 
               </p>
            </div>
            <div class="second">
               <img src="./img/thaitea.png" width="300px">
               <p id="headingtext">
                  <?php
                  	echo $second;
                  ?>
               </p>
               <p id="captiontext">
                  Small - ₱100 <br>
                  Regular -₱115<br>
                  Grande - ₱130 
               </p>
            </div>
            <div class="third">
               <img src="./img/fruittea.png" width="300px">
               <p id="headingtext">
                  <?php
                  	echo $third;
                  ?> 
               </p>
               <p id="captiontext">
                  Small - ₱110 <br>
                  Regular -₱115<br>
                  Grande - ₱135
               </p>
            </div>
         </div>
   </body>
</html>
