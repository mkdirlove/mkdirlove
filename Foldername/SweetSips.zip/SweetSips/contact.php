<?php 
	$phone = "Mobile phone";
	$mail = "Email Address";
	$fb = "Like and follow us!";
	$shop = "Visit our shop!";
?>

<html>
   <head>
      <title> Contact Us </title>
      <link rel="stylesheet" href="./css/contact.css">
   </head>
   <body>
      <body>
         <nav>
            <div class="logonav">
               <img id="logo" src="./img/logo.png">
            </div>
            <ul>
            <li> <a href="index.php"> Home </a>
            <li> <a href="about.php"> About Us </a> </li>
            <li> <a href="products.php"> Product </a>  </li>
            <li> <a href="contact.php"> Contact </a>    </li>
            </ul>
         </nav>
         <br>
         <h3> CONTACT US </h3>
         <div class="main">
            <div class="first">
               <img src="./img/phone.png" width="300px">
               <p id="headingtext">
                  <?php
                  	echo $phone;
                  ?> 
               </p>
               <p id="captiontext">
                  Smart: +639999999999 <br>
                  Globe: +639999999999
               </p>
            </div>
            <div class="second">
               <img src="./img/mail.png" width="300px">
               <p id="headingtext">
                  <?php
                  	echo $mail;
                  ?> 
               </p>
               <p id="captiontext">
                  sweetsips@gmail.com
               </p>
            </div>
            <div class="third">
               <img src="./img/fb2.png" width="700px">
               <p id="headingtext">
				<?php
					echo $fb;
				?>
                <br> 
               </p>
               <p id="captiontext">
                  @SweetSips
               </p>
            </div>
         </div>
         <p>
		<?php
			echo $shop;
		?>
         </p>
         <div class="map"> 
         <div style="width: 100%"><iframe width="100%" height="600" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=1%20Grafton%20Street,%20Dublin,%20Ireland+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"><a href="https://www.maps.ie/distance-area-calculator.html">distance maps</a></iframe></div>
         </div>
      <div class="footer">
         <h2> All rights reserved. (SweetSips) </h2><br>
         <h2 id="visitor-count"> Visitors: <span id="count">0</span></h2>
      </div>
   </body>
   <script type="text/javascript">
         var count = 0;
         count = parseInt(localStorage.getItem("count")) || 0;
         count++;
         localStorage.setItem("count", count);
         document.getElementById("count").innerHTML = count;
      </script>
</html>
