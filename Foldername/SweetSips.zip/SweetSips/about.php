<?php 
	$about = "Forget about worrying about the taste and quality as our milk tea's. So, ready your tummy as you visit our shop: A happy alternative to fast food, this is our new favorite spot for tasty (also) healthy snacks and drinks.";
?>

<html>
   <head>
      <title> About </title>
      <link rel="stylesheet" href="./css/about.css">
   </head>
   <body>
      <nav>
         <div class="logonav">
            <img id="logo" src="./img/logo.png">
         </div>
         <ul>
            <li> <a href="index.php"> Home </a>
            <li> <a href="about.php"> About Us </a> </li>
            <li> <a href="products.php"> Product </a>  </li>
            <li> <a href="contact.php"> Contact </a>    </li>
         </ul>
      </nav>
      <br>
      <br>
      <center>
      <img class="img1" src="./img/tables.jpg">
      </div>
      <div class="header">
      <div class="row1">
      <div class="text">
      <div class="content-info">
      <p class="text1">
		<?php
			echo $about;
		?>
      </p>  
         <br>
      <div class="pagerfooter">
      <div class="footer">
         <h2> All rights reserved. (SweetSips) </h2>
         <h2 id="visitor-count"> Visitors: <span id="count">0</span></h2>
      </div>
   </body>
   <script type="text/javascript">
         var count = 0;
         count = parseInt(localStorage.getItem("count")) || 0;
         count++;
         localStorage.setItem("count", count);
         document.getElementById("count").innerHTML = count;
      </script>
</html>
