function clearForm() {
    document.getElementById("num1").value = "";
    document.getElementById("num2").value = "";
    document.getElementById("result").innerHTML = "";
    document.getElementById("computeBtn").disabled = true;
}

function validateInputs() {
    var num1 = document.getElementById("num1").value;
    var num2 = document.getElementById("num2").value;
    var computeBtn = document.getElementById("computeBtn");

    if (num1 == "" || num2 == "") {
        computeBtn.disabled = true;
        if (num1 == "" && num2 == "") {
            alert("Please enter a value for Number 1 and Number 2.");
        } else if (num1 == "") {
            alert("Please enter a value for Number 1.");
        } else {
            alert("Please enter a value for Number 2.");
        }
    } else {
        computeBtn.disabled = false;
    }
}

function compute() {
    validateInputs();
    var num1 = Number(document.getElementById("num1").value);
    var num2 = Number(document.getElementById("num2").value);
    var operation = document.getElementById("operation").value;
    var result = document.getElementById("result");

    switch (operation) {
        case "add":
            result.innerHTML = num1 + num2;
            break;
        case "subtract":
            result.innerHTML = num1 - num2;
            break;
        case "multiply":
            result.innerHTML = num1 * num2;
            break;
        case "divide":
            result.innerHTML = num1 / num2;
            break;
        default:
            result.innerHTML = "";
            alert("Please select a valid operation.");
            break;
    }
}

var modeToggle = document.getElementById("mode-toggle");

// Check if there is a saved mode in local storage
var savedMode = localStorage.getItem("mode");
if (savedMode === "dark") {
    // Set the dark mode class on the body
    document.body.classList.add("dark-mode");
    // Update the button text
    modeToggle.textContent = "Light Mode";
}

function toggleMode() {
    var body = document.body;
    var mode = body.classList.contains("dark-mode") ? "light" : "dark";
    body.classList.toggle("dark-mode");
    modeToggle.textContent = mode === "dark" ? "Light Mode" : "Dark Mode";
    // Save the mode in local storage
    localStorage.setItem("mode", mode);
}