# GrayHat Phantom Backdoor Shell 

# Features
<ul>
<li> <b>CMD - Command</b></li>
Execute commands
<li> <b>Zone H Notifier</b></li>
Mass/Single Mirror Site on Zone H Notifier
<li> <b>Back Connector</b></li>
Reverse Shell with following payload (PHP, RUBY, PERL, PYTHON, NETCAT) credits to my friend bloos3rpent.
<li> <b>Mass Defacement</b></li>
Mass deface sites all folders on the same server
</ul>

# Review

![ghp_screenshot](https://user-images.githubusercontent.com/77033868/103889609-8ebf8080-509b-11eb-8303-c8f71e0ad076.png)
