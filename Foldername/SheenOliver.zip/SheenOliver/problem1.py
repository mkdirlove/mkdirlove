# Program to calculate the total bill, discount and final amount for multiple customers

# Function to calculate the total bill
def calculate_total_bill(num_soft_drinks, num_sandwiches):
    # Assume the cost of one soft drink is ₱17 and one sandwich is ₱20
    total_bill = (num_soft_drinks * 17) + (num_sandwiches * 20)
    return total_bill

# Function to calculate the final amount after discount
def calculate_final_amount(total_bill):
    discount = 15/100 * total_bill
    final_amount = total_bill - discount
    return final_amount

# Input the number of customers
num_customers = int(input("Enter the number of customers: "))

for i in range(num_customers):
    # Input the number of soft drinks and sandwiches bought
    num_soft_drinks = int(input("Enter the number of soft drinks: "))
    num_sandwiches = int(input("Enter the number of sandwiches: "))

    # Input the name of the customer
    customer_name = input("Enter the name of the customer: ")

    # Input the amount tendered by the customer
    amount_tendered = float(input("Enter the amount tendered by the customer: "))

    # Calculate the total bill
    total_bill = calculate_total_bill(num_soft_drinks, num_sandwiches)

    # Calculate the final amount
    final_amount = calculate_final_amount(total_bill)

    # Print the details
    print("\nBill for " + customer_name + ": ")
    print("Total bill: ₱" + str(total_bill))
    print("Discount: 15%")
    print("Final amount: ₱" + str(final_amount))
    print("Amount tendered: ₱" + str(amount_tendered))
    print("Change: ₱" + str(amount_tendered - final_amount))
    print()
