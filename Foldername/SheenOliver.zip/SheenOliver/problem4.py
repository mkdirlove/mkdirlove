while True:
    STUDENT_NAME = input("Enter student name: ")
    COURSE_CODE = input("Enter course code: ")
    YEAR_CODE = input("Enter year code: ")
    LECTURE_UNITS = int(input("Enter total number of lecture units enrolled: "))
    LAB_UNITS = int(input("Enter total number of laboratory units enrolled: "))
    COURSE_NAME = input("Enter course name: ")

    LECTURE_RATE = 500
    LAB_RATE = 300
    DOWN_PAYMENT = 1000

    TUITION_FEE = (LECTURE_UNITS * LECTURE_RATE) + (LAB_UNITS * LAB_RATE)
    BALANCE = TUITION_FEE - DOWN_PAYMENT
    TOTAL_UNITS = LECTURE_UNITS + LAB_UNITS

    print("\nStudent Name: ", STUDENT_NAME)
    print("Course Code: ", COURSE_CODE)
    print("Year Code: ", YEAR_CODE)
    print("Course Name: ", COURSE_NAME)
    print("Tuition Fee: ", TUITION_FEE)
    print("Balance: ", BALANCE)
    print("Total Units Enrolled: ", TOTAL_UNITS)
    repeat = input("Do you want to enter details for another student? (Y/N)")
    if repeat.upper() == "N":
        break
