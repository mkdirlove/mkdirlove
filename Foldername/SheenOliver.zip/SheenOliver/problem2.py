# Get the number of service crew members
num_crew = int(input("Enter the number of service crew members: "))

for i in range(num_crew):
    # Get input from user
    name = input("Enter Service Crew Name: ")
    hours_worked = float(input("Enter No. of Hours Worked: "))
    ot_hours = float(input("Enter Extra Service Hours (OT): "))
    ut_hours = float(input("Enter No. of Hours Late (UT): "))
    rate_per_hour = float(input("Enter Rate per Hour: "))
    food_deduction = float(input("Enter Food Deduction: "))
    extra_income = float(input("Enter Extra Income (Tip): "))

    #Calculate Pay
    ot_rate = rate_per_hour*1.03
    ot_pay = ot_hours * ot_rate
    ut_pay = ut_hours * rate_per_hour
    regular_pay = hours_worked* rate_per_hour

    gross_pay = regular_pay + ot_pay
    tax = gross_pay * 0.1
    insurance = gross_pay * 0.03
    sss = gross_pay * 0.05

    deduction = ut_pay + insurance + tax + sss + food_deduction
    net_pay = gross_pay - deduction + extra_income

    # Print the output
    print("\nService Crew Name: " + name)
    print("Under Time Pay: ₱" + str(ut_pay))
    print("Over Time Pay: ₱" + str(ot_pay))
    print("Extra Income (Tip): ₱" + str(extra_income))
    print("Net Pay: ₱" + str(net_pay))
    print()
