# Program to input and process multiple electricity bills

# Function to input and store consumer information
def input_consumer_info():
    consumer_name = input("Enter consumer name: ")
    consumer_id = input("Enter consumer ID: ")
    consumer_category = input("Enter consumer category (Residential/Commercial): ")
    consumer_address = input("Enter consumer address: ")
    return (consumer_name, consumer_id, consumer_category, consumer_address)

# Function to input and store bill information
def input_bill_info():
    present_reading = int(input("Enter present reading: "))
    previous_reading = int(input("Enter previous reading: "))
    current_rate = float(input("Enter current rate per unit: "))
    due_date = input("Enter due date (dd/mm/yyyy): ")
    return (present_reading, previous_reading, current_rate, due_date)

# Function to calculate bill amount
def calculate_bill(present_reading, previous_reading, current_rate):
    # Calculate CMU (Consumed Metered Units)
    CMU = present_reading - previous_reading
    # Calculate Amount Due
    amount_due = CMU * current_rate
    # Calculate Other Charges
    other_charges_rate = 0.23
    other_charges = amount_due * other_charges_rate
    # Calculate Net Bill Amount Due
    net_bill_amount_due = amount_due + other_charges
    return (net_bill_amount_due, other_charges, amount_due, CMU)

# Loop to input and process multiple bills
while True:
    # Input and store consumer information
    consumer_info = input_consumer_info()
    consumer_name = consumer_info[0]
    consumer_id = consumer_info[1]
    consumer_category = consumer_info[2]
    consumer_address = consumer_info[3]

    # Input and store bill information
    bill_info = input_bill_info()
    present_reading = bill_info[0]
    previous_reading = bill_info[1]
    current_rate = bill_info[2]
    due_date = bill_info[3]

    # Calculate bill amount
    bill_amount = calculate_bill(present_reading, previous_reading, current_rate)

    # Print bill information
    print("\nBill Information:")
    print("Consumer Name:", consumer_name)
    print("Consumer ID:", consumer_id)
    print("Consumer Category:", consumer_category)
    print("Consumer Address:", consumer_address)
    print("Consumed Metered Units:", bill_amount[3])
    print("Amount Due: ₱" + str(bill_amount[2]))
    print("Other Charges: ₱" + str(bill_amount[1]))
    print("Net Bill: ₱" + str(bill_amount[0]))
    print("Due Date:", due_date)

    # Ask the user if they want to input another bill
    repeat = input("\nDo you want to input another bill? (yes/no) ")
    if repeat.lower() == "no":
        break
