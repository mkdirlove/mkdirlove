function validateForm() {
    var model = document.forms[0]["model"].value;
    var color = document.forms[0]["color"].value;
    var year = document.forms[0]["year"].value;

    if (model == "" || color == "" || year == "") {
        alert("Please complete the form!");
        return false;
    }

    // Check if color is valid
    var validColors = ["red", "green", "blue", "yellow", "orange", "purple", "black", "white", "gray", "pink", "brown"];
    if (!validColors.includes(color.toLowerCase())) {
        alert("Invalid color, please enter a valid one");
        return false;
    }

    // Create vehicle object
    var vehicle = {
        model: model,
        color: color,
        year: year
    };

    // Display vehicle details
    var detailsDiv = document.getElementById("details");
    detailsDiv.innerHTML = "<p>Model: " + vehicle.model + "</p>" +
        "<p>Color: " + vehicle.color + "</p>" +
        "<p>Year Built: " + vehicle.year + "</p>";

    return false; // prevent form submission
}

var modeToggle = document.getElementById("mode-toggle");

// Check if there is a saved mode in local storage
var savedMode = localStorage.getItem("mode");
if (savedMode === "dark") {
    // Set the dark mode class on the body
    document.body.classList.add("dark-mode");
    // Update the button text
    modeToggle.textContent = "Light Mode";
}

function toggleMode() {
    var body = document.body;
    var mode = body.classList.contains("dark-mode") ? "light" : "dark";
    body.classList.toggle("dark-mode");
    modeToggle.textContent = mode === "dark" ? "Light Mode" : "Dark Mode";
    // Save the mode in local storage
    localStorage.setItem("mode", mode);
}