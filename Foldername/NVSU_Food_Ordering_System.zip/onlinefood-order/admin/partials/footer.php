<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center"><?php echo date("Y"); ?> All rights reserved. NVSU FOOD(For Online Ordering Depot)</a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>