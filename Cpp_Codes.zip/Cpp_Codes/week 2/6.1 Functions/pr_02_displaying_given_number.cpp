#include<iostream>
using namespace std;

void display(int num) {
    cout<<num<<endl;
    return;
}

int main() {

    int num;
    cin>>num;

    cout<<num<<endl;

    return 0;
}