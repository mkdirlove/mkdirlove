#include<iostream>
using namespace std;

int main() {

    char c;
    cin>>c;

    cout<<"The ASCII value of "<<c<<" is "<<int(c);
    return 0;
}