#include<iostream>
using namespace std;
int main()
{
    cout<<"Hello Guys Let's get started this course"<<endl;
    return 0;
}