#include<iostream>
using namespace std;
int main() {
    int a;
    int b;
    cin>>a>>b;

    if (a==b) {
        cout<<"Both numbers are equal"<<endl;
    }
    else {
        cout<<"Try Again!!"<<endl;
    }
    return 0;
}