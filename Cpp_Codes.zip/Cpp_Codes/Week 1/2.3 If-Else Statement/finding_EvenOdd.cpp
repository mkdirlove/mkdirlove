#include<iostream>
using namespace std;
 
int main() {
    int n;
    cin>>n;
    if (n%2==0) {
        cout<<n<<" The number is Even"<<endl;
    } 
    else {
        cout<<n<<" The number is Odd"<<endl;
    }
    return 0;
}